---
name: security-document
argument-hint: APPLICATION_NAME
description: Generate a comprehensive Security Document by analyzing the codebase for security patterns and creating a Markdown document following the standard template.
tags: [documentation, security, analysis, compliance]
---

# Security Document Generator

**Arguments:** $ARGUMENTS (Application name, e.g., "HRMS", "MyApp")

## Purpose
Generate a comprehensive Security Document for the specified application by analyzing the codebase for security patterns, authentication mechanisms, authorization controls, and data protection measures. The output follows the structure from `templates/SECURITY DOCUMENT.docx` but in Markdown format.

## Output
- **File:** `Documents/Security/{ApplicationName}_Security_Document.md`
- **Format:** Markdown (.md)

---

## Workflow

### Step 1: Parse Arguments & Setup
1. Extract APPLICATION_NAME from $ARGUMENTS
2. Set output path: `Documents/Security/{ApplicationName}_Security_Document.md`
3. Create output directory if needed using Bash: `mkdir -p Documents/Security`
4. **Detect technology stack** (see Technology Detection section below)

### Step 2: Security Analysis

Use the **Explore agent** to analyze the codebase for security patterns.

**IMPORTANT:** Use the appropriate search patterns based on the detected technology stack.

#### 2.1 Authentication Analysis

**Based on detected backend technology, search for:**

| Stack | JWT/Token Patterns | OAuth/SSO Patterns | Password Patterns |
|-------|-------------------|-------------------|-------------------|
| .NET (C#) | `**/JWTConfiguration.cs`, `**/*Jwt*.cs` | `**/Startup.cs`, `**/*Auth*.cs` | `**/*Password*.cs`, `**/*Hash*.cs` |
| Node.js/Express | `**/*jwt*.ts`, `**/*token*.ts` | `**/*oauth*.ts`, `**/*passport*.ts` | `**/*password*.ts`, `**/*hash*.ts` |
| NestJS | `**/*jwt*.strategy.ts`, `**/auth.module.ts` | `**/*oauth*.ts` | `**/*password*.ts` |
| Spring Boot | `**/*Security*.java`, `**/*Jwt*.java` | `**/*OAuth*.java` | `**/*Password*.java`, `**/*Encoder*.java` |
| Django | `**/settings.py`, `**/*auth*.py` | `**/*oauth*.py` | `**/*password*.py` |
| FastAPI | `**/*security*.py`, `**/*jwt*.py` | `**/*oauth*.py` | `**/*password*.py` |
| Go | `**/*jwt*.go`, `**/*auth*.go` | `**/*oauth*.go` | `**/*password*.go`, `**/*hash*.go` |
| Generic | `**/*jwt*.*`, `**/*auth*.*`, `**/*token*.*` | `**/*oauth*.*`, `**/*sso*.*` | `**/*password*.*`, `**/*hash*.*` |

#### 2.2 Authorization Analysis

**Based on detected backend technology, search for:**

| Stack | Roles/Permissions Patterns | Policy/Authorization Patterns |
|-------|---------------------------|------------------------------|
| .NET (C#) | `**/Roles.cs`, `**/Enums/*.cs`, `**/Permissions.cs` | `**/Controllers/*.cs` (Authorize attributes), `**/*Policy*.cs` |
| Node.js/Express | `**/roles*.ts`, `**/permissions*.ts` | `**/*middleware*.ts`, `**/*guard*.ts` |
| NestJS | `**/roles*.ts`, `**/*.guard.ts` | `**/*decorator*.ts` |
| Spring Boot | `**/Role*.java`, `**/Permission*.java` | `**/*Security*.java` |
| Django | `**/permissions.py` | `**/*decorator*.py`, `**/views.py` |
| FastAPI | `**/permissions.py`, `**/roles.py` | `**/*depends*.py` |
| Go | `**/roles*.go`, `**/permissions*.go` | `**/*middleware*.go` |
| Generic | `**/*role*.*`, `**/*permission*.*` | `**/*authorize*.*`, `**/*policy*.*` |

#### 2.3 Encryption & Data Security Analysis

**Based on detected backend technology, search for:**

| Stack | Encryption Patterns | Secret/Key Patterns |
|-------|--------------------|--------------------|
| .NET (C#) | `**/*Encrypt*.cs`, `**/*Crypto*.cs` | `**/appsettings*.json`, `**/*Config*.cs` |
| Node.js/Express | `**/*encrypt*.ts`, `**/*crypto*.ts` | `**/.env`, `**/config*.ts` |
| Spring Boot | `**/*Encrypt*.java`, `**/*Crypto*.java` | `**/application*.yml`, `**/application*.properties` |
| Django/FastAPI | `**/*encrypt*.py`, `**/*crypto*.py` | `**/settings.py`, `**/.env` |
| Go | `**/*encrypt*.go`, `**/*crypto*.go` | `**/*.env`, `**/config*.go` |
| Generic | `**/*encrypt*.*`, `**/*crypto*.*`, `**/*aes*.*` | `**/*config*.*`, `**/*secret*.*` |

#### 2.4 Sensitive Data Analysis

**Search for entities/models containing sensitive fields:**

| Stack | Entity/Model Patterns |
|-------|----------------------|
| .NET (C#) | `**/Entities/*.cs`, `**/DTOs/*.cs` |
| Node.js/Express | `**/models/*.ts`, `**/entities/*.ts` |
| NestJS | `**/entities/*.entity.ts` |
| Spring Boot | `**/entity/*.java`, `**/model/*.java` |
| Django | `**/models.py`, `**/*models*.py` |
| FastAPI | `**/models/*.py`, `**/schemas/*.py` |
| Go | `**/models/*.go`, `**/entities/*.go` |
| Generic | `**/{entities,models}/**/*.*` |

**Search for sensitive field names:**
- Password, Email, Phone
- PAN, Aadhar, SSN, NationalID
- BankAccount, Salary, CreditCard

#### 2.5 Logging Analysis

**Based on detected backend technology, search for:**

| Stack | Logging Patterns | Audit Patterns |
|-------|-----------------|----------------|
| .NET (C#) | `**/Program.cs`, `**/appsettings*.json` (Serilog/NLog) | `**/*Audit*.cs`, `**/*Log*.cs` |
| Node.js/Express | `**/*logger*.ts`, `**/*winston*.ts` | `**/*audit*.ts` |
| Spring Boot | `**/logback*.xml`, `**/application*.yml` | `**/*Audit*.java` |
| Django/FastAPI | `**/settings.py` (LOGGING) | `**/*audit*.py` |
| Go | `**/*log*.go`, `**/*zap*.go` | `**/*audit*.go` |
| Generic | `**/*log*.*`, `**/*logger*.*` | `**/*audit*.*` |

#### 2.6 Validation Analysis

**Based on detected backend technology, search for:**

| Stack | Validation Patterns |
|-------|-------------------|
| .NET (C#) | `**/Validations/*.cs`, `**/Validators/*.cs` (FluentValidation) |
| Node.js/Express | `**/*validator*.ts`, `**/*joi*.ts`, `**/*zod*.ts` |
| NestJS | `**/*dto*.ts` (class-validator decorators) |
| Spring Boot | `**/*Validator*.java` (javax.validation) |
| Django | `**/forms.py`, `**/serializers.py` |
| FastAPI | `**/schemas/*.py` (Pydantic) |
| Go | `**/*validator*.go` |
| Generic | `**/*valid*.*`, `**/*sanitize*.*` |

### Step 3: Generate Markdown Document

Write the security document to `Documents/Security/{ApplicationName}_Security_Document.md` using the Write tool.

---

## Technology Detection

### Automatic Detection Process

Before analyzing the codebase, detect the technology stack:

```
TECHNOLOGY DETECTION:

1. CHECK for module-structure.json at project root:
   IF EXISTS:
     - Read detectedStack.backend → use for backend patterns
     - Read detectedStack.frontend → use for frontend patterns
     - Read detectedStack.database → document in Technology section
     - Read projectName → use for document metadata
     - SKIP further detection

2. IF module-structure.json NOT found, DETECT manually:

   BACKEND DETECTION:
   - Check for *.csproj or *.sln → .NET (C#)
   - Check package.json for express/fastify/nestjs → Node.js
   - Check pom.xml or build.gradle for Spring → Spring Boot
   - Check requirements.txt/pyproject.toml for django → Django
   - Check requirements.txt for fastapi → FastAPI
   - Check for go.mod → Go
   - Check Gemfile for rails → Ruby on Rails
   - Check composer.json for laravel → Laravel (PHP)

   FRONTEND DETECTION:
   - Check for *.vue files → Vue.js
   - Check for angular.json → Angular
   - Check package.json for react → React
   - Check for next.config.* → Next.js
   - Check for svelte.config.* → Svelte

   DATABASE DETECTION:
   - Parse connection strings in config files
   - Check for ORM indicators (EF Core, Prisma, TypeORM, etc.)

3. STORE detected stack for use in pattern selection
```

---

## Document Structure (14 Sections)

### Section 1: Title & Metadata
**Auto-fill: Full**

```markdown
# SECURITY DOCUMENT

**Project / Application Name:** {APPLICATION_NAME from $ARGUMENTS or module-structure.json}
**Version:** 1.0
**Prepared By:** Security Architect / InfoSec Team
**Reviewed By:** Business Analyst
**Date:** {Current date in DD/MM/YYYY format}

---
```

### Section 2: Purpose
**Auto-fill: Full**

Standard template text:
> "The purpose of this document is to describe the security controls, access permissions, authentication mechanisms, and data protection measures implemented in the {APPLICATION_NAME} system.
>
> This ensures stakeholders understand how the system safeguards confidential data and complies with organizational security policies."

### Section 3: Scope
**Auto-fill: Full**

**This document covers:**
- User authentication and authorization
- Access control and role management
- Data security (at rest and in transit)
- Application vulnerabilities handling
- Logging and monitoring
- Compliance requirements
- Infrastructure and network security (high level)

**Out of scope:**
- Source code analysis
- Penetration test results (unless included separately)
- DevSecOps pipeline configuration

### Section 4: Security Roles and Responsibilities
**Auto-fill: Full**

Create **Table 1** (2 columns × 7 rows):

| Role | Responsibilities |
|------|------------------|
| Application Owner | Ensures compliance with org security standards |
| Security Architect | Designs system-level security controls |
| System Admin | Manages servers, access logs, patches |
| Business Analyst | Documents security requirements & clarifications |
| Developers | Implements secure coding practices |
| QA Engineers | Validates security acceptance criteria |

### Section 5: Authentication
**Auto-fill: Full** (from code analysis)

#### 5.1 Authentication Methods
Populate based on analysis findings:
- If JWT found: "JWT (JSON Web Token) based authentication"
- If OAuth/MSAL found: "OAuth 2.0 / SSO integration"
- If password auth found: "Username + Password authentication"
- If MFA found: "Multi-Factor Authentication (OTP)"

#### 5.2 Password Policy
Document findings from password-related code:
- Minimum length requirements
- Complexity requirements (uppercase, lowercase, number, symbol)
- Password expiry policy
- Lockout policy after failed attempts
- Password reset mechanism

### Section 6: Authorization & Access Control
**Auto-fill: Full** (from Roles/Permissions analysis)

#### 6.1 Role-Based Access Control (RBAC)
Create **Table 2** (2 columns × dynamic rows based on Roles enum):

| Role | Allowed Actions |
|------|-----------------|
| {Role from detected roles} | {Permissions associated with this role} |
| ... | ... |

#### 6.2 Access Management Rules
- Least privilege principle applied
- Segregation of duties enforced
- Admin actions fully logged
- Sensitive screens restricted to authorized roles

### Section 7: Data Security
**Auto-fill: Full** (from encryption/entities analysis)

#### 7.1 Data Encryption
Document findings:
- Data in Transit: HTTPS/TLS 1.2+
- Data at Rest: {Encryption method found, e.g., AES-256}
- API Communication: {Token type found, e.g., JWT}

#### 7.2 Sensitive Data Fields
Create **Table 3** (3 columns × dynamic rows):

| Field | Classification | Protection Mechanism |
|-------|---------------|---------------------|
| Password | Highly Sensitive | Hashed (bcrypt/AES) |
| Email | Personal Data | Encrypted storage |
| Phone Number | Personal Data | Masked in UI |
| {Sensitive field from entities} | {Classification} | {Protection method} |

### Section 8: Application Security Controls
**Auto-fill: Partial** (from validation analysis)

Document findings from validation code:
- Input validation and sanitization (from FluentValidation/Zod/Pydantic/etc.)
- Protection against SQL injection (if using parameterized queries/ORM)
- Rate limiting on login/API endpoints
- CSRF protection enabled
- XSS prevention via encoded outputs
- Session timeout configuration
- SameSite cookies enabled

### Section 9: Logging & Monitoring
**Auto-fill: Full** (from logging analysis)

#### 9.1 Logs Captured
- Login success/failure
- Password changes
- Role updates
- API call errors
- System exceptions

#### 9.2 Monitoring
- Alerts for multiple failed login attempts
- Real-time monitoring dashboard
- SIEM integration (if applicable)

### Section 10: Compliance Requirements
**Auto-fill: Full**

Standard compliance framework:
- GDPR (if personal data of EU citizens is collected)
- ISO 27001 security controls
- SOC 2 Type II policies
- Company internal security standards

### Section 11: Infrastructure & Network Security
**Auto-fill: Placeholder** (Manual input needed)

#### 11.1 Hosting Environment
> [PLACEHOLDER: Specify hosting environment - AWS/Azure/GCP/On-premise]
- Security groups & VPC rules configured
- Firewall and WAF enabled

#### 11.2 Backup & Recovery
> [PLACEHOLDER: Specify backup frequency and retention policy]
- Daily automated backups
- 30-day retention period
- Disaster recovery site available

### Section 12: Known Security Risks
**Auto-fill: Placeholder** (Manual input needed)

> [PLACEHOLDER: Document current known security risks]
- Example: Outdated library in payment module (upgrade pending)
- Example: Missing MFA for admin users
- Example: Manual approval flow for user account creation

### Section 13: Recommendations
**Auto-fill: Auto-generated** (from gap analysis)

Generate recommendations based on detected gaps:
- If no MFA detected → "Enable MFA for all user roles"
- If hardcoded keys found → "Move sensitive keys to secure key management (Azure Key Vault/AWS Secrets Manager)"
- If no rate limiting → "Implement rate limiting on authentication endpoints"
- If no CORS config → "Configure CORS policies for API endpoints"
- If weak password policy → "Strengthen password policy requirements"
- Standard recommendations:
  - Implement automated security patching
  - Conduct annual penetration testing
  - Enhance monitoring with anomaly detection

### Section 14: Document History
**Auto-fill: Full**

Create **Table 4** (4 columns × 2 rows):

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 1.0 | {Current date} | Security Architect | Initial draft |

---

## Gap Analysis Logic

After analyzing the codebase, identify security gaps and generate recommendations:

### Gap Detection Rules

| Gap Detected | Recommendation |
|--------------|---------------|
| No MFA/2FA implementation | "Enable Multi-Factor Authentication for all user roles" |
| Hardcoded secrets in code | "Move all secrets to secure key management service" |
| No rate limiting middleware | "Implement rate limiting on authentication and API endpoints" |
| No CORS configuration | "Configure CORS policies to restrict allowed origins" |
| Missing input validation | "Implement comprehensive input validation using appropriate library" |
| No audit logging | "Implement audit logging for sensitive operations" |
| Weak password policy | "Enforce strong password policy (min 12 chars, complexity)" |
| Missing HTTPS enforcement | "Enforce HTTPS for all communications" |
| No session timeout | "Implement session timeout after 15 minutes of inactivity" |
| Missing security headers | "Add security headers (X-Content-Type-Options, X-Frame-Options, CSP)" |

---

## Output Format Template

Write the following Markdown structure to `Documents/Security/{ApplicationName}_Security_Document.md`:

```markdown
# SECURITY DOCUMENT

**Project / Application Name:** {APPLICATION_NAME}
**Version:** 1.0
**Prepared By:** Security Architect / InfoSec Team
**Reviewed By:** Business Analyst
**Date:** {Current date}

---

## 1. Purpose

The purpose of this document is to describe the security controls, access permissions, authentication mechanisms, and data protection measures implemented in the {APPLICATION_NAME} system.

This ensures stakeholders understand how the system safeguards confidential data and complies with organizational security policies.

---

## 2. Scope

**This document covers:**
- User authentication and authorization
- Access control and role management
- Data security (at rest and in transit)
- Application vulnerabilities handling
- Logging and monitoring
- Compliance requirements
- Infrastructure and network security (high level)

**Out of scope:**
- Source code analysis
- Penetration test results (unless included separately)
- DevSecOps pipeline configuration

---

## 3. Security Roles and Responsibilities

| Role | Responsibilities |
|------|------------------|
| Application Owner | Ensures compliance with org security standards |
| Security Architect | Designs system-level security controls |
| System Admin | Manages servers, access logs, patches |
| Business Analyst | Documents security requirements & clarifications |
| Developers | Implements secure coding practices |
| QA Engineers | Validates security acceptance criteria |

---

## 4. Authentication

### 4.1 Authentication Methods

{List authentication methods found in codebase}

### 4.2 Password Policy

{List password policy details from analysis}

---

## 5. Authorization & Access Control

### 5.1 Role-Based Access Control (RBAC)

| Role | Allowed Actions |
|------|-----------------|
| {Roles from analysis} | {Permissions} |

### 5.2 Access Management Rules

- Least privilege principle applied
- Segregation of duties enforced
- Admin actions fully logged
- Sensitive screens restricted to authorized roles

---

## 6. Data Security

### 6.1 Data Encryption

- **Data in Transit:** HTTPS/TLS 1.2+
- **Data at Rest:** {Encryption method found}
- **API Communication:** {Token type found}

### 6.2 Sensitive Data Fields

| Field | Classification | Protection Mechanism |
|-------|---------------|---------------------|
| {Fields from analysis} | {Classification} | {Protection} |

---

## 7. Application Security Controls

{List security controls found in codebase}

---

## 8. Logging & Monitoring

### 8.1 Logs Captured

{List logged events from analysis}

### 8.2 Monitoring

{List monitoring capabilities}

---

## 9. Vulnerability Management

- Monthly vulnerability scanning
- Quarterly penetration testing
- CVE-based patching process
- Secure code reviews part of SDLC
- Automated dependency vulnerability checks

---

## 10. Compliance Requirements

The system follows:
- GDPR (if personal data of EU citizens is collected)
- ISO 27001 security controls
- SOC 2 Type II policies
- Company internal security standards

---

## 11. Infrastructure & Network Security (High Level)

### 11.1 Hosting Environment

> [PLACEHOLDER: Specify hosting environment]

### 11.2 Backup & Recovery

> [PLACEHOLDER: Specify backup policy]

---

## 12. Known Security Risks (Current System)

> [PLACEHOLDER: Document known security risks]

---

## 13. Recommendations

{Auto-generated recommendations from gap analysis}

---

## 14. Document History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 1.0 | {Current date} | Security Architect | Initial draft |
```

---

## Step 4: Template Alignment Verification (MANDATORY)

> **CRITICAL: This step ensures 100% alignment with the DOCX template. Do NOT skip.**

### 4.1 Extract Template Structure

Use MCP tools to read the DOCX template:

1. Call `mcp__word-document-server__get_document_outline` with template path:
   `templates/SECURITY DOCUMENT.docx`

2. Extract and document:
   - All section headings with their levels
   - All tables with row/column counts
   - Content structure expectations

### 4.2 Compare Generated Document

Read the generated Markdown document and compare:

| Check | Template Expectation | Generated | Status |
|-------|---------------------|-----------|--------|
| Section Count | 24 sections | ? | PASS/FAIL |
| Table Count | 4 tables | ? | PASS/FAIL |
| Heading Hierarchy | H1→H2→H3 | ? | PASS/FAIL |

### 4.3 Section Alignment Verification

Verify ALL 24 sections are present with exact names:

| # | Expected Section | Found | Status |
|---|------------------|-------|--------|
| 1 | Title & Metadata | ? | PASS/FAIL |
| 2 | 1. Purpose | ? | PASS/FAIL |
| 3 | 2. Scope | ? | PASS/FAIL |
| 4 | 3. Security Roles and Responsibilities | ? | PASS/FAIL |
| 5 | 4. Authentication | ? | PASS/FAIL |
| 6 | 4.1 Authentication Methods | ? | PASS/FAIL |
| 7 | 4.2 Password Policy | ? | PASS/FAIL |
| 8 | 5. Authorization & Access Control | ? | PASS/FAIL |
| 9 | 5.1 Role-Based Access Control (RBAC) | ? | PASS/FAIL |
| 10 | 5.2 Access Management Rules | ? | PASS/FAIL |
| 11 | 6. Data Security | ? | PASS/FAIL |
| 12 | 6.1 Data Encryption | ? | PASS/FAIL |
| 13 | 6.2 Sensitive Data Fields | ? | PASS/FAIL |
| 14 | 7. Application Security Controls | ? | PASS/FAIL |
| 15 | 8. Logging & Monitoring | ? | PASS/FAIL |
| 16 | 8.1 Logs Captured | ? | PASS/FAIL |
| 17 | 8.2 Monitoring | ? | PASS/FAIL |
| 18 | 9. Vulnerability Management | ? | PASS/FAIL |
| 19 | 10. Compliance Requirements | ? | PASS/FAIL |
| 20 | 11. Infrastructure & Network Security | ? | PASS/FAIL |
| 21 | 11.1 Hosting Environment | ? | PASS/FAIL |
| 22 | 11.2 Backup & Recovery | ? | PASS/FAIL |
| 23 | 12. Known Security Risks | ? | PASS/FAIL |
| 24 | 13. Recommendations | ? | PASS/FAIL |
| 25 | 14. Document History | ? | PASS/FAIL |

### 4.4 Table Alignment Verification

Verify ALL 4 tables are present with correct structure:

| Table | Expected Structure | Found | Status |
|-------|-------------------|-------|--------|
| Security Roles | 2 columns (Role, Responsibilities), 6+ rows | ? | PASS/FAIL |
| RBAC | 2 columns (Role, Allowed Actions), 4+ rows | ? | PASS/FAIL |
| Sensitive Data Fields | 3 columns (Field, Classification, Protection Mechanism), 4+ rows | ? | PASS/FAIL |
| Document History | 4 columns (Version, Date, Author, Description), 2+ rows | ? | PASS/FAIL |

### 4.5 Auto-Correction Loop

If alignment < 100%, execute corrections:

```
WHILE alignment_score < 100%:
    1. Identify first mismatch
    2. Apply correction:
       - Missing Section → Add section with exact template heading
       - Wrong Section Name → Rename to match template exactly
       - Missing Table → Add table with correct structure
       - Wrong Table Structure → Adjust columns/rows to match
       - Wrong Heading Level → Adjust markdown heading level
    3. Re-verify document
    4. Update alignment score

    MAX_ITERATIONS = 5
    IF iterations > MAX_ITERATIONS: Report remaining issues and proceed
```

### 4.6 Alignment Report

After verification, output:

```
## Template Alignment Results

**Template:** templates/SECURITY DOCUMENT.docx
**Document:** Documents/Security/{ApplicationName}_Security_Document.md
**Alignment Score:** {SCORE}%

### Summary
| Category | Expected | Found | Status |
|----------|----------|-------|--------|
| Sections | 24 | {N} | PASS/FAIL |
| Tables | 4 | {N} | PASS/FAIL |
| Heading Levels | H1/H2/H3 | {levels} | PASS/FAIL |

### Corrections Applied
- {List of corrections made, or "None required"}

### Status: ALIGNED / NEEDS MANUAL REVIEW
```

---

## Verification Checklist

Before completing, verify:
- [ ] Document created at `Documents/Security/{ApplicationName}_Security_Document.md`
- [ ] All 14 sections present with correct headings
- [ ] Table 1 (Security Roles): 2 columns × 7 rows
- [ ] Table 2 (RBAC): 2 columns × 5+ rows (based on detected Roles)
- [ ] Table 3 (Sensitive Data): 3 columns × 5+ rows
- [ ] Table 4 (Document History): 4 columns × 2 rows
- [ ] Authentication section populated from JWT/OAuth analysis
- [ ] Authorization section populated from Roles/Permissions analysis
- [ ] Data Security section populated from encryption/entities analysis
- [ ] Logging section populated from logging analysis
- [ ] Recommendations auto-generated from gap analysis
- [ ] Placeholder sections clearly marked for manual input

---

## Critical Source Files to Analyze

**The paths below are determined dynamically based on the detected technology stack.**

If `module-structure.json` exists, use the `detectedStack` information.

Otherwise, use the Explore agent with these generic patterns:

| Purpose | Generic Pattern (adapts to detected stack) |
|---------|---------------------------------------------|
| Roles/Permissions | `**/*role*.*`, `**/*permission*.*`, `**/enums/*.*` |
| JWT/Auth config | `**/*jwt*.*`, `**/*auth*.*`, `**/*security*.*` |
| Encryption | `**/*encrypt*.*`, `**/*crypto*.*`, `**/*aes*.*` |
| Entities | `**/{entities,models,domain}/**/*.*` |
| Logging config | `**/*log*.*`, `**/appsettings*.*`, `**/settings.py` |
| Validation | `**/*valid*.*`, `**/*validator*.*` |

---

## Execution

Now analyze the application "$ARGUMENTS" and generate the complete Security Document:

1. **Parse arguments** - Extract APPLICATION_NAME from $ARGUMENTS
2. **Detect technology stack** - Check for module-structure.json or detect from project files
3. **Create directory** - Run `mkdir -p Documents/Security`
4. **Run security analysis** - Use Explore agent with technology-appropriate patterns
5. **Collect findings** - Gather authentication, authorization, encryption, logging details
6. **Generate document** - Use Write tool to create Markdown file
7. **Run gap analysis** - Identify missing security controls
8. **Add recommendations** - Generate improvement suggestions
9. **Verify output** - Confirm all sections and tables present
