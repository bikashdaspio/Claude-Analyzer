---
name: iterative-migrate
argument-hint: MODULE_NAME
description: Iteratively migrates an application or module to a different framework (e.g., React to Vue):
---
# Iterative Migration

## Overview
The Iterative Migration agent combines the capabilities of both the React to Vue Migrator and the UI Parity agents to ensure a smooth and accurate migration process. This agent performs the migration in an iterative manner, allowing for continuous feedback and refinement until the migrated application achieves 100% visual and functional parity.

## Objective
Migrate $MODULE_NAME from React to Vue while ensuring that the UI parity agent confirms 100% visual and behavioral parity between the source and migrated UIs.

## Migration steps
1. Using the react-vue-bridge agent to perform initial migration and document all decisions, challenges, and learnings in Migration Notes.
2. Submitting the migrated UI to the ui-parity agent for pixel-perfect and behavioral comparison with the source UI.
3. Applying feedback from the ui-parity agent and the migrations notes of previous iterations to incrementally rectify and improve the migrated code.
4. Repeating the migration-feedback-rectification loop until the ui-parity agent confirms 100% visual and functional parity.
5. Ensuring all migration notes, decisions, and fixes are tracked in Documents/Migration Notes/{module_name}/.

## COMPLETION CRITERIA
- The iterative migration process should only stop when the ui-parity agent confirms the visual and behavioral parity between the source and migrated UI is 100%.