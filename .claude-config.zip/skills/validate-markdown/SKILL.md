---
name: validate-markdown
argument-hint: FILE_PATH [--auto-fix]
description: Validate and clean markdown content for pandoc compatibility, checking tables, lists, headings, code blocks, and other elements with detailed reports and optional auto-fix mode.
tags: [validation, markdown, pandoc, documentation, quality]
---

# Markdown Pandoc Validation Skill

## Purpose

This skill validates markdown documents for pandoc compatibility, ensuring clean conversion to formats like DOCX, PDF, and HTML. It performs section-by-section analysis with detailed reports, line numbers, and rule-based validation.

## Output

1. **Console Report**: Detailed validation report with scores, issues by category, and recommendations
2. **Fixed File** (if `--auto-fix`): Corrected markdown file with safe auto-fixes applied
3. **Backup File** (if `--auto-fix`): Original file backed up as `{filename}.backup.md`

---

## Workflow

### Phase 1: Argument Parsing

Extract arguments from `$ARGUMENTS`:

```
Arguments: $ARGUMENTS
```

**Parse the following:**
- `FILE_PATH`: The markdown file to validate (required)
- `--auto-fix`: Flag to enable automatic corrections (optional)

**Validation:**
- Confirm FILE_PATH is provided
- Verify file exists using Read tool
- Check file has `.md` extension

If FILE_PATH is missing, display usage:
```
Usage: /validate-markdown FILE_PATH [--auto-fix]

Arguments:
  FILE_PATH    Path to the markdown file to validate
  --auto-fix   Automatically fix safe issues and create backup

Example:
  /validate-markdown Documents/Modules/Crons.md
  /validate-markdown Documents/BRD/HR_BRD.md --auto-fix
```

---

### Phase 2: Content Parsing

1. **Read the file** using Read tool
2. **Split content into sections** by heading boundaries (lines starting with `#`)
3. **Build line-indexed structure**:
   ```
   {
     sections: [
       { heading: "# Title", startLine: 1, endLine: 15, content: "..." },
       { heading: "## Section 1", startLine: 16, endLine: 45, content: "..." }
     ],
     tables: [ { startLine: 20, endLine: 28, content: "..." } ],
     lists: [ { startLine: 30, endLine: 35, content: "...", type: "unordered" } ],
     codeBlocks: [ { startLine: 40, endLine: 55, language: "javascript" } ]
   }
   ```

---

### Phase 3: Table Validation

Apply these rules to each table found:
goto https://pandoc.org/MANUAL.html#pandocs-markdown and apply all relevant validation

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| TBL-001 | Consistent column count across all rows | Error | No |
| TBL-002 | Header separator row exists (second row with `---`) | Error | Yes |
| TBL-003 | Separator has at least 3 dashes per column | Error | Yes |
| TBL-004 | All rows start with pipe `\|` | Error | Yes |
| TBL-005 | All rows end with pipe `\|` | Error | Yes |
| TBL-006 | Valid alignment markers (`:---`, `:---:`, `---:`) | Error | No |
| TBL-007 | No tabs within cells (use spaces) | Warning | Yes |
| TBL-008 | Empty cells contain at least one space | Warning | Yes |
| TBL-009 | No trailing whitespace in cells | Info | Yes |
| TBL-010 | No multi-line content within single cell | Error | No |

**Table Detection Pattern:**
```regex
^\|.*\|$
```

**Validation Logic:**
1. Find consecutive lines matching table pattern
2. Count columns in first row (header)
3. Verify second row is separator with `---`
4. Check each subsequent row has same column count
5. Validate cell content for tabs, empty cells, whitespace

---

### Phase 4: List Validation

Apply these rules to each table found:
goto https://pandoc.org/MANUAL.html#pandocs-markdown and apply all relevant validation

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| LST-001 | Consistent unordered list markers (`-`, `*`, or `+`) | Warning | Yes |
| LST-002 | Valid ordered list numbering (1., 2., or all 1.) | Error | Yes |
| LST-003 | Nested items use 4-space indentation | Warning | Yes |
| LST-004 | No mixed list types at same indentation level | Error | No |
| LST-005 | Blank line before list start | Warning | Yes |
| LST-006 | Blank line after list end | Warning | Yes |
| LST-007 | Continuation content properly indented | Error | No |

**List Detection Patterns:**
```regex
Unordered: ^(\s*)[-*+]\s+
Ordered: ^(\s*)\d+\.\s+
```

**Validation Logic:**
1. Identify list blocks (consecutive list items)
2. Track indentation levels and markers used
3. Verify consistent marker usage within same list
4. Check for blank lines before/after list blocks

---

### Phase 5: Heading Validation

Apply these rules to each table found:
goto https://pandoc.org/MANUAL.html#pandocs-markdown and apply all relevant validation

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| HDG-001 | Space after `#` characters | Error | Yes |
| HDG-002 | No skipped heading levels (H1 -> H3 without H2) | Warning | No |
| HDG-003 | Document starts with H1 heading | Info | No |
| HDG-004 | No duplicate heading text at same level | Warning | No |
| HDG-005 | Use ATX style (`#`) not Setext (underlines) | Info | Yes |
| HDG-006 | No trailing `#` characters | Info | Yes |

**Heading Detection Pattern:**
```regex
ATX: ^(#{1,6})\s*(.+?)(?:\s*#+)?$
Setext H1: ^(.+)\n={2,}$
Setext H2: ^(.+)\n-{2,}$
```

**Validation Logic:**
1. Find all headings and record their levels
2. Build heading hierarchy to detect skipped levels
3. Track heading text to find duplicates
4. Check for proper spacing and style

---

### Phase 6: Code Block Validation

Apply these rules to each code block:

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| CBL-001 | Matching opening and closing fence markers | Error | No |
| CBL-002 | Fence markers have at least 3 characters | Error | Yes |
| CBL-003 | Language identifier present after opening fence | Info | No |
| CBL-004 | Blank line before code block | Warning | Yes |
| CBL-005 | Blank line after code block | Warning | Yes |
| CBL-006 | No mixed fenced and indented code styles | Warning | No |

**Code Block Detection Pattern:**
```regex
Fenced: ^(`{3,}|~{3,})(\w*)$
Indented: ^(\s{4}|\t)
```

**Validation Logic:**
1. Find opening fences and match with closing fences
2. Verify fence character count matches
3. Check for language identifier
4. Verify surrounding blank lines

---

### Phase 7: Block Element Spacing Validation

This phase ensures all block elements have proper blank lines above and below them for correct pandoc rendering. **This is critical for pandoc compatibility** - block elements without proper spacing may render incorrectly or merge with surrounding content.

#### Block Spacing Rules (SPC-001 to SPC-006)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| SPC-001 | Tables have blank line above | Error | Yes |
| SPC-002 | Tables have blank line below | Error | Yes |
| SPC-003 | Bulleted lists have blank line above | Error | Yes |
| SPC-004 | Bulleted lists have blank line below | Error | Yes |
| SPC-005 | Ordered lists have blank line above | Error | Yes |
| SPC-006 | Ordered lists have blank line below | Error | Yes |
| SPC-007 | Images have blank line above | Warning | Yes |
| SPC-008 | Images have blank line below | Warning | Yes |
| SPC-009 | Block quotes have blank line above | Warning | Yes |
| SPC-010 | Block quotes have blank line below | Warning | Yes |
| SPC-011 | Bold label has blank line before following table | Error | Yes |
| SPC-012 | Bold label has blank line before following bullet list | Error | Yes |
| SPC-013 | Bold label followed by appropriate blank line before block elements | Error | Yes |

**Block Element Detection Patterns:**
```regex
Table row: ^\|.*\|$
Bulleted list: ^(\s*)[-*+]\s+
Ordered list: ^(\s*)\d+\.\s+
Image: ^!\[.*\]\(.*\)$
Block quote: ^>\s
```

**Special Pattern: Bold Label Immediately Before Table (SPC-011)**

A common documentation pattern that violates pandoc spacing rules is a bold label followed immediately by a table:

```markdown
# BAD - Bold label directly followed by table
**Data Fields:**
| Field Name | Type | Required |
|-----------|------|----------|
| id | Number | Yes |

# GOOD - Blank line between label and table
**Data Fields:**

| Field Name | Type | Required |
|-----------|------|----------|
| id | Number | Yes |
```

**Detection Pattern for Bold-Label-Before-Table:**
```regex
^\*\*[^*]+\*\*:?\s*$   <- Bold label line (ends with ** or **:)
^\|.*\|$               <- Immediately followed by table row
```

**Why This Matters:**
- This pattern is common in technical documentation (API docs, data schemas)
- Labels like `**Data Fields:**`, `**API Endpoints:**`, `**Entities:**`, `**User Roles:**` often precede tables
- Pandoc requires a blank line between any text and a table
- Without the blank line, the table may not render correctly

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| SPC-011 | Bold label has blank line before table | Error | Yes |

**Special Pattern: Bold Label Immediately Before Bullet List (SPC-012)**

Another common documentation pattern is a bold label followed immediately by a bullet list:

```markdown
# BAD - Bold label directly followed by bullet list
**In Scope:**
- Feature one
- Feature two
- Feature three

# GOOD - Blank line between label and bullet list
**In Scope:**

- Feature one
- Feature two
- Feature three
```

**Detection Pattern for Bold-Label-Before-Bullet-List:**
```regex
^\*\*[^*]+\*\*:?\s*$   <- Bold label line (ends with ** or **:)
^[-*+]\s+              <- Immediately followed by bullet list item
```

**Why This Matters:**
- This pattern is extremely common in technical documentation (BRDs, FRDs, requirement documents)
- Labels like `**In Scope:**`, `**Assumptions:**`, `**Constraints:**`, `**Primary Objectives:**` often precede bullet lists
- Pandoc requires a blank line between any text and a list
- Without the blank line, the list may merge with the label or render incorrectly

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| SPC-012 | Bold label has blank line before bullet list | Error | Yes |

**General Bold Label Validation Pattern (SPC-013)**

This rule provides comprehensive validation for ALL bold labels matching the pattern `**[.*]:**` (or `**[.*]**`). It ensures that whenever a bold label is immediately followed by any block element (table, list, code block, image, heading, or even another bold label), there must be a blank line between them.

**Detection Pattern for Bold Labels:**
```regex
^\*\*[^*]+\*\*:?\s*$   <- Bold label line (any text between ** with optional trailing : or **)
```

**Block Elements That Require Blank Line After Bold Label:**
- Tables: `^\|.*\|$`
- Unordered lists: `^[-*+]\s+`
- Ordered lists: `^\d+\.\s+`
- Code blocks: `^(`{3,}|~{3,})`
- Images: `^!\[.*\]\(.*\)$`
- Headings: `^#{1,6}\s+`
- Horizontal rules: `^(---|===|___)$`
- Block quotes: `^>\s`
- Other bold labels: `^\*\*[^*]+\*\*:?\s*$`

**Why This General Rule Matters:**
- Consolidates validation for the most common markdown documentation pattern
- Labels like `**Parameters:**`, `**Response (200):**`, `**Data Fields:**`, `**API Endpoints:**`, etc. appear extensively in technical documentation
- Ensures consistent spacing throughout the document for better readability and pandoc compatibility
- Prevents accidental merging or misformatting when bold labels precede structured content

**Examples of Issues Caught by SPC-013:**

```markdown
# Bad - Multiple violations
**Parameters:**
| Name | Type | Required |
|------|------|----------|
| id | int | Yes |

**Response:**
```json
{
  "status": "success"
}
```

# Good - All bold labels properly spaced
**Parameters:**

| Name | Type | Required |
|------|------|----------|
| id | int | Yes |

**Response:**

```json
{
  "status": "success"
}
```
```

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| SPC-013 | Bold label followed by appropriate blank line | Error | Yes |

**Validation Logic:**
1. Scan document line by line
2. For each block element type:
   - Identify the **first line** of a block (start of table, first list item, standalone image)
   - Identify the **last line** of a block (last table row, last list item)
   - Check if line immediately **before** the first line is blank (empty or whitespace-only)
   - Check if line immediately **after** the last line is blank (empty or whitespace-only)
3. **Special check for bold-label-before-table pattern (SPC-011):**
   - If line before table matches `^\*\*[^*]+\*\*:?\s*$` (bold label)
   - This is NOT a valid blank line - report SPC-011 violation
   - The bold label itself is valid, but needs blank line between it and table
4. **Special check for bold-label-before-bullet-list pattern (SPC-012):**
   - If line before bullet list matches `^\*\*[^*]+\*\*:?\s*$` (bold label)
   - This is NOT a valid blank line - report SPC-012 violation
   - The bold label itself is valid, but needs blank line between it and bullet list
5. **General bold label validation (SPC-013):**
   - Scan for all lines matching pattern `^\*\*[^*]+\*\*:?\s*$` (bold label format like `**Label:**`)
   - Check if the next non-empty line is appropriately spaced:
     - If next line is a table, list, code block, image, or heading - requires blank line (SPC-011/SPC-012)
     - If next line is regular text - blank line is optional but recommended for readability
   - Report SPC-013 for any bold label NOT followed by appropriate blank line when block element follows
6. Exceptions:
   - First line of document doesn't need blank line above
   - Last line of document doesn't need blank line below
   - Consecutive blocks of same type (e.g., nested lists) share boundaries
   - Block elements immediately after headings need blank line between heading and block

**Example Issues:**

```markdown
# Bad - No spacing around table
Some text here
| Header | Header |
|--------|--------|
| Cell   | Cell   |
More text here

# Good - Proper spacing
Some text here

| Header | Header |
|--------|--------|
| Cell   | Cell   |

More text here
```

```markdown
# Bad - No spacing around list
This is some text
- Item 1
- Item 2
This continues text

# Good - Proper spacing
This is some text

- Item 1
- Item 2

This continues text
```

```markdown
# Bad - Image without spacing
Here is a description
![Alt text](image.png)
Caption below image

# Good - Image with proper spacing
Here is a description

![Alt text](image.png)

Caption below image
```

---

### Phase 9: Other Element Validation

#### Horizontal Rules (HRZ-001 to HRZ-002)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| HRZ-001 | Valid syntax (`---`, `***`, or `___`) | Error | Yes |
| HRZ-002 | Blank lines before and after | Warning | Yes |

#### Links (LNK-001 to LNK-003)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| LNK-001 | Valid inline link syntax `[text](url)` | Error | No |
| LNK-002 | Reference links have matching definitions | Error | No |
| LNK-003 | No empty link text or URLs | Warning | No |

#### Images (IMG-001 to IMG-003)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| IMG-001 | Valid image syntax `![alt](path)` | Error | No |
| IMG-002 | Alt text is provided | Info | No |
| IMG-003 | Standalone images on their own line | Warning | Yes |

#### Emphasis (EMP-001 to EMP-002)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| EMP-001 | Matched `**bold**` pairs | Error | No |
| EMP-002 | Matched `*italic*` pairs | Error | No |

#### Inline Code (INC-001)

| Rule ID | Check | Severity | Auto-Fix |
|---------|-------|----------|----------|
| INC-001 | Matched backtick pairs for inline code | Error | No |

---

### Phase 10: Score Calculation

Calculate validation score using this formula:

```
Score = max(0, 100 - (errors × 10) - (warnings × 3) - (info × 1))
```

**Rating Thresholds:**
- **PASS** (Score >= 70): Document is pandoc-ready
- **WARN** (Score 50-69): Document may have conversion issues
- **FAIL** (Score < 50): Document needs significant fixes

---

### Phase 11: Report Generation

Generate a comprehensive console report with this structure:

```markdown
# Markdown Validation Report

**File:** {FILE_PATH}
**Date:** {CURRENT_DATE}
**Mode:** {Validation | Auto-Fix}

---

## Summary

| Metric | Value |
|--------|-------|
| **Score** | {SCORE}/100 |
| **Rating** | {PASS/WARN/FAIL} |
| **Total Issues** | {COUNT} |
| **Errors** | {ERROR_COUNT} |
| **Warnings** | {WARNING_COUNT} |
| **Info** | {INFO_COUNT} |

### Issues by Category

| Category | Errors | Warnings | Info |
|----------|--------|----------|------|
| Tables | {n} | {n} | {n} |
| Lists | {n} | {n} | {n} |
| Headings | {n} | {n} | {n} |
| Code Blocks | {n} | {n} | {n} |
| Block Spacing | {n} | {n} | {n} |
| Other | {n} | {n} | {n} |

---

## Section Analysis

### {Section Heading}
**Lines:** {startLine}-{endLine}

| Line | Rule | Severity | Issue | Suggestion |
|------|------|----------|-------|------------|
| {n} | TBL-001 | Error | Column count mismatch | Add/remove columns |
| {n} | LST-003 | Warning | 2-space indent | Use 4-space indent |

---

## Detailed Issues

### Table Issues
{List all table issues with full context}

### List Issues
{List all list issues with full context}

### Heading Issues
{List all heading issues with full context}

### Code Block Issues
{List all code block issues with full context}

### Block Spacing Issues
{List all block spacing issues - tables, lists, images without proper blank lines}

### Other Issues
{List all other issues with full context}

---

## Recommendations

1. {Prioritized recommendation based on most common issues}
2. {Second recommendation}
3. {Third recommendation}

---

## Auto-Fix Available

The following issues can be automatically fixed with `--auto-fix`:
- {Count} table formatting issues
- {Count} list indentation issues
- {Count} heading style issues
- {Count} code block spacing issues
- {Count} block spacing issues (tables, lists, images without blank lines)

Run: `/validate-markdown {FILE_PATH} --auto-fix`
```

---

### Phase 12: Auto-Fix Mode

When `--auto-fix` flag is present:

#### Step 1: Create Backup
```bash
cp {FILE_PATH} {FILE_PATH}.backup.md
```

#### Step 2: Apply Safe Fixes

Only apply fixes marked as "Auto-Fix: Yes" in the rules tables:

**Table Fixes:**
- TBL-002: Add separator row if missing
- TBL-003: Extend separators to 3+ dashes
- TBL-004: Add leading pipe to rows
- TBL-005: Add trailing pipe to rows
- TBL-007: Replace tabs with spaces
- TBL-008: Add space to empty cells
- TBL-009: Trim trailing whitespace

**List Fixes:**
- LST-001: Normalize to `-` for unordered lists
- LST-002: Renumber ordered lists sequentially
- LST-003: Adjust to 4-space indentation
- LST-005: Add blank line before list
- LST-006: Add blank line after list

**Heading Fixes:**
- HDG-001: Add space after `#`
- HDG-005: Convert Setext to ATX style
- HDG-006: Remove trailing `#`

**Code Block Fixes:**
- CBL-002: Extend fence to 3 characters
- CBL-004: Add blank line before block
- CBL-005: Add blank line after block

**Block Spacing Fixes:**
- SPC-001: Add blank line above tables
- SPC-002: Add blank line below tables
- SPC-003: Add blank line above bulleted lists
- SPC-004: Add blank line below bulleted lists
- SPC-005: Add blank line above ordered lists
- SPC-006: Add blank line below ordered lists
- SPC-007: Add blank line above images
- SPC-008: Add blank line below images
- SPC-009: Add blank line above block quotes
- SPC-010: Add blank line below block quotes
- SPC-011: Add blank line between bold label and following table
- SPC-012: Add blank line between bold label and following bullet list
- SPC-013: Add blank line between bold label and any following block element

**Other Fixes:**
- HRZ-001: Normalize to `---`
- HRZ-002: Add surrounding blank lines
- IMG-003: Move inline images to their own line

#### Step 3: Write Fixed File

Write the corrected content back to `{FILE_PATH}`.

#### Step 4: Generate Fix Report

```markdown
## Auto-Fix Report

**Backup Created:** {FILE_PATH}.backup.md

### Changes Applied

| Line | Rule | Change |
|------|------|--------|
| 15 | TBL-004 | Added leading pipe |
| 23 | LST-003 | Changed 2-space to 4-space indent |
| 45 | HDG-001 | Added space after # |

**Total Changes:** {COUNT}

### Skipped Issues

The following issues require manual review:
| Line | Rule | Reason |
|------|------|--------|
| 30 | TBL-001 | Column count mismatch needs context |
| 55 | EMP-001 | Unmatched emphasis ambiguous |

### Diff Preview

{Show before/after for first 5 changes}
```

---

## Example Usage

### Basic Validation
```
/validate-markdown Documents/Modules/Crons.md
```

### With Auto-Fix
```
/validate-markdown Documents/BRD/HR_BRD.md --auto-fix
```

### Integration with Document Generation
```
/brd HR
/validate-markdown Documents/BRD/HR_BRD.md --auto-fix
# Then convert with pandoc
```

---

## Common Issues and Fixes

### Table Column Mismatch (TBL-001)
**Problem:** Row has different number of columns than header
**Manual Fix:** Add or remove cells to match header count

### List Indentation (LST-003)
**Problem:** Nested items use 2 spaces instead of 4
**Auto-Fix:** Converts `  -` to `    -`

### Skipped Heading Level (HDG-002)
**Problem:** H1 followed by H3 without H2
**Manual Fix:** Add intermediate heading or adjust levels

### Unmatched Fences (CBL-001)
**Problem:** Opening fence without matching close
**Manual Fix:** Add closing fence with same character count

### Missing Block Spacing (SPC-001 to SPC-010)
**Problem:** Tables, lists, or images don't have blank lines before/after them
**Why it matters:** Pandoc requires blank lines around block elements to parse them correctly. Without spacing:
- Tables may render as plain text
- Lists may merge with surrounding paragraphs
- Images may appear inline instead of as figures

**Auto-Fix:** Inserts blank lines above and below the block element

**Examples of common issues:**
```markdown
# BAD - Table immediately after text
Here is the data:
| Col 1 | Col 2 |
|-------|-------|
| A     | B     |

# GOOD - Table with blank lines
Here is the data:

| Col 1 | Col 2 |
|-------|-------|
| A     | B     |

```

```markdown
# BAD - List stuck to text
The items are:
- First item
- Second item
Continue reading...

# GOOD - List with proper spacing
The items are:

- First item
- Second item

Continue reading...
```

### Bold Label Followed by Table (SPC-011)
**Problem:** A bold label like `**Data Fields:**` is immediately followed by a table without a blank line
**Why it matters:** This is a very common pattern in technical documentation (API docs, data schemas, FRDs) where labels like:
- `**Data Fields:**`
- `**API Endpoints:**`
- `**Entities:**`
- `**User Roles:**`
- `**Use Cases:**`

are followed directly by tables. Pandoc requires a blank line between any text content and a table.

**Auto-Fix:** Inserts a blank line between the bold label and the table

**Examples of common issues:**
```markdown
# BAD - Bold label directly before table
**API Endpoints:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/users | Get users |

# GOOD - Blank line after bold label
**API Endpoints:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/users | Get users |
```

```markdown
# BAD - Data fields label directly before table
**Data Fields:**
| Field Name | Type | Required |
|-----------|------|----------|
| id | Number | Yes |

# GOOD - Blank line after data fields label
**Data Fields:**

| Field Name | Type | Required |
|-----------|------|----------|
| id | Number | Yes |
```

### Bold Label Followed by Bullet List (SPC-012)
**Problem:** A bold label like `**In Scope:**` is immediately followed by a bullet list without a blank line
**Why it matters:** This is an extremely common pattern in technical documentation (BRDs, FRDs, requirement documents) where labels like:
- `**In Scope:**`
- `**Out of Scope:**`
- `**Assumptions:**`
- `**Constraints:**`
- `**Primary Objectives:**`
- `**Secondary Objectives:**`
- `**Success Criteria:**`

are followed directly by bullet lists. Pandoc requires a blank line between any text content and a list.

**Auto-Fix:** Inserts a blank line between the bold label and the bullet list

**Examples of common issues:**
```markdown
# BAD - Bold label directly before bullet list
**In Scope:**
- Employee attendance report generation
- Multi-criteria filtering
- Excel export functionality

# GOOD - Blank line after bold label
**In Scope:**

- Employee attendance report generation
- Multi-criteria filtering
- Excel export functionality
```

```markdown
# BAD - Assumptions label directly before bullet list
**Assumptions:**
- Users have valid authentication credentials
- Attendance data is already captured
- Time zones are standardized to IST

# GOOD - Blank line after assumptions label
**Assumptions:**

- Users have valid authentication credentials
- Attendance data is already captured
- Time zones are standardized to IST
```

### General Bold Label Spacing Validation (SPC-013)
**Problem:** Any bold label matching the pattern `**[.*]:**` is not followed by a blank line before block elements (tables, lists, code blocks, images, headings, etc.)

**Why it matters:** This is the most common documentation pattern across all technical specifications. Bold labels are used extensively to introduce sections with structured content. Without proper spacing:
- Content may render incorrectly in pandoc conversion
- Document structure and readability may be compromised
- API documentation, data schemas, and requirement documents all rely on this pattern

**Comprehensive List of Common Bold Labels:**
- API/Request/Response labels: `**Response (200):**`, `**Request Body:**`, `**Response (400):**`, `**Parameters:**`
- Data structure labels: `**Data Fields:**`, `**Entities:**`, `**Database Schema:**`, `**Field Mapping:**`
- Business rule labels: `**Business Rules:**`, `**Validation Rules:**`, `**Edge Cases:**`, `**Special Cases:**`
- Requirement labels: `**Acceptance Criteria:**`, `**Components:**`, `**User Actions:**`, `**Form Fields:**`
- Documentation labels: `**Displayed Information:**`, `**Table Columns:**`, `**Features:**`, `**Behavior:**`

**Auto-Fix:** Automatically inserts a blank line between any bold label and the following block element

**Example of comprehensive bold label issues:**
```markdown
# BAD - Multiple bold labels without proper spacing
**Parameters:**
| Name | Type | Required |
|------|------|----------|
| id | int | Yes |
**Response (200):**
```json
{
  "status": "success"
}
```
**Acceptance Criteria:**
- Requirement one
- Requirement two
**Expected Excel Headers:**
| Column | Type |
|--------|------|
| Name | Text |

# GOOD - All bold labels properly spaced
**Parameters:**

| Name | Type | Required |
|------|------|----------|
| id | int | Yes |

**Response (200):**

```json
{
  "status": "success"
}
```

**Acceptance Criteria:**

- Requirement one
- Requirement two

**Expected Excel Headers:**

| Column | Type |
|--------|------|
| Name | Text |
```

**Recommended Practice:**
Always add a blank line after any bold label that precedes a block element. This ensures:
1. Consistent document formatting
2. Proper pandoc conversion
3. Better readability in both source and rendered formats
4. Professional appearance in generated documentation

---

## Notes

- This skill validates against pandoc's strict markdown requirements
- Some rules are informational and don't affect conversion
- Always review auto-fix changes before committing
- Backup files are created to prevent data loss
- Run validation after any document generation skill
