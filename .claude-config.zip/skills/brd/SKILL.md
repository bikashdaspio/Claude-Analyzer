---
name: brd
argument-hint: MODULE_NAME
description: Generate a comprehensive Business Requirement Document (BRD) for the specified module following the standard template.
tags: [documentation, business-requirements, analysis]
---

# Business Requirement Document (BRD) Generator

**Arguments:** $ARGUMENTS (Module name, e.g., "Leaves", "Grievances", "KPI")

## Purpose
Generate a comprehensive Business Requirement Document for the specified module, following the exact structure from `templates/Business Requirement Document (BRD) - Template.docx`.

## Output
- **Location:** `Documents/BRD/{ModuleName}_BRD.md`
- **Format:** Markdown (.md)

---

## Workflow

### Step 0: Screenshot Requirement Gate (ABSOLUTE PREREQUISITE)

> **HARD STOP - THIS GATE MUST PASS BEFORE ANY FURTHER STEPS**
>
> **The BRD skill CANNOT proceed without screenshots of the application.**
> **This is a NON-NEGOTIABLE requirement. No exceptions. No workarounds.**

#### Gate Validation Checklist

Before proceeding to Step 1, you MUST verify ONE of the following conditions is met:

| Condition | How to Verify | Action if Failed |
|-----------|---------------|------------------|
| **Option A:** User has provided screenshots | Check if user attached images in the conversation or specified a path to existing screenshots | Request user to provide screenshots |
| **Option B:** Application is accessible for live capture | Verify `APPLICATION_URL` env variable is set AND application responds | Request user to start the application or provide screenshots manually |

#### Gate Validation Process

```
EXECUTE GATE CHECK:

1. CHECK for user-provided screenshots:
   - Look for image attachments in the conversation
   - Look for user-specified screenshot directory path
   - IF FOUND → GATE PASSED → Proceed to Step 1

2. IF no user-provided screenshots, CHECK application accessibility:
   - Verify APPLICATION_URL environment variable exists
   - Attempt to access the application URL
   - IF ACCESSIBLE → GATE PASSED (will capture in Step 3) → Proceed to Step 1
   - IF NOT ACCESSIBLE → GATE FAILED

3. IF GATE FAILED:
   ╔════════════════════════════════════════════════════════════════════╗
   ║  BRD GENERATION HALTED - SCREENSHOT REQUIREMENT NOT MET            ║
   ╠════════════════════════════════════════════════════════════════════╣
   ║                                                                    ║
   ║  The BRD skill CANNOT proceed without screenshots.                 ║
   ║                                                                    ║
   ║  Please resolve by ONE of these methods:                           ║
   ║                                                                    ║
   ║  1. PROVIDE SCREENSHOTS MANUALLY:                                  ║
   ║     - Attach screenshots of the module's UI screens                ║
   ║     - OR specify path to existing screenshots directory            ║
   ║                                                                    ║
   ║  2. MAKE APPLICATION ACCESSIBLE:                                   ║
   ║     - Start the application locally                                ║
   ║     - Ensure APPLICATION_URL env variable is set                   ║
   ║     - Ensure credentials_email and credentials_password are set    ║
   ║                                                                    ║
   ║  Once resolved, run the /brd skill again.                          ║
   ║                                                                    ║
   ╚════════════════════════════════════════════════════════════════════╝

   → OUTPUT THIS ERROR MESSAGE
   → TERMINATE SKILL EXECUTION
   → DO NOT PROCEED TO ANY FURTHER STEPS
```

#### Why This Requirement Exists

- BRDs without visual documentation are incomplete and unusable
- Screenshots provide critical context for:
  - UI field mapping and layouts
  - Navigation flows and user journeys
  - Actual data formats and display patterns
  - Button placements and action triggers
- Code analysis alone cannot capture the full user experience
- Stakeholders require visual references for requirement validation

---

### Step 1: Parse Module Argument & Detect Technology Stack
1. Extract the MODULE_NAME from $ARGUMENTS
2. Set output path: `Documents/BRD/{ModuleName}_BRD.md`
3. Create output directory if needed using Bash: `mkdir -p Documents/BRD`
4. **Detect technology stack** (see Technology Detection section below)

### Step 2: Analyze Module Codebase
Use the **Explore agent** to gather comprehensive information about the module.

**IMPORTANT:** Use the appropriate search patterns based on the detected technology stack.

#### 2.1 Frontend Analysis

**First, detect the frontend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.frontend`
2. Otherwise, detect from project files:
   - Vue.js: `*.vue` files exist or `vite.config.*` with vue
   - React: `package.json` contains "react" dependency
   - Angular: `angular.json` exists
   - Next.js: `next.config.*` exists
   - Svelte: `svelte.config.*` exists

**Then use appropriate patterns based on detected frontend:**

| Stack | Page Patterns | Component Patterns | Store/State Patterns |
|-------|--------------|-------------------|----------------------|
| Vue.js | `**/pages/**/*{MODULE}*.vue`, `**/views/**/*{MODULE}*.vue` | `**/components/**/*{MODULE}*.vue` | `**/stores/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| React | `**/pages/**/*{MODULE}*.tsx`, `**/pages/**/*{MODULE}*.jsx` | `**/components/**/*{MODULE}*.tsx` | `**/store/**/*{MODULE}*.ts`, `**/redux/**/*{MODULE}*.ts` |
| Angular | `**/*{MODULE}*.component.ts` | `**/components/**/*{MODULE}*.ts` | `**/services/**/*{MODULE}*.service.ts` |
| Next.js | `**/app/**/*{MODULE}*/page.tsx`, `**/pages/**/*{MODULE}*.tsx` | `**/components/**/*{MODULE}*.tsx` | `**/lib/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| Svelte | `**/routes/**/*{MODULE}*.svelte` | `**/components/**/*{MODULE}*.svelte` | `**/stores/**/*{MODULE}*.ts` |
| Generic | `**/pages/**/*{MODULE}*.*`, `**/views/**/*{MODULE}*.*` | `**/components/**/*{MODULE}*.*` | `**/store*/**/*{MODULE}*.*` |

Extract:
- All screens and navigation paths
- Form fields with validations
- User interactions (buttons, actions)
- Data display formats (tables, cards, lists)

#### 2.2 Backend Analysis

**First, detect the backend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.backend`
2. Otherwise, detect from project files:
   - .NET (C#): `*.csproj` or `*.sln` files exist
   - Node.js/Express: `package.json` with express/fastify/nestjs
   - Spring Boot: `pom.xml` or `build.gradle` with Spring
   - Django: `requirements.txt` or `pyproject.toml` with django
   - FastAPI: `requirements.txt` with fastapi
   - Go: `go.mod` exists
   - Ruby on Rails: `Gemfile` with rails

**Then use appropriate patterns based on detected backend:**

| Stack | Controllers/Handlers | Services/Logic | DTOs/Models | Entities |
|-------|---------------------|----------------|-------------|----------|
| .NET (C#) | `**/Controllers/*{MODULE}*.cs` | `**/Services/*{MODULE}*.cs` | `**/DTOs/*{MODULE}*.cs`, `**/Models/*{MODULE}*.cs` | `**/Entities/*{MODULE}*.cs` |
| Node.js/Express | `**/routes/*{MODULE}*.ts`, `**/routes/*{MODULE}*.js` | `**/services/*{MODULE}*.ts` | `**/models/*{MODULE}*.ts`, `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.ts` |
| NestJS | `**/*{MODULE}*.controller.ts` | `**/*{MODULE}*.service.ts` | `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.entity.ts` |
| Spring Boot | `**/controller/*{MODULE}*.java` | `**/service/*{MODULE}*.java` | `**/dto/*{MODULE}*.java` | `**/entity/*{MODULE}*.java`, `**/model/*{MODULE}*.java` |
| Django | `**/views/*{MODULE}*.py`, `**/*{MODULE}*/views.py` | `**/services/*{MODULE}*.py` | `**/serializers/*{MODULE}*.py` | `**/models/*{MODULE}*.py`, `**/*{MODULE}*/models.py` |
| FastAPI | `**/routers/*{MODULE}*.py`, `**/routes/*{MODULE}*.py` | `**/services/*{MODULE}*.py` | `**/schemas/*{MODULE}*.py` | `**/models/*{MODULE}*.py` |
| Go | `**/handlers/*{MODULE}*.go`, `**/controllers/*{MODULE}*.go` | `**/services/*{MODULE}*.go` | `**/dto/*{MODULE}*.go`, `**/models/*{MODULE}*.go` | `**/entities/*{MODULE}*.go` |
| Ruby on Rails | `**/controllers/*{MODULE}*.rb` | `**/services/*{MODULE}*.rb` | `**/serializers/*{MODULE}*.rb` | `**/models/*{MODULE}*.rb` |
| Generic | `**/{controllers,handlers,routes}/**/*{MODULE}*.*` | `**/services/**/*{MODULE}*.*` | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` | `**/entities/**/*{MODULE}*.*` |

Extract:
- API endpoints (GET, POST, PUT, DELETE)
- Request/response models
- Business rules and validations
- Database relationships

#### 2.3 Service Layer Analysis

Use patterns appropriate for the detected backend:

| Stack | Business Logic | Calculations | Workflows |
|-------|---------------|--------------|-----------|
| .NET (C#) | `**/Services/*{MODULE}*Service*.cs` | `**/*{MODULE}*Calculator*.cs` | `**/*{MODULE}*Workflow*.cs` |
| Node.js/Express | `**/services/*{MODULE}*.ts` | `**/*{MODULE}*calculator*.ts` | `**/*{MODULE}*workflow*.ts` |
| Spring Boot | `**/service/*{MODULE}*Service*.java` | `**/*{MODULE}*Calculator*.java` | `**/*{MODULE}*Workflow*.java` |
| Django/FastAPI | `**/services/*{MODULE}*.py` | `**/*{MODULE}*calculator*.py` | `**/*{MODULE}*workflow*.py` |
| Go | `**/services/*{MODULE}*.go` | `**/*{MODULE}*calculator*.go` | `**/*{MODULE}*workflow*.go` |
| Generic | `**/services/**/*{MODULE}*.*` | `**/*{MODULE}*calc*.*` | `**/*{MODULE}*workflow*.*` |

Extract:
- Business calculations
- Workflow steps
- Approval processes
- External integrations

### Step 3: Explore Live UI with Playwright - MANDATORY

> **CRITICAL: THIS STEP IS REQUIRED - DO NOT SKIP UNDER ANY CIRCUMSTANCES**
>
> UI exploration is **NON-NEGOTIABLE** and **MUST BE COMPLETED** before generating the BRD.
> The BRD cannot be accurate without visual verification of the actual application.
> **FAILURE TO COMPLETE THIS STEP WILL RESULT IN AN INCOMPLETE AND INVALID BRD.**

Use Playwright MCP tools to explore the live application:

**Pre-requisites (MUST verify before proceeding):**
- Ensure the application is running locally
- Analyze the repo and run the startup script specified in env variable `STARTUP_SCRIPT`

**REQUIRED Actions (ALL must be completed):**
1. Navigate to the application URL from env variable `APPLICATION_URL`
2. Login with credentials from env variables `credentials_email` and `credentials_password`
3. Navigate to the module's pages
4. **Take screenshots of ALL screens** related to the module
5. **Document navigation flow** and UI elements thoroughly
6. **Capture ALL form fields**, buttons, and actions
7. Log out, close browser, and stop servers using `STARTUP_SCRIPT`

> **DO NOT proceed to Step 4 until ALL UI screenshots are captured and documented.**

### Step 4: Generate BRD Document
Create the document with ALL sections matching the exact template structure.

---

## Technology Detection

### Automatic Detection Process

Before analyzing module code, detect the technology stack:

```
TECHNOLOGY DETECTION:

1. CHECK for module-structure.json at project root:
   IF EXISTS:
     - Read detectedStack.backend → use for backend patterns
     - Read detectedStack.frontend → use for frontend patterns
     - Read detectedStack.database → document in Technology section
     - Read detectedStack.languages → use for file extensions
     - SKIP further detection

2. IF module-structure.json NOT found, DETECT manually:

   BACKEND DETECTION:
   - Check for *.csproj or *.sln → .NET (C#)
   - Check package.json for express/fastify/nestjs → Node.js
   - Check pom.xml or build.gradle for Spring → Spring Boot
   - Check requirements.txt/pyproject.toml for django → Django
   - Check requirements.txt for fastapi → FastAPI
   - Check for go.mod → Go
   - Check Gemfile for rails → Ruby on Rails
   - Check composer.json for laravel → Laravel (PHP)

   FRONTEND DETECTION:
   - Check for *.vue files → Vue.js
   - Check for angular.json → Angular
   - Check package.json for react → React
   - Check for next.config.* → Next.js
   - Check for svelte.config.* → Svelte

   DATABASE DETECTION:
   - Parse connection strings in config files
   - Check for ORM indicators (EF Core, Prisma, TypeORM, etc.)

3. STORE detected stack for use in pattern selection
```

### Using Module Structure (When Available)

If `module-structure.json` exists and contains the module being documented:

```
1. Find the module entry in modules array by name
2. Use paths.backend for backend file locations
3. Use paths.frontend for frontend file locations
4. Use paths.shared for DTO/type locations
5. This provides precise paths instead of glob patterns
```

---

## Document Structure (Must Follow Exactly)

### Title Page & Metadata

```markdown
# BUSINESS REQUIREMENT DOCUMENT (BRD)

**PROGRAMMERS.IO INDIA PVT LTD.**

---

| Field | Value |
|-------|-------|
| **Client Name** | {Client name or "PROGRAMMERS.IO"} |
| **Project Name** | {Project name from module-structure.json or directory name} - {Module Name} Module |
| **Document Version** | 1.0 |
| **Author Name** | Business Analyst |
| **Date** | {Current date in DD/MM/YYYY format} |

---
```

### Version History Table

```markdown
## Version History

| Release Date | Version Number | Section/Page # Change | Change Details | Done By | Reviewed By |
|-------------|----------------|----------------------|----------------|---------|-------------|
| {Current date} | 1.0 | All | Initial draft | Business Analyst | Technical Lead |

---
```

### Section 1: Introduction

```markdown
## 1. Introduction

{Provide a quick overview of the BRD document contents and its purpose. Include key terms used throughout.}

### 1.1 Overview

{High-level description of the module derived from code analysis - what it does, who uses it, and why it exists.}

### 1.2 Problem Statement

{Define the specific problem this module addresses. Derive from:
- Business context of the module
- Pain points the module solves
- Current challenges addressed}

### 1.3 Project Objective

{Define the goals and objectives. List specific, measurable objectives derived from the module's functionality:
- Primary objective
- Secondary objectives
- Success criteria}

### 1.4 Project Scope

**In Scope:**
{List all features and functionalities that are part of this module, derived from code analysis:}
- Feature 1
- Feature 2
- ...

**Future Scope:**
{List features that could be added in future phases but are not part of current implementation:}
- Future feature 1
- Future feature 2
- ...

### 1.5 Assumptions and Constraints

**Assumptions:**
{List assumptions made during analysis:}
- Assumption 1
- Assumption 2
- ...

**Constraints:**
{List constraints and limitations:}
- Constraint 1
- Constraint 2
- ...

---
```

### Section 2: Definitions and Abbreviations

```markdown
## 2. Definitions and Abbreviations

| Term | Definition |
|------|------------|
| {Project-specific term} | {Definition based on detected technology} |
| {MODULE_ABBREV} | {Module full name} |
| {Term from code} | {Definition} |
| {Business term} | {Definition} |
| ... | ... |

---
```

### Section 3: Business Drivers

```markdown
## 3. Business Drivers

### Top Executives (Primary Stakeholders)
- {Role 1 - e.g., HR Director}
- {Role 2 - e.g., Department Managers}

### Secondary Stakeholders
- {Role 3 - e.g., Employees}
- {Role 4 - e.g., System Administrators}

---
```

### Section 4: Functional Requirements

```markdown
## 4. Functional Requirements

{This section comprises the detailed project requirements derived from code analysis.}

### 4.1 Feature Overview

{List all major features discovered in the module:}

| Feature ID | Feature Name | Description | Priority |
|-----------|--------------|-------------|----------|
| FR-{ABBREV}-001 | {Feature name} | {Description from code} | {Critical/High/Medium/Low} |
| FR-{ABBREV}-002 | {Feature name} | {Description from code} | {Priority} |
| ... | ... | ... | ... |

### 4.2 Detailed Requirements

#### FR-{ABBREV}-001: {Feature Name}

**Description:** {Detailed description}

**Business Rules:**
- Rule 1: {From service layer analysis}
- Rule 2: {From validation analysis}

**User Actions:**
- Action 1: {From UI analysis}
- Action 2: {From API endpoints}

**Data Fields:**
| Field Name | Type | Required | Validation | Description |
|-----------|------|----------|------------|-------------|
| {field} | {type} | Yes/No | {validation rules} | {description} |

**API Endpoints:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/{module}/... | {description} |
| POST | /api/{module}/... | {description} |

{Repeat for each feature}

### 4.3 Workflow Diagrams

{Describe the workflow steps. If screenshots were taken, reference them here.}

**Main Workflow:**
1. Step 1: {Action}
2. Step 2: {Action}
3. Step 3: {Action}

### 4.4 Wireframes/Designs

{Reference any screenshots or describe the UI layouts discovered:}
- Screen 1: {attach screenshot} {Description}
- Screen 2: {attach screenshot} {Description}

---
```

### Section 5: Non-Functional Requirements

```markdown
## 5. Non-Functional Requirements

### 5.1 Performance Requirements

| Requirement | Specification |
|------------|---------------|
| Page Load Time | < 3 seconds |
| API Response Time | < 500ms for standard operations |
| Concurrent Users | Support {N} concurrent users |
| Data Volume | Handle {N} records efficiently |

### 5.2 Usability Requirements

| Requirement | Specification |
|------------|---------------|
| Ease of Use | Intuitive interface with minimal training required |
| Accessibility | WCAG 2.1 AA compliance |
| Mobile Responsiveness | Responsive design for tablet and mobile |
| Navigation | Maximum 3 clicks to reach any feature |

### 5.3 Security Requirements

| Requirement | Specification |
|------------|---------------|
| Authentication | {From code analysis - JWT/OAuth/etc.} |
| Authorization | Role-based access control (RBAC) |
| Data Protection | Encryption at rest and in transit |
| Audit Trail | All critical actions logged |
| Session Management | {Session timeout, token expiry details} |

---
```

### Section 6: References

```markdown
## 6. References

| Reference Document Details | Location |
|---------------------------|----------|
| API Documentation | /docs/api |
| Database Schema | /docs/database |
| UI Design Mockups | /designs |
| {Other reference} | {Location} |

---
```

### Section 7: Priority

```markdown
## 7. Priority

| Level | Rating | Description |
|-------|--------|-------------|
| 1 | Critical | This requirement is imperative to the success of the project. |
| 2 | High | This requirement is of high priority, but the project can be implemented at a bare minimum without this requirement. |
| 3 | Medium | This requirement is somewhat important, as it provides some value but the project can proceed without it. |
| 4 | Low | This is a low-priority requirement, or a "nice to have" feature if time and cost allow it. |
| 5 | Future | This requirement is out of scope for this project and has been included here for a possible future release. |

---
```

### Section 8: Technology Used

```markdown
## 8. Technology Used

| S No. | Component | Technology |
|-------|-----------|------------|
| 1 | Back-end Technology | {From detectedStack or analysis} |
| 2 | Front-end Technology | {From detectedStack or analysis} |
| 3 | Database | {From detectedStack or analysis} |
| 4 | Authentication | {From analysis - e.g., JWT, OAuth 2.0} |
| 5 | API Style | {From analysis - e.g., RESTful API, GraphQL} |

> **Note:** If `module-structure.json` exists, populate from `detectedStack`. Otherwise, detect automatically from project configuration files.

---
```

---

## Step 5: Template Alignment Verification (MANDATORY)

> **CRITICAL: This step ensures 100% alignment with the DOCX template. Do NOT skip.**

### 5.1 Extract Template Structure

Use MCP tools to read the DOCX template:

1. Call `mcp__word-document-server__get_document_outline` with template path:
   `templates/Business Requirement Document (BRD) - Template.docx`

2. Extract and document:
   - All section headings with their levels
   - All tables with row/column counts
   - Content structure expectations

### 5.2 Compare Generated Document

Read the generated Markdown document and compare:

| Check | Template Expectation | Generated | Status |
|-------|---------------------|-----------|--------|
| Section Count | 16 sections | ? | PASS/FAIL |
| Table Count | 6 tables | ? | PASS/FAIL |
| Heading Hierarchy | H1→H2→H3 | ? | PASS/FAIL |

### 5.3 Section Alignment Verification

Verify ALL 16 sections are present with exact names:

| # | Expected Section | Found | Status |
|---|------------------|-------|--------|
| 1 | Title Page & Metadata | ? | PASS/FAIL |
| 2 | Version History | ? | PASS/FAIL |
| 3 | 1. Introduction | ? | PASS/FAIL |
| 4 | 1.1 Overview | ? | PASS/FAIL |
| 5 | 1.2 Problem Statement | ? | PASS/FAIL |
| 6 | 1.3 Project Objective | ? | PASS/FAIL |
| 7 | 1.4 Project Scope | ? | PASS/FAIL |
| 8 | 1.5 Assumptions and Constraints | ? | PASS/FAIL |
| 9 | 2. Definitions and Abbreviations | ? | PASS/FAIL |
| 10 | 3. Business Drivers | ? | PASS/FAIL |
| 11 | 4. Functional Requirements | ? | PASS/FAIL |
| 12 | 5. Non-Functional Requirements | ? | PASS/FAIL |
| 13 | 6. References | ? | PASS/FAIL |
| 14 | 7. Priority | ? | PASS/FAIL |
| 15 | 8. Technology Used | ? | PASS/FAIL |
| 16 | (Subsections of Section 4) | ? | PASS/FAIL |

### 5.4 Table Alignment Verification

Verify ALL 6 tables are present with correct structure:

| Table | Expected Structure | Found | Status |
|-------|-------------------|-------|--------|
| Metadata | 2 columns (Field, Value), 5+ rows | ? | PASS/FAIL |
| Version History | 6 columns (Release Date, Version Number, Section/Page # Change, Change Details, Done By, Reviewed By), 2+ rows | ? | PASS/FAIL |
| Definitions | 2 columns (Term, Definition), 2+ rows | ? | PASS/FAIL |
| References | 2 columns (Reference Document Details, Location), 2+ rows | ? | PASS/FAIL |
| Priority | 3 columns (Level, Rating, Description), 6 rows | ? | PASS/FAIL |
| Technology | 3 columns (S No., Component, Technology), 3+ rows | ? | PASS/FAIL |

### 5.5 Auto-Correction Loop

If alignment < 100%, execute corrections:

```
WHILE alignment_score < 100%:
    1. Identify first mismatch
    2. Apply correction:
       - Missing Section → Add section with exact template heading
       - Wrong Section Name → Rename to match template exactly
       - Missing Table → Add table with correct structure
       - Wrong Table Structure → Adjust columns/rows to match
       - Wrong Heading Level → Adjust markdown heading level
    3. Re-verify document
    4. Update alignment score

    MAX_ITERATIONS = 5
    IF iterations > MAX_ITERATIONS: Report remaining issues and proceed
```

### 5.6 Alignment Report

After verification, output:

```
## Template Alignment Results

**Template:** templates/Business Requirement Document (BRD) - Template.docx
**Document:** Documents/BRD/{ModuleName}_BRD.md
**Alignment Score:** {SCORE}%

### Summary
| Category | Expected | Found | Status |
|----------|----------|-------|--------|
| Sections | 16 | {N} | PASS/FAIL |
| Tables | 6 | {N} | PASS/FAIL |
| Heading Levels | H1/H2/H3 | {levels} | PASS/FAIL |

### Corrections Applied
- {List of corrections made, or "None required"}

### Status: ALIGNED / NEEDS MANUAL REVIEW
```

---

## Verification Checklist

Before completing, verify:
- [ ] **GATE CHECK PASSED: Screenshots were provided OR application was accessible**
- [ ] Document created at `Documents/BRD/{ModuleName}_BRD.md`
- [ ] Title page with metadata table (Client, Project, Version, Author, Date)
- [ ] Version History table (6 columns)
- [ ] Section 1: Introduction with all 5 subsections
- [ ] Section 2: Definitions table (2 columns)
- [ ] Section 3: Business Drivers with stakeholders
- [ ] Section 4: Functional Requirements with feature table and detailed requirements
- [ ] Section 5: Non-Functional Requirements (Performance, Usability, Security)
- [ ] Section 6: References table (2 columns)
- [ ] Section 7: Priority table (3 columns × 6 rows)
- [ ] Section 8: Technology table (3 columns)
- [ ] All content derived from actual code analysis, not generic placeholders
- [ ] Feature IDs follow convention: FR-{MODULE_ABBREV}-XXX
- [ ] Field names match actual implementation
- [ ] Business rules extracted from service layer
- [ ] **MANDATORY: UI exploration completed with Playwright**
- [ ] **MANDATORY: Screenshots captured for ALL module screens**
- [ ] **MANDATORY: UI exploration findings incorporated into document**

---

## Critical Source Files to Analyze

**The paths below are determined dynamically based on the detected technology stack.**

If `module-structure.json` exists, use the paths from the matching module entry.

Otherwise, use the Explore agent with these generic patterns:

| Purpose | Generic Pattern (adapts to detected stack) |
|---------|---------------------------------------------|
| Frontend pages | `**/{pages,views,app}/**/*{MODULE}*.*` |
| Frontend components | `**/components/**/*{MODULE}*.*` |
| Backend controllers/handlers | `**/{controllers,handlers,routes,routers}/**/*{MODULE}*.*` |
| Backend services | `**/services/**/*{MODULE}*.*` |
| DTOs/Models | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` |
| Entities | `**/{entities,models,domain}/**/*{MODULE}*.*` |
| Validations | `**/{validations,validators}/**/*{MODULE}*.*` |
| Stores/State | `**/{store,stores,redux,state}/**/*{MODULE}*.*` |

---

## Execution

Now analyze the module "$ARGUMENTS" and generate the complete Business Requirement Document:

0. **SCREENSHOT GATE CHECK (MANDATORY FIRST)** - Verify screenshots exist OR application is accessible. **IF GATE FAILS → HALT AND DISPLAY ERROR → DO NOT PROCEED**
1. **Parse arguments** - Extract MODULE_NAME from $ARGUMENTS
2. **Detect technology stack** - Check for module-structure.json or detect from project files
3. **Create directory** - Run `mkdir -p Documents/BRD`
4. **Run code analysis** - Use Explore agent with technology-appropriate patterns
5. **Analyze frontend** - Extract pages, components, forms, fields, actions
6. **Analyze backend** - Extract controllers, services, DTOs, entities
7. **Extract business rules** - From service layer and validations
8. **MANDATORY: Explore UI** - Use Playwright to capture screenshots and workflows **(DO NOT SKIP)**
9. **Generate document** - Use Write tool to create Markdown file
10. **Verify output** - Confirm all sections and tables present
11. **Final screenshot verification** - Ensure screenshots are embedded/referenced in the document

> **CRITICAL:** Step 0 is an ABSOLUTE GATE. If it fails, the entire skill execution MUST terminate with an error message. No code analysis, no document generation, nothing. The user must fix the screenshot/accessibility issue first.

> **IMPORTANT REMINDER:** Step 8 (UI Exploration) is **REQUIRED** and must be completed before generating the document. The BRD is considered incomplete and invalid without UI screenshots and workflow documentation from the live application.
