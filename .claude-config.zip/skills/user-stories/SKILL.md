---
name: user-stories
description: Generate a User Stories Document in markdown format for any module following the exact template structure.
tags: [documentation, user-stories, analysis]
---

# User Stories Document Generator

**Arguments:** $ARGUMENTS (Module name, e.g., "Leaves", "Grievances", "KPI")

## Purpose
Generate a comprehensive User Stories Document for the specified module, following the exact structure from `templates/USER STORIES DOCUMENT.docx`.

## Workflow

### Step 1: Parse Module Argument & Detect Technology Stack
- Extract the MODULE_NAME from $ARGUMENTS
- Generate MODULE_ABBREV for User Story IDs:
   use first 2-4 characters in uppercase
- **Detect technology stack** (see Technology Detection section below)

### Step 2: Analyze Module Codebase
Use the Explore agent to gather information about the module.

**IMPORTANT:** Use the appropriate search patterns based on the detected technology stack.

1. **Frontend Analysis:**

   **First, detect the frontend technology stack:**
   - Check if `module-structure.json` exists - if so, use `detectedStack.frontend`
   - Otherwise, detect from project files

   **Then use appropriate patterns:**
   | Stack | Page Patterns | Component Patterns |
   |-------|--------------|-------------------|
   | Vue.js | `**/pages/**/*{MODULE}*.vue` | `**/components/**/*{MODULE}*.vue` |
   | React | `**/pages/**/*{MODULE}*.tsx` | `**/components/**/*{MODULE}*.tsx` |
   | Angular | `**/*{MODULE}*.component.ts` | `**/components/**/*{MODULE}*.ts` |
   | Next.js | `**/app/**/*{MODULE}*/page.tsx` | `**/components/**/*{MODULE}*.tsx` |
   | Generic | `**/pages/**/*{MODULE}*.*` | `**/components/**/*{MODULE}*.*` |

   - Search for pages related to the module
   - Identify components, forms, tables, and UI elements
   - Extract field names, validations, and user interactions
   - Map navigation paths and screen flows

2. **Backend Analysis:**

   **First, detect the backend technology stack:**
   - Check if `module-structure.json` exists - if so, use `detectedStack.backend`
   - Otherwise, detect from project files

   **Then use appropriate patterns:**
   | Stack | Controllers | Services | DTOs/Models |
   |-------|------------|----------|-------------|
   | .NET (C#) | `**/Controllers/*{MODULE}*.cs` | `**/Services/*{MODULE}*.cs` | `**/DTOs/*{MODULE}*.cs` |
   | Node.js/Express | `**/routes/*{MODULE}*.ts` | `**/services/*{MODULE}*.ts` | `**/models/*{MODULE}*.ts` |
   | NestJS | `**/*{MODULE}*.controller.ts` | `**/*{MODULE}*.service.ts` | `**/dto/*{MODULE}*.ts` |
   | Spring Boot | `**/controller/*{MODULE}*.java` | `**/service/*{MODULE}*.java` | `**/dto/*{MODULE}*.java` |
   | Django | `**/views/*{MODULE}*.py` | `**/services/*{MODULE}*.py` | `**/serializers/*{MODULE}*.py` |
   | FastAPI | `**/routers/*{MODULE}*.py` | `**/services/*{MODULE}*.py` | `**/schemas/*{MODULE}*.py` |
   | Go | `**/handlers/*{MODULE}*.go` | `**/services/*{MODULE}*.go` | `**/models/*{MODULE}*.go` |
   | Generic | `**/{controllers,routes}/**/*{MODULE}*.*` | `**/services/**/*{MODULE}*.*` | `**/{dto,models}/**/*{MODULE}*.*` |

   - Identify API endpoints (GET, POST, PUT, DELETE)
   - Extract request/response models from DTOs
   - Identify business rules and validations

3. **Service Layer Analysis:**

   **Use patterns appropriate for the detected backend:**
   | Stack | Service Patterns |
   |-------|-----------------|
   | .NET (C#) | `**/Services/*{MODULE}*Service*.cs` |
   | Node.js/Express | `**/services/*{MODULE}*.ts` |
   | Spring Boot | `**/service/*{MODULE}*Service*.java` |
   | Django/FastAPI | `**/services/*{MODULE}*.py` |
   | Go | `**/services/*{MODULE}*.go` |
   | Generic | `**/services/**/*{MODULE}*.*` |

   - Identify business logic and calculations
   - Map dependencies and external integrations

### Step 3: Explore Live UI with Playwright
Use Playwright MCP tools to explore the live application:

But before exploring the live application, ensure the application is running locally.
Analyze the repo and run the startup script specified in the env variable `STARTUP_SCRIPT` to start both frontend and backend servers.

And then:
1. Navigate to the application URL from env variable `APPLICATION_URL`
2. Login with appropriate credentials defined in env variables `credentials_email` and `credentials_password`
3. Navigate to the module's pages
4. Take screenshots of key screens
5. Document navigation flow and UI elements
6. Capture form fields, buttons, and actions
7. Finally log out of the application and close the browser and stop the servers using the same script defined in `STARTUP_SCRIPT`

### Step 4: Generate User Stories Document
Create the document with ALL 11 sections matching the exact template:

---

## Technology Detection

### Automatic Detection Process

Before analyzing module code, detect the technology stack:

```
TECHNOLOGY DETECTION:

1. CHECK for module-structure.json at project root:
   IF EXISTS:
     - Read detectedStack.backend → use for backend patterns
     - Read detectedStack.frontend → use for frontend patterns
     - Read detectedStack.languages → use for file extensions
     - Read projectName → use for document metadata
     - SKIP further detection

2. IF module-structure.json NOT found, DETECT manually:

   BACKEND DETECTION:
   - Check for *.csproj or *.sln → .NET (C#)
   - Check package.json for express/fastify/nestjs → Node.js
   - Check pom.xml or build.gradle for Spring → Spring Boot
   - Check requirements.txt/pyproject.toml for django → Django
   - Check requirements.txt for fastapi → FastAPI
   - Check for go.mod → Go
   - Check Gemfile for rails → Ruby on Rails
   - Check composer.json for laravel → Laravel (PHP)

   FRONTEND DETECTION:
   - Check for *.vue files → Vue.js
   - Check for angular.json → Angular
   - Check package.json for react → React
   - Check for next.config.* → Next.js
   - Check for svelte.config.* → Svelte

3. STORE detected stack for use in pattern selection
```

### Using Module Structure (When Available)

If `module-structure.json` exists and contains the module being documented:

```
1. Find the module entry in modules array by name
2. Use paths.backend for backend file locations
3. Use paths.frontend for frontend file locations
4. Use paths.shared for DTO/type locations
5. This provides precise paths instead of glob patterns
```

---

## Output Format (MUST Follow Exactly)

```markdown
# USER STORIES DOCUMENT

**Project Name:** {Project name from module-structure.json or directory name}
**Module / Feature:** {Module Name from $ARGUMENTS}

---

## 1. User Story Details

**User Story ID:** US-{MODULE_ABBREV}-001
**User Story Title:** {Descriptive title based on main functionality}

**User Story Statement (INVEST Format)**
As a {type of user - HR Admin, Employee, Manager, etc.}
I want {specific goal derived from module analysis}
So that {business value/benefit}

---

## 2. Description

{High-level explanation of what this user story is about and why it is needed.
Derived from the module's purpose and functionality discovered during analysis.}

---

## 3. Acceptance Criteria (Given/When/Then Format)

**AC-1**
Given {precondition from the system state}
When {user action derived from UI analysis}
Then {expected result based on business rules}

**AC-2**
Given {another precondition}
When {another user action}
Then {expected result}

{Add more AC items based on the complexity of the module}

---

## 4. UI/UX Requirements

- **Screens involved:** {List all pages/screens discovered in frontend analysis}
- **Wireframes (if any):** {Reference to screenshots taken, or N/A}
- **Navigation details:** {Navigation flow from sidebar/menu to the module screens}

---

## 5. Business Rules

- **Rule 1:** {Business rule from backend/service analysis}
- **Rule 2:** {Validation rule from frontend/backend}
- **Rule 3:** {Calculation or constraint rule}
{Add more rules as discovered}

---

## 6. Data Requirements

- **Fields involved:** {List fields with their types from DTOs/forms}
- **Validation rules:** {Field-level validations discovered}
- **Backend data needs:** {API endpoints and database requirements}

---

## 7. Dependencies

- **Dependent modules:** {Other modules this module interacts with}
- **API dependencies:** {List of API endpoints used}
- **External systems:** {Any external integrations}

---

## 8. Assumptions

- {Assumptions made during analysis}
- {System state assumptions}
- {User role assumptions}
- {Any limitations discovered}

---

## 9. Non-Functional Requirements (If applicable)

- **Performance requirements:** {Based on data volume and operations}
- **Security requirements:** {Role-based access, data protection}
- **Availability:** {System availability expectations}
- **Load time expectations:** {Page load and response time expectations}

---

## 10. Test Scenarios / Test Notes

A high-level list of what QA needs to verify:
- {Test scenario for main functionality}
- {Test scenario for edge cases}
- {Test scenario for validations}
- {Test scenario for error handling}
- {Test scenario for permissions/roles}

---

## 11. Comments / Open Questions

- **Pending clarifications:** {Any unclear requirements discovered}
- **Questions for stakeholders:** {Business logic questions}
```

---

## User Story ID Convention
- Format: `US-{MODULE_ABBREV}-{SEQUENCE}`
- Start sequence at 001 for each module
- If multiple user stories are needed, create separate sections for each:
  - US-{ABBREV}-001, US-{ABBREV}-002, etc.

## Output Location
- Save the generated document to: `Documents/UserStories/{ModuleName}_UserStories.md`

---

## Step 5: Template Alignment Verification (MANDATORY)

> **CRITICAL: This step ensures 100% alignment with the DOCX template. Do NOT skip.**

### 5.1 Extract Template Structure

Use MCP tools to read the DOCX template:

1. Call `mcp__word-document-server__get_document_outline` with template path:
   `templates/USER STORIES DOCUMENT.docx`

2. Extract and document:
   - All section headings with their levels
   - Content structure expectations (no tables in this template)

### 5.2 Compare Generated Document

Read the generated Markdown document and compare:

| Check | Template Expectation | Generated | Status |
|-------|---------------------|-----------|--------|
| Section Count | 11 sections | ? | PASS/FAIL |
| Table Count | 0 tables | ? | PASS/FAIL |
| Heading Hierarchy | H1→H2→H3 | ? | PASS/FAIL |

### 5.3 Section Alignment Verification

Verify ALL 11 sections are present with exact names:

| # | Expected Section | Found | Status |
|---|------------------|-------|--------|
| 1 | Title & Metadata | ? | PASS/FAIL |
| 2 | 1. User Story Details | ? | PASS/FAIL |
| 3 | 2. Description | ? | PASS/FAIL |
| 4 | 3. Acceptance Criteria | ? | PASS/FAIL |
| 5 | 4. UI/UX Requirements | ? | PASS/FAIL |
| 6 | 5. Business Rules | ? | PASS/FAIL |
| 7 | 6. Data Requirements | ? | PASS/FAIL |
| 8 | 7. Dependencies | ? | PASS/FAIL |
| 9 | 8. Assumptions | ? | PASS/FAIL |
| 10 | 9. Non-Functional Requirements | ? | PASS/FAIL |
| 11 | 10. Test Scenarios / Test Notes | ? | PASS/FAIL |
| 12 | 11. Comments / Open Questions | ? | PASS/FAIL |

### 5.4 Content Format Verification

Verify content follows required formats:

| Check | Expected Format | Found | Status |
|-------|----------------|-------|--------|
| User Story ID | US-{MODULE_ABBREV}-XXX | ? | PASS/FAIL |
| User Story Statement | INVEST format: "As a... I want... So that..." | ? | PASS/FAIL |
| Acceptance Criteria | Given/When/Then format | ? | PASS/FAIL |

### 5.5 Auto-Correction Loop

If alignment < 100%, execute corrections:

```
WHILE alignment_score < 100%:
    1. Identify first mismatch
    2. Apply correction:
       - Missing Section → Add section with exact template heading
       - Wrong Section Name → Rename to match template exactly
       - Wrong ID Format → Fix User Story ID to match convention
       - Wrong Statement Format → Rewrite in INVEST format
       - Wrong AC Format → Rewrite in Given/When/Then format
       - Wrong Heading Level → Adjust markdown heading level
    3. Re-verify document
    4. Update alignment score

    MAX_ITERATIONS = 5
    IF iterations > MAX_ITERATIONS: Report remaining issues and proceed
```

### 5.6 Alignment Report

After verification, output:

```
## Template Alignment Results

**Template:** templates/USER STORIES DOCUMENT.docx
**Document:** Documents/UserStories/{ModuleName}_UserStories.md
**Alignment Score:** {SCORE}%

### Summary
| Category | Expected | Found | Status |
|----------|----------|-------|--------|
| Sections | 11 | {N} | PASS/FAIL |
| Tables | 0 | {N} | PASS/FAIL |
| ID Format | US-{ABBREV}-XXX | {format} | PASS/FAIL |
| INVEST Format | As a/I want/So that | {found} | PASS/FAIL |
| AC Format | Given/When/Then | {found} | PASS/FAIL |

### Corrections Applied
- {List of corrections made, or "None required"}

### Status: ALIGNED / NEEDS MANUAL REVIEW
```

---

## Verification Checklist
Before completing, verify:
- [ ] All 11 sections are present with exact headings
- [ ] User Story ID follows the convention
- [ ] INVEST format is used for User Story Statement
- [ ] Given/When/Then format is used for Acceptance Criteria
- [ ] Content is derived from actual code analysis, not generic placeholders
- [ ] UI exploration findings are incorporated
- [ ] Business rules are extracted from backend code
- [ ] Field names match actual implementation

## Critical Source Files to Analyze

**The paths below are determined dynamically based on the detected technology stack.**

If `module-structure.json` exists, use the paths from the matching module entry.

Otherwise, use the Explore agent with these generic patterns:

| Purpose | Generic Pattern (adapts to detected stack) |
|---------|---------------------------------------------|
| Frontend pages | `**/{pages,views,app}/**/*{MODULE}*.*` |
| Frontend components | `**/components/**/*{MODULE}*.*` |
| Backend controllers/handlers | `**/{controllers,handlers,routes,routers}/**/*{MODULE}*.*` |
| Backend services | `**/services/**/*{MODULE}*.*` |
| DTOs/Models | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` |
| Entities | `**/{entities,models,domain}/**/*{MODULE}*.*` |
| Validations | `**/{validations,validators}/**/*{MODULE}*.*` |

## Execution
Now analyze the module "$ARGUMENTS" and generate the complete User Stories Document following the exact structure above.
