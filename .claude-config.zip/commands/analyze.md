---
name: analyze
description: Produce comprehensive per-module documentation combining BRD, FRD, User Stories, and Process Flow into a single markdown file for each discovered module.
tags: [documentation, analysis, brd, frd, user-stories, process-flow, comprehensive]
---

# Comprehensive Module Documentation Generator

## Purpose
Auto-discover all modules in the codebase and generate **one comprehensive markdown file per module** that combines:
- **Part 1:** Business Requirements (BRD)
- **Part 2:** Functional Requirements (FRD)
- **Part 3:** User Stories
- **Part 4:** Process Flow (with Mermaid diagrams)

## Output
- **Location:** `Documents/Modules/{ModuleName}.md` (one file per module)
- **Diagrams:** `Documents/Modules/diagrams/{ModuleName}_flow.mmd` and `.png`
- **Screenshots:** `Documents/Modules/screenshots/{ModuleName}/` (MANDATORY)
- **Format:** Markdown (.md)

---

## ⛔ CRITICAL: MANDATORY UI EXPLORATION REQUIREMENT

> **THIS PROCESS REQUIRES LIVE UI EXPLORATION AND SCREENSHOT CAPTURE.**
>
> **THE FOLLOWING ARE NON-NEGOTIABLE REQUIREMENTS:**
>
> 1. ✅ The application MUST be running and accessible
> 2. ✅ All required environment variables MUST be set (`STARTUP_SCRIPT`, `APPLICATION_URL`, `credentials_email`, `credentials_password`)
> 3. ✅ Playwright MUST successfully navigate to and capture screenshots of ALL module screens
> 4. ✅ Screenshots of list view, create form, edit form, and detail view are MANDATORY for each module
>
> **IF ANY OF THE ABOVE FAIL:**
> - ⛔ The entire documentation process will be ABORTED IMMEDIATELY
> - ⛔ No partial documentation will be generated
> - ⛔ An error message will be displayed with the specific failure reason
>
> **DO NOT attempt to generate documentation without completing UI exploration.**
> **DO NOT skip screenshots or mark them as "N/A" or "To be added later".**

---

## Workflow

### Step 1: Module Discovery

#### 1.1 Backend Controller Scanning
Search for all controllers to identify modules:
```
**/Controllers/*Controller.cs
```

Extract module names from controller names:
- `LeaveController.cs` → `Leave`
- `GrievancesController.cs` → `Grievances`
- `EmployeeController.cs` → `Employee`
- `KPIController.cs` → `KPI`

#### 1.2 Frontend Page Directory Scanning
Cross-reference with frontend page directories:
```
**/pages/*/
**/views/*/
```

Extract module names from directory names:
- `pages/leave/` → `Leave`
- `pages/grievances/` → `Grievances`
- `pages/employee/` → `Employee`

#### 1.3 Build Unified Module List
Combine results from backend and frontend scanning:
1. Create a list of unique module names
2. Normalize casing (PascalCase preferred)
3. Map each module to its related files (controllers, pages, components, services)

### Step 2: Create Output Directories
```bash
mkdir -p Documents/Modules/diagrams
```

### Step 3: For Each Module, Generate Comprehensive Document

For each discovered module, use the **Explore agent** to analyze:

#### 3.1 Frontend Analysis
| Search Pattern | Files to Search |
|---------------|-----------------|
| Pages, routes | `**/pages/**/*{MODULE}*.vue`, `**/views/**/*{MODULE}*.vue` |
| Components | `**/components/**/*{MODULE}*.vue` |
| Forms, inputs | `**/*{MODULE}*Form*.vue`, `**/*{MODULE}*Input*.vue` |
| Tables, lists | `**/*{MODULE}*Table*.vue`, `**/*{MODULE}*List*.vue` |
| Store/state | `**/store/**/*{MODULE}*.ts`, `**/stores/**/*{MODULE}*.ts` |

Extract:
- All screens and navigation paths
- Form fields with validations
- User interactions (buttons, actions)
- Data display formats (tables, cards, lists)

#### 3.2 Backend Analysis
| Search Pattern | Files to Search |
|---------------|-----------------|
| Controllers | `**/Controllers/*{MODULE}*.cs` |
| Services | `**/Services/*{MODULE}*.cs` |
| DTOs | `**/DTOs/*{MODULE}*.cs`, `**/Models/*{MODULE}*.cs` |
| Entities | `**/Entities/*{MODULE}*.cs` |
| Validations | `**/Validations/*{MODULE}*.cs` |

Extract:
- API endpoints (GET, POST, PUT, DELETE)
- Request/response models
- Business rules and validations
- Database relationships

#### 3.3 Service Layer Analysis
| Search Pattern | Files to Search |
|---------------|-----------------|
| Business logic | `**/Services/*{MODULE}*Service*.cs` |
| Calculations | `**/*{MODULE}*Calculator*.cs`, `**/*{MODULE}*Compute*.cs` |
| Workflows | `**/*{MODULE}*Workflow*.cs`, `**/*{MODULE}*Process*.cs` |

Extract:
- Business calculations
- Workflow steps
- Approval processes
- External integrations

### Step 4: Explore Live UI with Playwright (MANDATORY - CANNOT BE SKIPPED)

> **CRITICAL REQUIREMENT:** This step is MANDATORY and CANNOT be skipped under any circumstances.
> If this step fails or cannot be completed, the entire documentation process MUST be ABORTED IMMEDIATELY.
> Do NOT proceed to Step 5 or any subsequent steps without successfully completing UI exploration and capturing screenshots.

Use Playwright MCP tools to explore the live application:

#### 4.1 Pre-requisites Check (MANDATORY)
Before exploring, verify the following environment variables are set:
- `STARTUP_SCRIPT` - Script to start/stop the application
- `APPLICATION_URL` - URL of the running application
- `credentials_email` - Login email
- `credentials_password` - Login password

**If any environment variable is missing, ABORT the process immediately with an error message.**

#### 4.2 Application Startup (MANDATORY)
1. Analyze the repo and run the startup script specified in env variable `STARTUP_SCRIPT`
2. Wait for the application to be fully running and accessible
3. Verify the application is responding at `APPLICATION_URL`

**If the application fails to start or is not accessible, ABORT the process immediately.**

#### 4.3 UI Exploration Steps (MANDATORY - ALL steps must complete successfully)
1. Navigate to the application URL from env variable `APPLICATION_URL`
2. Login with credentials from env variables `credentials_email` and `credentials_password`
3. Navigate to the module's pages
4. **Take screenshots of ALL key screens** (minimum requirements below)
5. Document navigation flow and UI elements
6. Capture form fields, buttons, and actions
7. Log out, close browser, and stop servers using `STARTUP_SCRIPT`

#### 4.4 Minimum Screenshot Requirements (MANDATORY)
The following screenshots MUST be captured for each module. If any screenshot cannot be captured, ABORT the process:

| Screenshot Type | Description | Required |
|-----------------|-------------|----------|
| List/Index View | Main listing page showing data grid/table | YES |
| Create/Add Form | Form for creating new records | YES |
| Edit Form | Form for editing existing records | YES |
| View/Detail Page | Detailed view of a single record | YES |
| Filter/Search UI | Any filter or search functionality | YES (if exists) |
| Modal Dialogs | Any popup modals or dialogs | YES (if exists) |
| Error States | Validation errors, empty states | YES (if exists) |

#### 4.5 Screenshot Storage (MANDATORY)
All screenshots MUST be saved to:
```
Documents/Modules/screenshots/{ModuleName}/
├── {ModuleName}_list.png
├── {ModuleName}_create.png
├── {ModuleName}_edit.png
├── {ModuleName}_view.png
├── {ModuleName}_filter.png (if applicable)
├── {ModuleName}_modal_*.png (if applicable)
└── {ModuleName}_error_*.png (if applicable)
```

#### 4.6 Abort Conditions
**ABORT the entire documentation process immediately if ANY of the following occur:**
- Environment variables are not set
- Application fails to start
- Login fails
- Cannot navigate to module pages
- Cannot capture required screenshots
- Browser automation encounters unrecoverable errors
- Any screenshot in the minimum requirements cannot be captured

**When aborting, output a clear error message:**
```
⛔ PROCESS ABORTED: UI Exploration Failed
Reason: {specific reason}
Module: {module name}
Step Failed: {step number and description}
Action Required: {what needs to be fixed before retrying}
```

#### 4.7 Success Verification (MANDATORY)
Before proceeding to Step 5, verify:
- [ ] All minimum required screenshots have been captured
- [ ] Screenshots are saved to the correct directory
- [ ] Screenshots are readable and show the expected UI elements
- [ ] Navigation flow has been documented
- [ ] Form fields and actions have been captured

**Only proceed to Step 5 after ALL verification checks pass.**

### Step 5: Generate Mermaid Diagram for Process Flow
Create a flowchart for each module and save to:
- Mermaid source: `Documents/Modules/diagrams/{ModuleName}_flow.mmd`
- PNG image: `Documents/Modules/diagrams/{ModuleName}_flow.png`

Render using:
```bash
mmdc -i Documents/Modules/diagrams/{ModuleName}_flow.mmd \
     -o Documents/Modules/diagrams/{ModuleName}_flow.png \
     -b transparent -w 1200
```

### Step 6: Write Comprehensive Document
Generate `Documents/Modules/{ModuleName}.md` with ALL 4 parts.

---

## Document Structure (Must Follow Exactly)

> **⛔ CRITICAL REMINDER: SCREENSHOT EMBEDDING IS MANDATORY**
>
> Every generated markdown document MUST embed the captured screenshots using markdown image syntax:
> ```markdown
> ![Description](screenshots/{ModuleName}/{ModuleName}_list.png)
> ```
>
> Screenshots MUST appear in these sections:
> - **Part 1, Section 1.4.4:** Wireframes/Screenshots
> - **Part 2, Section 2.2.2:** Wireframes/Screenshots
> - **Part 3, Section 3.4:** UI/UX Requirements
>
> **DO NOT** just store screenshots in folders without embedding them in the document.
> **DO NOT** use placeholder text like "Screenshot to be added" or "See screenshots folder".

### Title Page & Metadata

```markdown
# {Module Name} - Comprehensive Module Documentation

**PROGRAMMERS.IO INDIA PVT LTD.**

---

| Field | Value |
|-------|-------|
| **Client Name** | {Client name or "PROGRAMMERS.IO"} |
| **Project Name** | HRMS - {Module Name} Module |
| **Document Version** | 1.0 |
| **Author Name** | Business Analyst |
| **Date** | {Current date in DD/MM/YYYY format} |

---

## Version History

| Release Date | Version Number | Section/Page # Change | Change Details | Done By | Reviewed By |
|-------------|----------------|----------------------|----------------|---------|-------------|
| {Current date} | 1.0 | All | Initial draft | Business Analyst | Technical Lead |

---

## Table of Contents

- [Part 1: Business Requirements (BRD)](#part-1-business-requirements-brd)
- [Part 2: Functional Requirements (FRD)](#part-2-functional-requirements-frd)
- [Part 3: User Stories](#part-3-user-stories)
- [Part 4: Process Flow](#part-4-process-flow)

---
```

---

# Part 1: Business Requirements (BRD)

```markdown
# Part 1: Business Requirements (BRD)

## 1.1 Introduction

{Provide a quick overview of the BRD document contents and its purpose. Include key terms used throughout.}

### 1.1.1 Overview

{High-level description of the module derived from code analysis - what it does, who uses it, and why it exists.}

### 1.1.2 Problem Statement

{Define the specific problem this module addresses. Derive from:
- Business context of the module
- Pain points the module solves
- Current challenges addressed}

### 1.1.3 Project Objective

{Define the goals and objectives. List specific, measurable objectives derived from the module's functionality:
- Primary objective
- Secondary objectives
- Success criteria}

### 1.1.4 Project Scope

**In Scope:**
{List all features and functionalities that are part of this module, derived from code analysis:}
- Feature 1
- Feature 2
- ...

**Future Scope:**
{List features that could be added in future phases but are not part of current implementation:}
- Future feature 1
- Future feature 2
- ...

### 1.1.5 Assumptions and Constraints

**Assumptions:**
{List assumptions made during analysis:}
- Assumption 1
- Assumption 2
- ...

**Constraints:**
{List constraints and limitations:}
- Constraint 1
- Constraint 2
- ...

---

## 1.2 Definitions and Abbreviations

| Term | Definition |
|------|------------|
| HRMS | Human Resource Management System |
| {MODULE_ABBREV} | {Module full name} |
| {Term from code} | {Definition} |
| {Business term} | {Definition} |
| ... | ... |

---

## 1.3 Business Drivers

### Top Executives (Primary Stakeholders)
- {Role 1 - e.g., HR Director}
- {Role 2 - e.g., Department Managers}

### Secondary Stakeholders
- {Role 3 - e.g., Employees}
- {Role 4 - e.g., System Administrators}

---

## 1.4 Functional Requirements

{This section comprises the detailed project requirements derived from code analysis.}

### 1.4.1 Feature Overview

{List all major features discovered in the module:}

| Feature ID | Feature Name | Description | Priority |
|-----------|--------------|-------------|----------|
| FR-{ABBREV}-001 | {Feature name} | {Description from code} | {Critical/High/Medium/Low} |
| FR-{ABBREV}-002 | {Feature name} | {Description from code} | {Priority} |
| ... | ... | ... | ... |

### 1.4.2 Detailed Requirements

#### FR-{ABBREV}-001: {Feature Name}

**Description:** {Detailed description}

**Business Rules:**
- Rule 1: {From service layer analysis}
- Rule 2: {From validation analysis}

**User Actions:**
- Action 1: {From UI analysis}
- Action 2: {From API endpoints}

**Data Fields:**
| Field Name | Type | Required | Validation | Description |
|-----------|------|----------|------------|-------------|
| {field} | {type} | Yes/No | {validation rules} | {description} |

**API Endpoints:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/{module}/... | {description} |
| POST | /api/{module}/... | {description} |

{Repeat for each feature}

### 1.4.3 Workflow Diagrams

{Describe the workflow steps with embedded screenshots.}

**Main Workflow:**
1. Step 1: {Action}
2. Step 2: {Action}
3. Step 3: {Action}

### 1.4.4 Wireframes/Screenshots (MANDATORY)

> **CRITICAL:** This section MUST include embedded screenshots captured during UI exploration.
> Screenshots are stored in `Documents/Modules/screenshots/{ModuleName}/` and MUST be embedded here.

**List/Index View:**
![{Module Name} List View](screenshots/{ModuleName}/{ModuleName}_list.png)
{Description of the list view UI elements, columns, actions available}

**Create Form:**
![{Module Name} Create Form](screenshots/{ModuleName}/{ModuleName}_create.png)
{Description of the create form fields, validations, buttons}

**Edit Form:**
![{Module Name} Edit Form](screenshots/{ModuleName}/{ModuleName}_edit.png)
{Description of the edit form, pre-populated fields, update actions}

**Detail/View Page:**
![{Module Name} Detail View](screenshots/{ModuleName}/{ModuleName}_view.png)
{Description of the detail view layout, displayed information}

**Filter/Search UI (if applicable):**
![{Module Name} Filter](screenshots/{ModuleName}/{ModuleName}_filter.png)
{Description of filter options, search functionality}

**Modal Dialogs (if applicable):**
![{Module Name} Modal](screenshots/{ModuleName}/{ModuleName}_modal_*.png)
{Description of any popup dialogs, confirmation modals}

---

## 1.5 Non-Functional Requirements

### 1.5.1 Performance Requirements

| Requirement | Specification |
|------------|---------------|
| Page Load Time | < 3 seconds |
| API Response Time | < 500ms for standard operations |
| Concurrent Users | Support {N} concurrent users |
| Data Volume | Handle {N} records efficiently |

### 1.5.2 Usability Requirements

| Requirement | Specification |
|------------|---------------|
| Ease of Use | Intuitive interface with minimal training required |
| Accessibility | WCAG 2.1 AA compliance |
| Mobile Responsiveness | Responsive design for tablet and mobile |
| Navigation | Maximum 3 clicks to reach any feature |

### 1.5.3 Security Requirements

| Requirement | Specification |
|------------|---------------|
| Authentication | {From code analysis - JWT/OAuth/etc.} |
| Authorization | Role-based access control (RBAC) |
| Data Protection | Encryption at rest and in transit |
| Audit Trail | All critical actions logged |
| Session Management | {Session timeout, token expiry details} |

---

## 1.6 References

| Reference Document Details | Location |
|---------------------------|----------|
| API Documentation | /docs/api |
| Database Schema | /docs/database |
| UI Design Mockups | /designs |
| {Other reference} | {Location} |

---

## 1.7 Priority Matrix

| Level | Rating | Description |
|-------|--------|-------------|
| 1 | Critical | This requirement is imperative to the success of the project. |
| 2 | High | This requirement is of high priority, but the project can be implemented at a bare minimum without this requirement. |
| 3 | Medium | This requirement is somewhat important, as it provides some value but the project can proceed without it. |
| 4 | Low | This is a low-priority requirement, or a "nice to have" feature if time and cost allow it. |
| 5 | Future | This requirement is out of scope for this project and has been included here for a possible future release. |

---

## 1.8 Technology Used

| S No. | Component | Technology |
|-------|-----------|------------|
| 1 | Back-end Technology | {From analysis - e.g., .NET Core 8, C#} |
| 2 | Front-end Technology | {From analysis - e.g., Vue.js 3, TypeScript} |
| 3 | Database | {From analysis - e.g., PostgreSQL, SQL Server} |
| 4 | Authentication | {From analysis - e.g., JWT, OAuth 2.0} |
| 5 | API Style | {From analysis - e.g., RESTful API} |

---
```

---

# Part 2: Functional Requirements (FRD)

```markdown
# Part 2: Functional Requirements (FRD)

## 2.1 Introduction

This Functional Requirements Document (FRD) section describes the functional requirements of the {Module Name} module within the HRMS application.

### 2.1.1 Project Overview

{Provide a brief overview of the module derived from code analysis - what it does, who uses it, and why it exists within the HRMS ecosystem.}

### 2.1.2 Problem Statement

{Specify the problem statement that this module resolves. Derive from:
- Business context of the module
- Pain points the module addresses
- Current challenges solved}

### 2.1.3 Purpose

{Define the goal that needs to be accomplished:
- Primary purpose of the module
- Key objectives
- Expected outcomes}

### 2.1.4 Project Scope

**In Scope:**
{List all features and functionalities that are part of this module, derived from code analysis:}
- Feature 1
- Feature 2
- ...

**Out of Scope:**
{List features that are NOT part of current implementation:}
- Feature 1
- Feature 2
- ...

### 2.1.5 Assumptions and Constraints

**Assumptions:**
> See Part 1, Section 1.1.5 for detailed assumptions.

**Constraints:**
> See Part 1, Section 1.1.5 for detailed constraints.

#### 2.1.5.1 Dependencies

{Add details if there is a dependency to implement any functionality:}
- Dependency 1: {Description}
- Dependency 2: {Description}

### 2.1.6 Interfaces to External System

{List any external systems the module interfaces with:}

| System Name | Interface Type | Description |
|-------------|---------------|-------------|
| {System 1} | {API/File/Database} | {Description} |
| {System 2} | {API/File/Database} | {Description} |

---

## 2.2 Functional Requirements

The functional requirements describe the core functionality of the {Module Name} module.

### 2.2.1 System Flow Diagram

{Describe the system flow including user roles and their related functionalities.}

**User Roles:**
| Role | Permissions | Description |
|------|-------------|-------------|
| {Role 1} | {Create, Read, Update, Delete} | {Description} |
| {Role 2} | {Read only} | {Description} |

**System Flow:**
1. {Step 1 description}
2. {Step 2 description}
3. {Step 3 description}
...

### 2.2.2 Functional Process Requirements

This section describes what the application should do for the {Module Name} module.

#### Feature: {Feature Name}

**Description:** {Detailed description of the feature}

**Workflow Diagram:**
{Describe the workflow steps:}
1. Step 1: {Action}
2. Step 2: {Action}
3. Step 3: {Action}

**Wireframes/Screenshots (MANDATORY):**

> **IMPORTANT:** Embed actual screenshots captured during UI exploration.

![{Feature Name} - Main Screen](screenshots/{ModuleName}/{ModuleName}_list.png)
*{Description of the main screen for this feature}*

![{Feature Name} - Form](screenshots/{ModuleName}/{ModuleName}_create.png)
*{Description of form elements for this feature}*

{Reference additional screenshots as applicable to this feature}

**Use Cases:**

| Use Case ID | Use Case Name | Actor | Description |
|------------|---------------|-------|-------------|
| UC-{ABBREV}-001 | {Use case name} | {Actor} | {Description} |
| UC-{ABBREV}-002 | {Use case name} | {Actor} | {Description} |

**Data Fields:**

| Field Name | Type | Required | Validation Rules | Description |
|-----------|------|----------|-----------------|-------------|
| {field} | {type} | Yes/No | {validation rules} | {description} |

**API Endpoints:**

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | /api/{module}/... | {description} | N/A | {response model} |
| POST | /api/{module}/... | {description} | {request model} | {response model} |

**Business Rules:**
> See Part 4, Section 4.7 for complete Business Rules table.

{Repeat for each feature discovered in the module}

#### 2.2.2.1 Entity Relationship Diagram

{Describe the database entities and their relationships:}

**Entities:**
| Entity Name | Description | Key Fields |
|-------------|-------------|------------|
| {Entity 1} | {Description} | {Primary key, foreign keys} |
| {Entity 2} | {Description} | {Primary key, foreign keys} |

**Relationships:**
- {Entity 1} → {Entity 2}: {Relationship type and description}
- {Entity 2} → {Entity 3}: {Relationship type and description}

#### 2.2.2.2 Swimlane Diagram

{Describe the process flow across different actors/systems:}

| Step | {Actor 1} | {Actor 2} | {System} |
|------|-----------|-----------|----------|
| 1 | {Action} | | |
| 2 | | {Action} | |
| 3 | | | {Action} |

### 2.2.3 Data Requirements

This section includes the entity definitions and attribute specifications.

**Entity: {Entity Name}**

| Attribute | Data Type | Size | Nullable | Default | Description |
|-----------|-----------|------|----------|---------|-------------|
| {attribute} | {type} | {size} | Yes/No | {default} | {description} |

{Repeat for each entity}

### 2.2.4 Non-Functional Requirements

> For detailed Non-Functional Requirements (Performance, Usability, Security), see Part 1, Section 1.5.

#### 2.2.4.1 Reliability

| Requirement | Specification |
|-------------|---------------|
| Uptime | {Expected uptime percentage} |
| Error Handling | {Error handling approach} |
| Data Integrity | {Data validation and consistency measures} |

#### 2.2.4.2 Recoverability

| Requirement | Specification |
|-------------|---------------|
| Backup Frequency | {Backup schedule} |
| Recovery Time Objective (RTO) | {Maximum acceptable downtime} |
| Recovery Point Objective (RPO) | {Maximum acceptable data loss} |

#### 2.2.4.3 System Availability

| Requirement | Specification |
|-------------|---------------|
| Availability Target | {e.g., 99.9%} |
| Maintenance Windows | {Scheduled maintenance times} |
| Failover Strategy | {Failover approach if applicable} |

---

## 2.3 Technology Used

> See Part 1, Section 1.8 for Technology details.

---

## 2.4 Data Migration

{Explain in brief the data conversion plan if applicable.}

### Migration Overview

| Aspect | Details |
|--------|---------|
| Source System | {Source system name if migrating data} |
| Target System | HRMS - {Module Name} Module |
| Migration Strategy | {Strategy - e.g., Big Bang, Phased} |
| Data Volume | {Estimated data volume} |

### Migration Steps

1. {Step 1: Data extraction}
2. {Step 2: Data transformation}
3. {Step 3: Data loading}
4. {Step 4: Validation}

### Rollback Plan

{Describe rollback strategy in case of migration failure}

---

## 2.5 Document References

The source of information for this FRD.

| Reference Document | Location | Description |
|-------------------|----------|-------------|
| API Documentation | /docs/api | API specifications |
| Database Schema | /docs/database | Entity relationship diagrams |
| UI Design Mockups | /designs | UI wireframes and mockups |
| Business Requirement Document | Part 1 of this document | Business requirements |
| {Other reference} | {Location} | {Description} |

---

## 2.6 Glossary

| Term | Abbreviation | Definition |
|------|--------------|------------|
| Human Resource Management System | HRMS | System for managing HR operations |
| {Module Name} | {ABBREV} | {Module description} |
| Functional Requirement Document | FRD | Document describing functional requirements |
| {Term from code} | {Abbrev} | {Definition} |
| {Business term} | {Abbrev} | {Definition} |

---
```

---

# Part 3: User Stories

```markdown
# Part 3: User Stories

## 3.1 User Story Details

**User Story ID:** US-{MODULE_ABBREV}-001
**User Story Title:** {Descriptive title based on main functionality}

**User Story Statement (INVEST Format)**
As a {type of user - HR Admin, Employee, Manager, etc.}
I want {specific goal derived from module analysis}
So that {business value/benefit}

---

## 3.2 Description

{High-level explanation of what this user story is about and why it is needed.
Derived from the module's purpose and functionality discovered during analysis.}

---

## 3.3 Acceptance Criteria (Given/When/Then Format)

**AC-1**
Given {precondition from the system state}
When {user action derived from UI analysis}
Then {expected result based on business rules}

**AC-2**
Given {another precondition}
When {another user action}
Then {expected result}

{Add more AC items based on the complexity of the module}

---

## 3.4 UI/UX Requirements (MANDATORY Screenshots)

> **CRITICAL:** This section MUST include embedded screenshots. Do NOT skip or mark as "N/A".

### Screens Involved
{List all pages/screens discovered in frontend analysis}

### Screenshots (MANDATORY)

**List View:**
![{Module Name} List View](screenshots/{ModuleName}/{ModuleName}_list.png)
*Main listing page showing data grid/table with available actions*

**Create Form:**
![{Module Name} Create Form](screenshots/{ModuleName}/{ModuleName}_create.png)
*Form for creating new records with input fields and validations*

**Edit Form:**
![{Module Name} Edit Form](screenshots/{ModuleName}/{ModuleName}_edit.png)
*Form for editing existing records with pre-populated data*

**Detail View:**
![{Module Name} Detail View](screenshots/{ModuleName}/{ModuleName}_view.png)
*Detailed view showing all information for a single record*

**Additional Screenshots (if applicable):**
- Filter/Search: `![Filter](screenshots/{ModuleName}/{ModuleName}_filter.png)`
- Modal Dialogs: `![Modal](screenshots/{ModuleName}/{ModuleName}_modal_*.png)`
- Error States: `![Error](screenshots/{ModuleName}/{ModuleName}_error_*.png)`

### Navigation Details
{Navigation flow from sidebar/menu to the module screens}

---

## 3.5 Business Rules

> See Part 4, Section 4.7 for complete Business Rules table.

Key rules applicable to this user story:
- **Rule 1:** {Business rule from backend/service analysis}
- **Rule 2:** {Validation rule from frontend/backend}
- **Rule 3:** {Calculation or constraint rule}
{Add more rules as discovered}

---

## 3.6 Data Requirements

- **Fields involved:** {List fields with their types from DTOs/forms}
- **Validation rules:** {Field-level validations discovered}
- **Backend data needs:** {API endpoints and database requirements}

---

## 3.7 Dependencies

- **Dependent modules:** {Other modules this module interacts with}
- **API dependencies:** {List of API endpoints used}
- **External systems:** {Any external integrations}

---

## 3.8 Assumptions

> See Part 1, Section 1.1.5 for detailed assumptions.

Key assumptions for this user story:
- {Assumptions made during analysis}
- {System state assumptions}
- {User role assumptions}
- {Any limitations discovered}

---

## 3.9 Non-Functional Requirements

> See Part 1, Section 1.5 for detailed Non-Functional Requirements.

Key NFRs applicable to this user story:
- **Performance requirements:** {Based on data volume and operations}
- **Security requirements:** {Role-based access, data protection}
- **Availability:** {System availability expectations}
- **Load time expectations:** {Page load and response time expectations}

---

## 3.10 Test Scenarios / Test Notes

A high-level list of what QA needs to verify:
- {Test scenario for main functionality}
- {Test scenario for edge cases}
- {Test scenario for validations}
- {Test scenario for error handling}
- {Test scenario for permissions/roles}

---

## 3.11 Comments / Open Questions

- **Pending clarifications:** {Any unclear requirements discovered}
- **Questions for stakeholders:** {Business logic questions}

---

### Additional User Stories (if applicable)

{If the module has multiple distinct user stories, repeat the structure above with incrementing IDs:}
- US-{ABBREV}-002
- US-{ABBREV}-003
- etc.

---
```

---

# Part 4: Process Flow

```markdown
# Part 4: Process Flow

## 4.1 Purpose

This section describes the end-to-end process flow for the {Module Name} module within the HRMS application.

{Provide a detailed description of:
- What the process accomplishes
- Business value delivered
- Key outcomes expected}

---

## 4.2 Scope

### In Scope
{List all processes and functionalities covered by this document:}
- Process 1: {Description}
- Process 2: {Description}
- ...

### Out of Scope
{List processes that are NOT covered:}
- Process 1: {Description}
- Process 2: {Description}
- ...

---

## 4.3 Actors Involved

| Actor Type | Actor Name | Description |
|------------|------------|-------------|
| Human | Employee | {Description of role in this process} |
| Human | Manager | {Description of role in this process} |
| Human | HR Administrator | {Description of role in this process} |
| System | HRMS System | {Description of automated actions} |
| External | {External System} | {Description if applicable} |

---

## 4.4 High-Level Process Summary

{Provide a brief overview of the process in 3-5 sentences:}

The {Module Name} process begins when {trigger event}. The process involves {key actors} who perform {main activities}. Upon completion, the system {outcome/result}. This process supports {business objective}.

---

## 4.5 Detailed Process Flow Steps

| Step No. | Actor | Description | Output/Result |
|----------|-------|-------------|---------------|
| 1 | {Actor} | {Action description} | {Result of this step} |
| 2 | {Actor} | {Action description} | {Result of this step} |
| 3 | System | {Automated action} | {Result of this step} |
| 4 | {Actor} | {Decision point description} | {Result based on decision} |
| ... | ... | ... | ... |

---

## 4.6 Process Flow Diagram

![{Module Name} Process Flow](diagrams/{ModuleName}_flow.png)

<details>
<summary>Mermaid Source Code</summary>

```mermaid
flowchart TD
    Start([Start: {Module Name} Process]):::startEnd --> A[User Action 1]:::userAction
    A --> B(System validates input):::systemAction
    B --> C{Validation passed?}:::decision
    C -->|No| D[Show error message]:::error --> A
    C -->|Yes| E(System processes request):::systemAction
    E --> F{Approval required?}:::decision
    F -->|Yes| G[Send for approval]:::userAction
    F -->|No| H(System saves data):::systemAction
    G --> I{Approved?}:::decision
    I -->|Yes| H
    I -->|No| J[Rejected notification]:::error --> End
    H --> K[Success notification]:::userAction
    K --> End([End: Process Complete]):::startEnd

    classDef userAction fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef systemAction fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef decision fill:#fff8e1,stroke:#f57f17,color:#e65100
    classDef error fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef startEnd fill:#f3e5f5,stroke:#7b1fa2,color:#4a148c
```

</details>

### Diagram Legend

| Shape | Meaning | Color |
|-------|---------|-------|
| Rounded Rectangle `([text])` | Start/End | Purple |
| Rectangle `[text]` | User Action | Blue |
| Stadium `(text)` | System Action | Green |
| Diamond `{text?}` | Decision Point | Yellow |
| Red Rectangle | Error/Exception | Red |

---

## 4.7 Business Rules

| Rule ID | Rule Description |
|---------|------------------|
| BR-{ABBREV}-001 | {Business rule from service layer or validation} |
| BR-{ABBREV}-002 | {Business rule from service layer or validation} |
| BR-{ABBREV}-003 | {Business rule from service layer or validation} |
| ... | ... |

---

## 4.8 Exception Scenarios

### Exception 1: {Exception Name}

| Aspect | Details |
|--------|---------|
| **Trigger** | {What causes this exception} |
| **System Response** | {How the system handles it} |
| **Resolution** | {Steps to resolve} |

### Exception 2: {Exception Name}

| Aspect | Details |
|--------|---------|
| **Trigger** | {What causes this exception} |
| **System Response** | {How the system handles it} |
| **Resolution** | {Steps to resolve} |

{Repeat for each exception scenario identified}

---

## 4.9 Integrations

| Integration | Type | Description |
|-------------|------|-------------|
| {System/Module 1} | {API/Event/Database} | {How this process integrates with it} |
| {System/Module 2} | {API/Event/Database} | {How this process integrates with it} |
| {External Service} | {API/Webhook} | {How this process integrates with it} |

---

## 4.10 Assumptions

> See Part 1, Section 1.1.5 for detailed assumptions.

Key assumptions for this process flow:
- {Assumption 1: e.g., Users have valid credentials}
- {Assumption 2: e.g., Required master data is configured}
- {Assumption 3: e.g., Network connectivity is available}
- {Assumption 4: e.g., External services are operational}
- ...

---

## 4.11 Document History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 1.0 | {Current date in DD/MM/YYYY} | Business Analyst | Initial draft |

---
```

---

## Cross-Reference Deduplication Guide

To avoid content duplication across parts, use cross-references:

| Overlapping Content | First Occurrence | Reference In Other Parts |
|---------------------|------------------|--------------------------|
| Technology Stack | Part 1, Section 1.8 | "See Part 1, Section 1.8 for Technology details." |
| Business Rules | Part 4, Section 4.7 | "See Part 4, Section 4.7 for complete Business Rules table." |
| Non-Functional Requirements | Part 1, Section 1.5 | "See Part 1, Section 1.5 for detailed Non-Functional Requirements." |
| Assumptions | Part 1, Section 1.1.5 | "See Part 1, Section 1.1.5 for detailed assumptions." |
| Definitions/Glossary | Part 1, Section 1.2 | "See Part 1, Section 1.2 for Definitions and Abbreviations." |

---

## Mermaid Diagram Generation Guide

### Code Pattern to Flow Element Mapping

| Code Pattern | Flow Element | Mermaid Syntax |
|--------------|--------------|----------------|
| HTTP GET endpoint | User views/loads data | `[User views {resource}]:::userAction` |
| HTTP POST endpoint | User creates/submits | `[User submits {form}]:::userAction` |
| HTTP PUT endpoint | User updates | `[User updates {resource}]:::userAction` |
| HTTP DELETE endpoint | User deletes | `[User deletes {resource}]:::userAction` |
| `if/else` statements | Decision diamond | `{Condition?}:::decision` |
| `try/catch` blocks | Exception path | `[Error: {message}]:::error` |
| Validation rules | Decision point | `{Valid?}:::decision` |
| Service method calls | System action | `(System {action}):::systemAction` |
| Authorization checks | Permission gate | `{Has permission?}:::decision` |
| Approval workflows | Approval decision | `{Approved?}:::decision` |

### Mermaid Syntax Reference

```mermaid
flowchart TD
    %% Start and End nodes
    Start([Start: Process Name]):::startEnd
    End([End: Process Complete]):::startEnd

    %% User actions (rectangle)
    A[User performs action]:::userAction

    %% System actions (stadium shape)
    B(System validates data):::systemAction

    %% Decision points (diamond)
    C{Is condition met?}:::decision

    %% Error states
    D[Error: Validation failed]:::error

    %% Flow connections
    Start --> A
    A --> B
    B --> C
    C -->|Yes| End
    C -->|No| D
    D --> A

    %% Style definitions
    classDef userAction fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef systemAction fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef decision fill:#fff8e1,stroke:#f57f17,color:#e65100
    classDef error fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef startEnd fill:#f3e5f5,stroke:#7b1fa2,color:#4a148c
```

### Rendering Command

```bash
# Primary method using mermaid-cli
mmdc -i Documents/Modules/diagrams/{ModuleName}_flow.mmd \
     -o Documents/Modules/diagrams/{ModuleName}_flow.png \
     -b transparent -w 1200

# Check if mmdc is installed
which mmdc || npm install -g @mermaid-js/mermaid-cli
```

**Fallback:** If mermaid-cli (`mmdc`) is not available or fails:
1. Use Playwright to navigate to https://mermaid.live
2. Paste the Mermaid code into the editor
3. Take a screenshot of the rendered diagram
4. Save to the PNG output path

---

## Critical Source Files to Analyze

| Purpose | Path Pattern |
|---------|--------------|
| Frontend pages | `**/pages/**/*{MODULE}*.vue` |
| Frontend components | `**/components/**/*{MODULE}*.vue` |
| Frontend stores | `**/stores/**/*{MODULE}*.ts` |
| Backend controllers | `**/Controllers/*{MODULE}*.cs` |
| Backend services | `**/Services/*{MODULE}*.cs` |
| DTOs | `**/DTOs/*{MODULE}*.cs` |
| Entities | `**/Entities/*{MODULE}*.cs` |
| Validations | `**/Validations/*{MODULE}*.cs` |

---

## Verification Checklist

Before completing each module document, verify:

### Structure
- [ ] Document created at `Documents/Modules/{ModuleName}.md`
- [ ] Title page with metadata table (Client, Project, Version, Author, Date)
- [ ] Version History table
- [ ] Table of Contents with links to all 4 parts

### Part 1: Business Requirements (BRD)
- [ ] Section 1.1: Introduction with all 5 subsections
- [ ] Section 1.2: Definitions table
- [ ] Section 1.3: Business Drivers with stakeholders
- [ ] Section 1.4: Functional Requirements with feature table and detailed requirements
- [ ] Section 1.5: Non-Functional Requirements (Performance, Usability, Security)
- [ ] Section 1.6: References table
- [ ] Section 1.7: Priority Matrix table
- [ ] Section 1.8: Technology table

### Part 2: Functional Requirements (FRD)
- [ ] Section 2.1: Introduction with all 6 subsections
- [ ] Section 2.2: Functional Requirements with:
  - [ ] 2.2.1 System Flow Diagram
  - [ ] 2.2.2 Functional Process Requirements (workflows, wireframes, use cases, ERD, swimlane)
  - [ ] 2.2.3 Data Requirements
  - [ ] 2.2.4 Non-Functional Requirements
- [ ] Section 2.3: Technology (cross-reference)
- [ ] Section 2.4: Data Migration plan
- [ ] Section 2.5: Document References table
- [ ] Section 2.6: Glossary table

### Part 3: User Stories
- [ ] Section 3.1: User Story Details (ID, Title, INVEST format statement)
- [ ] Section 3.2: Description
- [ ] Section 3.3: Acceptance Criteria (Given/When/Then format)
- [ ] Section 3.4: UI/UX Requirements
- [ ] Section 3.5: Business Rules (cross-reference)
- [ ] Section 3.6: Data Requirements
- [ ] Section 3.7: Dependencies
- [ ] Section 3.8: Assumptions (cross-reference)
- [ ] Section 3.9: Non-Functional Requirements (cross-reference)
- [ ] Section 3.10: Test Scenarios
- [ ] Section 3.11: Comments / Open Questions

### Part 4: Process Flow
- [ ] Section 4.1: Purpose
- [ ] Section 4.2: Scope (In Scope / Out of Scope)
- [ ] Section 4.3: Actors Involved table
- [ ] Section 4.4: High-Level Process Summary
- [ ] Section 4.5: Detailed Process Flow Steps table
- [ ] Section 4.6: Process Flow Diagram with embedded PNG and Mermaid source
- [ ] Section 4.7: Business Rules table
- [ ] Section 4.8: Exception Scenarios
- [ ] Section 4.9: Integrations table
- [ ] Section 4.10: Assumptions (cross-reference)
- [ ] Section 4.11: Document History table

### Content Quality
- [ ] All content derived from actual code analysis, not generic placeholders
- [ ] Feature IDs follow convention: FR-{MODULE_ABBREV}-XXX
- [ ] Use Case IDs follow convention: UC-{MODULE_ABBREV}-XXX
- [ ] Business Rule IDs follow convention: BR-{MODULE_ABBREV}-XXX
- [ ] User Story IDs follow convention: US-{MODULE_ABBREV}-XXX
- [ ] Field names match actual implementation
- [ ] Business rules extracted from service layer
- [ ] API endpoints documented from controllers
- [ ] Cross-references used for overlapping content

### Screenshots (MANDATORY - Process aborts if not completed)
- [ ] Screenshot directory created at `Documents/Modules/screenshots/{ModuleName}/`
- [ ] List/Index view screenshot captured (`{ModuleName}_list.png`)
- [ ] Create form screenshot captured (`{ModuleName}_create.png`)
- [ ] Edit form screenshot captured (`{ModuleName}_edit.png`)
- [ ] View/Detail page screenshot captured (`{ModuleName}_view.png`)
- [ ] Filter/Search UI screenshot captured (if applicable)
- [ ] Modal dialogs captured (if applicable)
- [ ] Error states captured (if applicable)
- [ ] All screenshots are readable and show expected UI elements

### Screenshot Embedding in Document (MANDATORY)
- [ ] Screenshots are EMBEDDED in Part 1, Section 1.4.4 (Wireframes/Screenshots)
- [ ] Screenshots are EMBEDDED in Part 2, Section 2.2.2 (Wireframes/Screenshots)
- [ ] Screenshots are EMBEDDED in Part 3, Section 3.4 (UI/UX Requirements)
- [ ] All screenshot image paths use relative paths: `screenshots/{ModuleName}/{ModuleName}_*.png`
- [ ] Each embedded screenshot has a descriptive caption
- [ ] Screenshot alt text is meaningful (not generic placeholders)

### Diagrams
- [ ] Mermaid file saved to `Documents/Modules/diagrams/{ModuleName}_flow.mmd`
- [ ] PNG rendered to `Documents/Modules/diagrams/{ModuleName}_flow.png`
- [ ] Mermaid diagram uses correct styling classes
- [ ] Flow elements properly mapped from code patterns

---

## Execution

Run `/analyze` to automatically:

1. **Discover modules** - Scan controllers and page directories for all modules
2. **Create directories** - Run `mkdir -p Documents/Modules/diagrams Documents/Modules/screenshots`
3. **Verify environment variables** - Check that `STARTUP_SCRIPT`, `APPLICATION_URL`, `credentials_email`, and `credentials_password` are set. **ABORT if any are missing.**
4. **For each module:**
   a. **Run code analysis** - Use Explore agent to search for module-related files
   b. **Analyze frontend** - Extract pages, components, forms, fields, actions
   c. **Analyze backend** - Extract controllers, services, DTOs, entities
   d. **Extract business rules** - From service layer and validations
   e. **⚠️ MANDATORY: Explore UI** - Use Playwright to capture screenshots and workflows. **ABORT IMMEDIATELY if this step fails.**
   f. **⚠️ MANDATORY: Capture screenshots** - Take all required screenshots (list, create, edit, view, etc.). **ABORT IMMEDIATELY if screenshots cannot be captured.**
   g. **Verify screenshots** - Confirm all minimum required screenshots exist before proceeding. **ABORT if verification fails.**
   h. **⚠️ MANDATORY: Embed screenshots in document** - All captured screenshots MUST be embedded in the markdown document using relative paths (`screenshots/{ModuleName}/{ModuleName}_*.png`). Screenshots must appear in:
      - Part 1, Section 1.4.4 (Wireframes/Screenshots)
      - Part 2, Section 2.2.2 (Wireframes/Screenshots)
      - Part 3, Section 3.4 (UI/UX Requirements)
   i. **Generate Mermaid diagram** - Create flowchart with proper syntax and styling
   j. **Write Mermaid file** - Save `.mmd` file to diagrams folder
   k. **Render PNG** - Execute `mmdc` command (with fallback to Playwright)
   l. **Generate comprehensive document** - Use Write tool to create Markdown file with all 4 parts. **CRITICAL: All captured screenshots MUST be embedded in the document with proper markdown image syntax.**
   m. **Verify output** - Confirm all sections present, cross-references correct, and **all screenshots are embedded in the document (not just stored in folder)**
5. **Report completion** - List all generated module documentation files with screenshot counts

**IMPORTANT:** The process will ABORT and not generate any documentation if UI exploration or screenshot capture fails. This ensures that all documentation includes real UI screenshots and accurate UI descriptions.

---

## Expected Output Structure

```
Documents/Modules/
├── diagrams/
│   ├── AssetManagement_flow.mmd
│   ├── AssetManagement_flow.png
│   ├── Attendance_flow.mmd
│   ├── Attendance_flow.png
│   └── ...
├── screenshots/                          # MANDATORY - Must exist for all modules
│   ├── AssetManagement/
│   │   ├── AssetManagement_list.png      # REQUIRED
│   │   ├── AssetManagement_create.png    # REQUIRED
│   │   ├── AssetManagement_edit.png      # REQUIRED
│   │   ├── AssetManagement_view.png      # REQUIRED
│   │   ├── AssetManagement_filter.png    # If applicable
│   │   └── AssetManagement_modal_*.png   # If applicable
│   ├── Attendance/
│   │   ├── Attendance_list.png           # REQUIRED
│   │   ├── Attendance_create.png         # REQUIRED
│   │   ├── Attendance_edit.png           # REQUIRED
│   │   ├── Attendance_view.png           # REQUIRED
│   │   └── ...
│   └── ... (one folder per module with screenshots)
├── AssetManagement.md
├── Attendance.md
├── Certificates.md
├── CompanyPolicy.md
├── Dashboard.md
├── Employee.md
├── Events.md
├── ExitEmployee.md
├── Grievances.md
├── KPI.md
├── LeaveManagement.md
├── Nominee.md
├── RolePermission.md
├── Survey.md
├── UserGuide.md
└── ... (one file per discovered module)
```

**NOTE:**
- If the `screenshots/` folder or any required screenshots are missing, the documentation generation has FAILED and should be re-run.
- **CRITICAL:** Screenshots stored in the `screenshots/` folder MUST also be EMBEDDED in the corresponding markdown files using relative image paths. Just having screenshots in the folder is NOT sufficient - they MUST appear inline in the documentation.

**Example of correct screenshot embedding in markdown:**
```markdown
## 1.4.4 Wireframes/Screenshots

**List View:**
![Leave Management List View](screenshots/LeaveManagement/LeaveManagement_list.png)
*Main listing page showing leave requests with status, dates, and actions*

**Create Form:**
![Leave Management Create Form](screenshots/LeaveManagement/LeaveManagement_create.png)
*Form for submitting new leave requests with date picker and leave type selection*
```
