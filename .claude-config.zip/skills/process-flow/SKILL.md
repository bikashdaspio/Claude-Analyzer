---
name: process-flow
argument-hint: MODULE_NAME
description: Generate a comprehensive Process Flow Document with Mermaid diagrams for the specified module following the standard template.
tags: [documentation, process-flow, workflow, mermaid, diagrams]
---

# Process Flow Document Generator

**Arguments:** $ARGUMENTS (Module name, e.g., "Leaves", "Grievances", "KPI")

## Purpose
Generate a comprehensive Process Flow Document for the specified module with Mermaid diagrams rendered as PNG images, documenting the end-to-end business process flow.

## Output
- **Document:** `Documents/ProcessFlow/{ModuleName}_ProcessFlow.md`
- **Mermaid Source:** `Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd`
- **PNG Image:** `Documents/ProcessFlow/diagrams/{ModuleName}_flow.png`

---

## Workflow

### Step 1: Parse Module Argument & Detect Technology Stack
1. Extract the MODULE_NAME from $ARGUMENTS
2. Set output paths:
   - Document: `Documents/ProcessFlow/{ModuleName}_ProcessFlow.md`
   - Mermaid: `Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd`
   - PNG: `Documents/ProcessFlow/diagrams/{ModuleName}_flow.png`
3. Create output directories using Bash: `mkdir -p Documents/ProcessFlow/diagrams`
4. **Detect technology stack** (see Technology Detection section below)

### Step 2: Analyze Module Codebase
Use the **Explore agent** to gather comprehensive information about the module.

**IMPORTANT:** Use the appropriate search patterns based on the detected technology stack.

#### 2.1 Frontend Analysis

**First, detect the frontend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.frontend`
2. Otherwise, detect from project files:
   - Vue.js: `*.vue` files exist or `vite.config.*` with vue
   - React: `package.json` contains "react" dependency
   - Angular: `angular.json` exists
   - Next.js: `next.config.*` exists
   - Svelte: `svelte.config.*` exists

**Then use appropriate patterns based on detected frontend:**

| Stack | Page Patterns | Component Patterns | Store/State Patterns |
|-------|--------------|-------------------|----------------------|
| Vue.js | `**/pages/**/*{MODULE}*.vue`, `**/views/**/*{MODULE}*.vue` | `**/components/**/*{MODULE}*.vue` | `**/stores/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| React | `**/pages/**/*{MODULE}*.tsx`, `**/pages/**/*{MODULE}*.jsx` | `**/components/**/*{MODULE}*.tsx` | `**/store/**/*{MODULE}*.ts`, `**/redux/**/*{MODULE}*.ts` |
| Angular | `**/*{MODULE}*.component.ts` | `**/components/**/*{MODULE}*.ts` | `**/services/**/*{MODULE}*.service.ts` |
| Next.js | `**/app/**/*{MODULE}*/page.tsx`, `**/pages/**/*{MODULE}*.tsx` | `**/components/**/*{MODULE}*.tsx` | `**/lib/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| Svelte | `**/routes/**/*{MODULE}*.svelte` | `**/components/**/*{MODULE}*.svelte` | `**/stores/**/*{MODULE}*.ts` |
| Generic | `**/pages/**/*{MODULE}*.*`, `**/views/**/*{MODULE}*.*` | `**/components/**/*{MODULE}*.*` | `**/store*/**/*{MODULE}*.*` |

Extract:
- All screens and navigation paths
- Form fields with validations
- User interactions (buttons, actions)
- Data display formats (tables, cards, lists)

#### 2.2 Backend Analysis

**First, detect the backend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.backend`
2. Otherwise, detect from project files:
   - .NET (C#): `*.csproj` or `*.sln` files exist
   - Node.js/Express: `package.json` with express/fastify/nestjs
   - Spring Boot: `pom.xml` or `build.gradle` with Spring
   - Django: `requirements.txt` or `pyproject.toml` with django
   - FastAPI: `requirements.txt` with fastapi
   - Go: `go.mod` exists
   - Ruby on Rails: `Gemfile` with rails

**Then use appropriate patterns based on detected backend:**

| Stack | Controllers/Handlers | Services/Logic | DTOs/Models | Entities |
|-------|---------------------|----------------|-------------|----------|
| .NET (C#) | `**/Controllers/*{MODULE}*.cs` | `**/Services/*{MODULE}*.cs` | `**/DTOs/*{MODULE}*.cs`, `**/Models/*{MODULE}*.cs` | `**/Entities/*{MODULE}*.cs` |
| Node.js/Express | `**/routes/*{MODULE}*.ts`, `**/routes/*{MODULE}*.js` | `**/services/*{MODULE}*.ts` | `**/models/*{MODULE}*.ts`, `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.ts` |
| NestJS | `**/*{MODULE}*.controller.ts` | `**/*{MODULE}*.service.ts` | `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.entity.ts` |
| Spring Boot | `**/controller/*{MODULE}*.java` | `**/service/*{MODULE}*.java` | `**/dto/*{MODULE}*.java` | `**/entity/*{MODULE}*.java`, `**/model/*{MODULE}*.java` |
| Django | `**/views/*{MODULE}*.py`, `**/*{MODULE}*/views.py` | `**/services/*{MODULE}*.py` | `**/serializers/*{MODULE}*.py` | `**/models/*{MODULE}*.py`, `**/*{MODULE}*/models.py` |
| FastAPI | `**/routers/*{MODULE}*.py`, `**/routes/*{MODULE}*.py` | `**/services/*{MODULE}*.py` | `**/schemas/*{MODULE}*.py` | `**/models/*{MODULE}*.py` |
| Go | `**/handlers/*{MODULE}*.go`, `**/controllers/*{MODULE}*.go` | `**/services/*{MODULE}*.go` | `**/dto/*{MODULE}*.go`, `**/models/*{MODULE}*.go` | `**/entities/*{MODULE}*.go` |
| Ruby on Rails | `**/controllers/*{MODULE}*.rb` | `**/services/*{MODULE}*.rb` | `**/serializers/*{MODULE}*.rb` | `**/models/*{MODULE}*.rb` |
| Generic | `**/{controllers,handlers,routes}/**/*{MODULE}*.*` | `**/services/**/*{MODULE}*.*` | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` | `**/entities/**/*{MODULE}*.*` |

Extract:
- API endpoints (GET, POST, PUT, DELETE)
- Request/response models
- Business rules and validations
- Database relationships

#### 2.3 Service Layer Analysis

Use patterns appropriate for the detected backend:

| Stack | Business Logic | Calculations | Workflows |
|-------|---------------|--------------|-----------|
| .NET (C#) | `**/Services/*{MODULE}*Service*.cs` | `**/*{MODULE}*Calculator*.cs` | `**/*{MODULE}*Workflow*.cs` |
| Node.js/Express | `**/services/*{MODULE}*.ts` | `**/*{MODULE}*calculator*.ts` | `**/*{MODULE}*workflow*.ts` |
| Spring Boot | `**/service/*{MODULE}*Service*.java` | `**/*{MODULE}*Calculator*.java` | `**/*{MODULE}*Workflow*.java` |
| Django/FastAPI | `**/services/*{MODULE}*.py` | `**/*{MODULE}*calculator*.py` | `**/*{MODULE}*workflow*.py` |
| Go | `**/services/*{MODULE}*.go` | `**/*{MODULE}*calculator*.go` | `**/*{MODULE}*workflow*.go` |
| Generic | `**/services/**/*{MODULE}*.*` | `**/*{MODULE}*calc*.*` | `**/*{MODULE}*workflow*.*` |

Extract:
- Business calculations
- Workflow steps
- Approval processes
- External integrations

### Step 3: Identify Process Elements

Based on the code analysis, identify:

#### 3.1 Actors
- Identify roles from permission/authorization checks
- Map role names to actor types (Employee, Manager, HR, Admin, System)

#### 3.2 Process Steps
- Map HTTP GET endpoints → User views/loads data
- Map HTTP POST endpoints → User creates/submits
- Map HTTP PUT endpoints → User updates
- Map HTTP DELETE endpoints → User deletes
- Map service method calls → System actions

#### 3.3 Decision Points
- Map `if/else` statements → Decision diamonds
- Map validation rules → Decision points
- Map authorization checks → Permission gates

#### 3.4 Exception Paths
- Map `try/catch` blocks → Exception handling
- Map error responses → Error paths
- Map validation failures → Rejection paths

### Step 4: Explore Live UI with Playwright (Optional)
Use Playwright MCP tools to explore the live application:

Before exploring, ensure the application is running locally.
Analyze the repo and run the startup script specified in env variable `STARTUP_SCRIPT`.

Then:
1. Navigate to the application URL from env variable `APPLICATION_URL`
2. Login with credentials from env variables `credentials_email` and `credentials_password`
3. Navigate to the module's pages
4. Take screenshots of key screens
5. Document navigation flow and UI elements
6. Capture form fields, buttons, and actions
7. Log out, close browser, and stop servers using `STARTUP_SCRIPT`

### Step 5: Generate Mermaid Diagram
Create a flowchart with the following syntax:

```mermaid
flowchart TD
    Start([Start: Process Name]):::startEnd --> A[User Action 1]:::userAction
    A --> B(System validates input):::systemAction
    B --> C{Validation passed?}:::decision
    C -->|No| D[Show error message]:::error --> A
    C -->|Yes| E(System processes request):::systemAction
    E --> F{Approval required?}:::decision
    F -->|Yes| G[Send for approval]:::userAction
    F -->|No| H(System saves data):::systemAction
    G --> I{Approved?}:::decision
    I -->|Yes| H
    I -->|No| J[Rejected notification]:::error --> End
    H --> K[Success notification]:::userAction
    K --> End([End: Process Complete]):::startEnd

    classDef userAction fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef systemAction fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef decision fill:#fff8e1,stroke:#f57f17,color:#e65100
    classDef error fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef startEnd fill:#f3e5f5,stroke:#7b1fa2,color:#4a148c
```

### Step 6: Write Mermaid File
Save the Mermaid diagram to `Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd`

### Step 7: Render High-DPI PNG Image
Execute the following command to render a high-quality PNG (scale factor 2 for high-DPI):

```bash
mmdc -i Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd \
     -o Documents/ProcessFlow/diagrams/{ModuleName}_flow.png \
     -b white -w 2400 -H 1600 -s 2
```

**Options explained:**
- `-w 2400`: Width of 2400px for high resolution
- `-H 1600`: Height of 1600px
- `-s 2`: Scale factor of 2 for high-DPI/retina displays
- `-b white`: White background for better readability

**Fallback:** If mermaid-cli (`mmdc`) is not available or fails:
1. Use Playwright to navigate to https://mermaid.live
2. Paste the Mermaid code into the editor
3. Configure export settings for high-DPI (2x scale)
4. Download/screenshot the rendered diagram
5. Save to the PNG output path

### Step 8: Generate Markdown Document
Create the document with ALL sections matching the exact template structure below.

---

## Technology Detection

### Automatic Detection Process

Before analyzing module code, detect the technology stack:

```
TECHNOLOGY DETECTION:

1. CHECK for module-structure.json at project root:
   IF EXISTS:
     - Read detectedStack.backend → use for backend patterns
     - Read detectedStack.frontend → use for frontend patterns
     - Read detectedStack.database → document in Technology section
     - Read detectedStack.languages → use for file extensions
     - SKIP further detection

2. IF module-structure.json NOT found, DETECT manually:

   BACKEND DETECTION:
   - Check for *.csproj or *.sln → .NET (C#)
   - Check package.json for express/fastify/nestjs → Node.js
   - Check pom.xml or build.gradle for Spring → Spring Boot
   - Check requirements.txt/pyproject.toml for django → Django
   - Check requirements.txt for fastapi → FastAPI
   - Check for go.mod → Go
   - Check Gemfile for rails → Ruby on Rails
   - Check composer.json for laravel → Laravel (PHP)

   FRONTEND DETECTION:
   - Check for *.vue files → Vue.js
   - Check for angular.json → Angular
   - Check package.json for react → React
   - Check for next.config.* → Next.js
   - Check for svelte.config.* → Svelte

   DATABASE DETECTION:
   - Parse connection strings in config files
   - Check for ORM indicators (EF Core, Prisma, TypeORM, etc.)

3. STORE detected stack for use in pattern selection
```

### Using Module Structure (When Available)

If `module-structure.json` exists and contains the module being documented:

```
1. Find the module entry in modules array by name
2. Use paths.backend for backend file locations
3. Use paths.frontend for frontend file locations
4. Use paths.shared for DTO/type locations
5. This provides precise paths instead of glob patterns
```

---

## Document Structure (Must Follow Exactly)

### Title Page & Metadata

```markdown
# PROCESS FLOW DOCUMENT

**PROGRAMMERS.IO INDIA PVT LTD.**

---

| Field | Value |
|-------|-------|
| **Client Name** | {Client name or "PROGRAMMERS.IO"} |
| **Project Name** | {Project name from module-structure.json or directory name} - {Module Name} Module |
| **Document Version** | 1.0 |
| **Author Name** | Business Analyst |
| **Date** | {Current date in DD/MM/YYYY format} |

---
```

### Section 1: Purpose

```markdown
## 1. Purpose

This document describes the end-to-end process flow for the {Module Name} module within the application.

{Provide a detailed description of:
- What the process accomplishes
- Business value delivered
- Key outcomes expected}

---
```

### Section 2: Scope

```markdown
## 2. Scope

### In Scope
{List all processes and functionalities covered by this document:}
- Process 1: {Description}
- Process 2: {Description}
- ...

### Out of Scope
{List processes that are NOT covered:}
- Process 1: {Description}
- Process 2: {Description}
- ...

---
```

### Section 3: Actors Involved

```markdown
## 3. Actors Involved

| Actor Type | Actor Name | Description |
|------------|------------|-------------|
| Human | Employee | {Description of role in this process} |
| Human | Manager | {Description of role in this process} |
| Human | Administrator | {Description of role in this process} |
| System | Application System | {Description of automated actions} |
| External | {External System} | {Description if applicable} |

---
```

### Section 4: High-Level Process Summary

```markdown
## 4. High-Level Process Summary

{Provide a brief overview of the process in 3-5 sentences:}

The {Module Name} process begins when {trigger event}. The process involves {key actors} who perform {main activities}. Upon completion, the system {outcome/result}. This process supports {business objective}.

---
```

### Section 5: Detailed Process Flow Steps

```markdown
## 5. Detailed Process Flow Steps

| Step No. | Actor | Description | Output/Result |
|----------|-------|-------------|---------------|
| 1 | {Actor} | {Action description} | {Result of this step} |
| 2 | {Actor} | {Action description} | {Result of this step} |
| 3 | System | {Automated action} | {Result of this step} |
| 4 | {Actor} | {Decision point description} | {Result based on decision} |
| ... | ... | ... | ... |

---
```

### Section 6: Process Flow Diagram

```markdown
## 6. Process Flow Diagram

![{Module Name} Process Flow](diagrams/{ModuleName}_flow.png)

### Diagram Legend

| Shape | Meaning | Color |
|-------|---------|-------|
| Rounded Rectangle `([text])` | Start/End | Purple |
| Rectangle `[text]` | User Action | Blue |
| Stadium `(text)` | System Action | Green |
| Diamond `{text?}` | Decision Point | Yellow |
| Red Rectangle | Error/Exception | Red |

---
```

> **IMPORTANT: Do NOT include mermaid source code in the markdown document.**
> The mermaid source is stored separately in the `.mmd` file for maintenance.
> Only the rendered PNG image should be embedded in the document.

### Section 7: Business Rules

```markdown
## 7. Business Rules

| Rule ID | Rule Description |
|---------|------------------|
| BR-{ABBREV}-001 | {Business rule from service layer or validation} |
| BR-{ABBREV}-002 | {Business rule from service layer or validation} |
| BR-{ABBREV}-003 | {Business rule from service layer or validation} |
| ... | ... |

---
```

### Section 8: Exception Scenarios

```markdown
## 8. Exception Scenarios

### Exception 1: {Exception Name}

| Aspect | Details |
|--------|---------|
| **Trigger** | {What causes this exception} |
| **System Response** | {How the system handles it} |
| **Resolution** | {Steps to resolve} |

### Exception 2: {Exception Name}

| Aspect | Details |
|--------|---------|
| **Trigger** | {What causes this exception} |
| **System Response** | {How the system handles it} |
| **Resolution** | {Steps to resolve} |

{Repeat for each exception scenario identified}

---
```

### Section 9: Integrations

```markdown
## 9. Integrations

| Integration | Type | Description |
|-------------|------|-------------|
| {System/Module 1} | {API/Event/Database} | {How this process integrates with it} |
| {System/Module 2} | {API/Event/Database} | {How this process integrates with it} |
| {External Service} | {API/Webhook} | {How this process integrates with it} |

---
```

### Section 10: Assumptions

```markdown
## 10. Assumptions

- {Assumption 1: e.g., Users have valid credentials}
- {Assumption 2: e.g., Required master data is configured}
- {Assumption 3: e.g., Network connectivity is available}
- {Assumption 4: e.g., External services are operational}
- ...

---
```

### Section 11: Document History

```markdown
## 11. Document History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 1.0 | {Current date in DD/MM/YYYY} | Business Analyst | Initial draft |

---
```

---

## Mermaid Diagram Generation Guide

### Code Pattern to Flow Element Mapping

| Code Pattern | Flow Element | Mermaid Syntax |
|--------------|--------------|----------------|
| HTTP GET endpoint | User views/loads data | `[User views {resource}]:::userAction` |
| HTTP POST endpoint | User creates/submits | `[User submits {form}]:::userAction` |
| HTTP PUT endpoint | User updates | `[User updates {resource}]:::userAction` |
| HTTP DELETE endpoint | User deletes | `[User deletes {resource}]:::userAction` |
| `if/else` statements | Decision diamond | `{Condition?}:::decision` |
| `try/catch` blocks | Exception path | `[Error: {message}]:::error` |
| Validation rules | Decision point | `{Valid?}:::decision` |
| Service method calls | System action | `(System {action}):::systemAction` |
| Authorization checks | Permission gate | `{Has permission?}:::decision` |
| Approval workflows | Approval decision | `{Approved?}:::decision` |

### Mermaid Syntax Reference

```mermaid
flowchart TD
    %% Start and End nodes
    Start([Start: Process Name]):::startEnd
    End([End: Process Complete]):::startEnd

    %% User actions (rectangle)
    A[User performs action]:::userAction

    %% System actions (stadium shape)
    B(System validates data):::systemAction

    %% Decision points (diamond)
    C{Is condition met?}:::decision

    %% Error states
    D[Error: Validation failed]:::error

    %% Flow connections
    Start --> A
    A --> B
    B --> C
    C -->|Yes| End
    C -->|No| D
    D --> A

    %% Style definitions
    classDef userAction fill:#e3f2fd,stroke:#1565c0,color:#0d47a1
    classDef systemAction fill:#e8f5e9,stroke:#2e7d32,color:#1b5e20
    classDef decision fill:#fff8e1,stroke:#f57f17,color:#e65100
    classDef error fill:#ffebee,stroke:#c62828,color:#b71c1c
    classDef startEnd fill:#f3e5f5,stroke:#7b1fa2,color:#4a148c
```

### Rendering Command (High-DPI)

```bash
# Check if mmdc is installed, install if needed
which mmdc || npm install -g @mermaid-js/mermaid-cli

# Primary method using mermaid-cli (high-DPI rendering)
mmdc -i Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd \
     -o Documents/ProcessFlow/diagrams/{ModuleName}_flow.png \
     -b white -w 2400 -H 1600 -s 2

# Options:
#   -w 2400: Width in pixels (high resolution)
#   -H 1600: Height in pixels
#   -s 2: Scale factor for high-DPI/retina displays
#   -b white: White background for readability
```

> **IMPORTANT: Never include mermaid source code in the final markdown document.**
> The `.mmd` file is kept separate for maintenance purposes only.
> The markdown should only contain the PNG image reference.

---

## Step 9: Diagram Rendering Validation (MANDATORY)

> **CRITICAL: Validate that mermaid diagrams are rendered as PNG and no mermaid source appears in markdown.**

### 9.1 Verify PNG File Exists and Is Valid

Run the following validation:

```bash
# Check PNG file exists
if [ -f "Documents/ProcessFlow/diagrams/{ModuleName}_flow.png" ]; then
    echo "✓ PNG file exists"
    # Check file size (should be > 10KB for a proper diagram)
    size=$(stat -f%z "Documents/ProcessFlow/diagrams/{ModuleName}_flow.png" 2>/dev/null || stat -c%s "Documents/ProcessFlow/diagrams/{ModuleName}_flow.png" 2>/dev/null)
    if [ "$size" -gt 10000 ]; then
        echo "✓ PNG file size is valid: $size bytes"
    else
        echo "✗ PNG file too small, may be corrupt: $size bytes"
    fi
else
    echo "✗ PNG file NOT found - REGENERATE REQUIRED"
fi
```

### 9.2 Verify No Mermaid Source in Markdown

Scan the generated markdown document for mermaid code blocks:

```bash
# Check for mermaid code blocks in markdown
if grep -q '```mermaid' "Documents/ProcessFlow/{ModuleName}_ProcessFlow.md"; then
    echo "✗ VALIDATION FAILED: Mermaid source code found in markdown!"
    echo "  Action: Remove all mermaid code blocks from the document."
    echo "  The mermaid source should only exist in the .mmd file."
else
    echo "✓ No mermaid source code in markdown document"
fi
```

### 9.3 Verify Image Reference in Markdown

Ensure the PNG is properly referenced:

```bash
# Check for image reference
if grep -q '!\[.*\](diagrams/{ModuleName}_flow.png)' "Documents/ProcessFlow/{ModuleName}_ProcessFlow.md"; then
    echo "✓ PNG image properly referenced in markdown"
else
    echo "✗ PNG image reference missing or incorrect"
fi
```

### 9.4 Validation Checklist

| Check | Expected | Status |
|-------|----------|--------|
| PNG file exists | `Documents/ProcessFlow/diagrams/{ModuleName}_flow.png` | PASS/FAIL |
| PNG file size | > 10KB | PASS/FAIL |
| No `\`\`\`mermaid` in markdown | 0 occurrences | PASS/FAIL |
| PNG referenced in Section 6 | `![...](diagrams/...)` present | PASS/FAIL |
| .mmd source file exists | `Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd` | PASS/FAIL |

### 9.5 Auto-Correction for Mermaid Source Removal

If mermaid source code is found in the markdown, execute:

1. Read the markdown file
2. Remove any `<details>` sections containing mermaid code
3. Remove any standalone `\`\`\`mermaid ... \`\`\`` blocks
4. Keep only the PNG image reference
5. Rewrite the file

```
IF mermaid_source_found_in_markdown:
    1. Read document content
    2. Remove pattern: /<details>.*?```mermaid.*?```.*?<\/details>/s
    3. Remove pattern: /```mermaid[\s\S]*?```/
    4. Write corrected content back to file
    5. Re-validate
```

---

## Step 10: Template Alignment Verification (MANDATORY)

> **CRITICAL: This step ensures 100% alignment with the DOCX template. Do NOT skip.**

### 9.1 Extract Template Structure

Use MCP tools to read the DOCX template:

1. Call `mcp__word-document-server__get_document_outline` with template path:
   `templates/PROCESS FLOW DOCUMENT.docx`

2. Extract and document:
   - All section headings with their levels
   - All tables with row/column counts
   - Content structure expectations

### 9.2 Compare Generated Document

Read the generated Markdown document and compare:

| Check | Template Expectation | Generated | Status |
|-------|---------------------|-----------|--------|
| Section Count | 11 sections | ? | PASS/FAIL |
| Table Count | 3 tables | ? | PASS/FAIL |
| Heading Hierarchy | H1→H2→H3 | ? | PASS/FAIL |

### 9.3 Section Alignment Verification

Verify ALL 11 sections are present with exact names:

| # | Expected Section | Found | Status |
|---|------------------|-------|--------|
| 1 | Title Page & Metadata | ? | PASS/FAIL |
| 2 | 1. Purpose | ? | PASS/FAIL |
| 3 | 2. Scope | ? | PASS/FAIL |
| 4 | 3. Actors Involved | ? | PASS/FAIL |
| 5 | 4. High-Level Process Summary | ? | PASS/FAIL |
| 6 | 5. Detailed Process Flow Steps | ? | PASS/FAIL |
| 7 | 6. Process Flow Diagram | ? | PASS/FAIL |
| 8 | 7. Business Rules | ? | PASS/FAIL |
| 9 | 8. Exception Scenarios | ? | PASS/FAIL |
| 10 | 9. Integrations | ? | PASS/FAIL |
| 11 | 10. Assumptions | ? | PASS/FAIL |
| 12 | 11. Document History | ? | PASS/FAIL |

### 9.4 Table Alignment Verification

Verify ALL 3 tables are present with correct structure:

| Table | Expected Structure | Found | Status |
|-------|-------------------|-------|--------|
| Actors Involved | 3 columns (Actor Type, Actor Name, Description), 3+ rows | ? | PASS/FAIL |
| Process Steps | 4 columns (Step No., Actor, Description, Output/Result), 5+ rows | ? | PASS/FAIL |
| Document History | 4 columns (Version, Date, Author, Description), 2+ rows | ? | PASS/FAIL |

### 9.5 Auto-Correction Loop

If alignment < 100%, execute corrections:

```
WHILE alignment_score < 100%:
    1. Identify first mismatch
    2. Apply correction:
       - Missing Section → Add section with exact template heading
       - Wrong Section Name → Rename to match template exactly
       - Missing Table → Add table with correct structure
       - Wrong Table Structure → Adjust columns/rows to match
       - Wrong Heading Level → Adjust markdown heading level
    3. Re-verify document
    4. Update alignment score

    MAX_ITERATIONS = 5
    IF iterations > MAX_ITERATIONS: Report remaining issues and proceed
```

### 9.6 Alignment Report

After verification, output:

```
## Template Alignment Results

**Template:** templates/PROCESS FLOW DOCUMENT.docx
**Document:** Documents/ProcessFlow/{ModuleName}_ProcessFlow.md
**Alignment Score:** {SCORE}%

### Summary
| Category | Expected | Found | Status |
|----------|----------|-------|--------|
| Sections | 11 | {N} | PASS/FAIL |
| Tables | 3 | {N} | PASS/FAIL |
| Heading Levels | H1/H2/H3 | {levels} | PASS/FAIL |

### Corrections Applied
- {List of corrections made, or "None required"}

### Status: ALIGNED / NEEDS MANUAL REVIEW
```

---

## Verification Checklist

Before completing, verify:

### File Structure
- [ ] Directories created: `Documents/ProcessFlow/diagrams`
- [ ] Mermaid source file saved to `Documents/ProcessFlow/diagrams/{ModuleName}_flow.mmd`
- [ ] High-DPI PNG rendered to `Documents/ProcessFlow/diagrams/{ModuleName}_flow.png`
- [ ] Document created at `Documents/ProcessFlow/{ModuleName}_ProcessFlow.md`

### Diagram Validation (CRITICAL)
- [ ] **PNG file exists** and is > 10KB in size
- [ ] **NO mermaid source code** (`\`\`\`mermaid`) appears anywhere in the markdown document
- [ ] PNG image is properly referenced in Section 6: `![...](diagrams/{ModuleName}_flow.png)`
- [ ] Mermaid source exists ONLY in the `.mmd` file, NOT in the markdown

### Document Sections
- [ ] Title page with metadata table
- [ ] Section 1: Purpose
- [ ] Section 2: Scope (In Scope / Out of Scope)
- [ ] Section 3: Actors Involved table
- [ ] Section 4: High-Level Process Summary
- [ ] Section 5: Detailed Process Flow Steps table
- [ ] Section 6: Process Flow Diagram (PNG image ONLY, no mermaid code)
- [ ] Section 7: Business Rules table
- [ ] Section 8: Exception Scenarios
- [ ] Section 9: Integrations table
- [ ] Section 10: Assumptions
- [ ] Section 11: Document History table

### Content Quality
- [ ] All content derived from actual code analysis
- [ ] Business Rule IDs follow convention: BR-{MODULE_ABBREV}-XXX
- [ ] Flow elements properly mapped from code patterns
- [ ] Mermaid diagram uses correct styling classes

---

## Critical Source Files to Analyze

**The paths below are determined dynamically based on the detected technology stack.**

If `module-structure.json` exists, use the paths from the matching module entry.

Otherwise, use the Explore agent with these generic patterns:

| Purpose | Generic Pattern (adapts to detected stack) |
|---------|---------------------------------------------|
| Frontend pages | `**/{pages,views,app}/**/*{MODULE}*.*` |
| Frontend components | `**/components/**/*{MODULE}*.*` |
| Backend controllers/handlers | `**/{controllers,handlers,routes,routers}/**/*{MODULE}*.*` |
| Backend services | `**/services/**/*{MODULE}*.*` |
| DTOs/Models | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` |
| Entities | `**/{entities,models,domain}/**/*{MODULE}*.*` |
| Validations | `**/{validations,validators}/**/*{MODULE}*.*` |
| Stores/State | `**/{store,stores,redux,state}/**/*{MODULE}*.*` |

---

## Execution

Now analyze the module "$ARGUMENTS" and generate the complete Process Flow Document:

1. **Parse arguments** - Extract MODULE_NAME from $ARGUMENTS
2. **Detect technology stack** - Check for module-structure.json or detect from project files
3. **Create directories** - Run `mkdir -p Documents/ProcessFlow/diagrams`
4. **Run code analysis** - Use Explore agent with technology-appropriate patterns
5. **Analyze frontend** - Extract pages, components, forms, fields, actions
6. **Analyze backend** - Extract controllers, services, DTOs, entities
7. **Identify process elements** - Map code patterns to flow elements
8. **Explore UI (optional)** - Use Playwright to capture screenshots and workflows
9. **Generate Mermaid diagram** - Create flowchart with proper syntax and styling
10. **Write Mermaid file** - Save `.mmd` file to diagrams folder
11. **Render High-DPI PNG** - Execute `mmdc` command with `-s 2` scale factor (with fallback to Playwright)
12. **Generate document** - Use Write tool to create Markdown file with all 11 sections
    - **IMPORTANT:** Do NOT include any `\`\`\`mermaid` code blocks in the markdown
    - Only include the PNG image reference: `![...](diagrams/{ModuleName}_flow.png)`
13. **Validate diagram rendering** - Run Step 9 validation:
    - Verify PNG file exists and is > 10KB
    - Verify NO mermaid source code in markdown document
    - Verify PNG is properly referenced in Section 6
    - Auto-correct if mermaid code is found in markdown
14. **Template alignment verification** - Run Step 10 verification
15. **Final output** - Confirm all files created and checklist completed
