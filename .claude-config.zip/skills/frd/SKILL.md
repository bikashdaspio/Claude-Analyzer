---
name: frd
argument-hint: MODULE_NAME
description: Generate a comprehensive Functional Requirement Document (FRD) for the specified module following the standard template.
tags: [documentation, functional-requirements, analysis]
---

# Functional Requirement Document (FRD) Generator

**Arguments:** $ARGUMENTS (Module name, e.g., "Leaves", "Grievances", "KPI")

## Purpose
Generate a comprehensive Functional Requirement Document for the specified module, following the exact structure from `templates/FRD_Template.docx`.

## Output
- **Location:** `Documents/FRD/{ModuleName}_FRD.md`
- **Format:** Markdown (.md)

---

## Workflow

### Step 1: Parse Module Argument & Detect Technology Stack
1. Extract the MODULE_NAME from $ARGUMENTS
2. Set output path: `Documents/FRD/{ModuleName}_FRD.md`
3. Create output directory if needed using Bash: `mkdir -p Documents/FRD`
4. **Detect technology stack** (see Technology Detection section below)

### Step 2: Analyze Module Codebase
Use the **Explore agent** to gather comprehensive information about the module.

**IMPORTANT:** Use the appropriate search patterns based on the detected technology stack.

#### 2.1 Frontend Analysis

**First, detect the frontend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.frontend`
2. Otherwise, detect from project files:
   - Vue.js: `*.vue` files exist or `vite.config.*` with vue
   - React: `package.json` contains "react" dependency
   - Angular: `angular.json` exists
   - Next.js: `next.config.*` exists
   - Svelte: `svelte.config.*` exists

**Then use appropriate patterns based on detected frontend:**

| Stack | Page Patterns | Component Patterns | Store/State Patterns |
|-------|--------------|-------------------|----------------------|
| Vue.js | `**/pages/**/*{MODULE}*.vue`, `**/views/**/*{MODULE}*.vue` | `**/components/**/*{MODULE}*.vue` | `**/stores/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| React | `**/pages/**/*{MODULE}*.tsx`, `**/pages/**/*{MODULE}*.jsx` | `**/components/**/*{MODULE}*.tsx` | `**/store/**/*{MODULE}*.ts`, `**/redux/**/*{MODULE}*.ts` |
| Angular | `**/*{MODULE}*.component.ts` | `**/components/**/*{MODULE}*.ts` | `**/services/**/*{MODULE}*.service.ts` |
| Next.js | `**/app/**/*{MODULE}*/page.tsx`, `**/pages/**/*{MODULE}*.tsx` | `**/components/**/*{MODULE}*.tsx` | `**/lib/**/*{MODULE}*.ts`, `**/store/**/*{MODULE}*.ts` |
| Svelte | `**/routes/**/*{MODULE}*.svelte` | `**/components/**/*{MODULE}*.svelte` | `**/stores/**/*{MODULE}*.ts` |
| Generic | `**/pages/**/*{MODULE}*.*`, `**/views/**/*{MODULE}*.*` | `**/components/**/*{MODULE}*.*` | `**/store*/**/*{MODULE}*.*` |

Extract:
- All screens and navigation paths
- Form fields with validations
- User interactions (buttons, actions)
- Data display formats (tables, cards, lists)

#### 2.2 Backend Analysis

**First, detect the backend technology stack:**
1. Check if `module-structure.json` exists - if so, use `detectedStack.backend`
2. Otherwise, detect from project files:
   - .NET (C#): `*.csproj` or `*.sln` files exist
   - Node.js/Express: `package.json` with express/fastify/nestjs
   - Spring Boot: `pom.xml` or `build.gradle` with Spring
   - Django: `requirements.txt` or `pyproject.toml` with django
   - FastAPI: `requirements.txt` with fastapi
   - Go: `go.mod` exists
   - Ruby on Rails: `Gemfile` with rails

**Then use appropriate patterns based on detected backend:**

| Stack | Controllers/Handlers | Services/Logic | DTOs/Models | Entities |
|-------|---------------------|----------------|-------------|----------|
| .NET (C#) | `**/Controllers/*{MODULE}*.cs` | `**/Services/*{MODULE}*.cs` | `**/DTOs/*{MODULE}*.cs`, `**/Models/*{MODULE}*.cs` | `**/Entities/*{MODULE}*.cs` |
| Node.js/Express | `**/routes/*{MODULE}*.ts`, `**/routes/*{MODULE}*.js` | `**/services/*{MODULE}*.ts` | `**/models/*{MODULE}*.ts`, `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.ts` |
| NestJS | `**/*{MODULE}*.controller.ts` | `**/*{MODULE}*.service.ts` | `**/dto/*{MODULE}*.ts` | `**/entities/*{MODULE}*.entity.ts` |
| Spring Boot | `**/controller/*{MODULE}*.java` | `**/service/*{MODULE}*.java` | `**/dto/*{MODULE}*.java` | `**/entity/*{MODULE}*.java`, `**/model/*{MODULE}*.java` |
| Django | `**/views/*{MODULE}*.py`, `**/*{MODULE}*/views.py` | `**/services/*{MODULE}*.py` | `**/serializers/*{MODULE}*.py` | `**/models/*{MODULE}*.py`, `**/*{MODULE}*/models.py` |
| FastAPI | `**/routers/*{MODULE}*.py`, `**/routes/*{MODULE}*.py` | `**/services/*{MODULE}*.py` | `**/schemas/*{MODULE}*.py` | `**/models/*{MODULE}*.py` |
| Go | `**/handlers/*{MODULE}*.go`, `**/controllers/*{MODULE}*.go` | `**/services/*{MODULE}*.go` | `**/dto/*{MODULE}*.go`, `**/models/*{MODULE}*.go` | `**/entities/*{MODULE}*.go` |
| Ruby on Rails | `**/controllers/*{MODULE}*.rb` | `**/services/*{MODULE}*.rb` | `**/serializers/*{MODULE}*.rb` | `**/models/*{MODULE}*.rb` |
| Generic | `**/{controllers,handlers,routes}/**/*{MODULE}*.*` | `**/services/**/*{MODULE}*.*` | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` | `**/entities/**/*{MODULE}*.*` |

Extract:
- API endpoints (GET, POST, PUT, DELETE)
- Request/response models
- Business rules and validations
- Database relationships

#### 2.3 Service Layer Analysis

Use patterns appropriate for the detected backend:

| Stack | Business Logic | Calculations | Workflows |
|-------|---------------|--------------|-----------|
| .NET (C#) | `**/Services/*{MODULE}*Service*.cs` | `**/*{MODULE}*Calculator*.cs` | `**/*{MODULE}*Workflow*.cs` |
| Node.js/Express | `**/services/*{MODULE}*.ts` | `**/*{MODULE}*calculator*.ts` | `**/*{MODULE}*workflow*.ts` |
| Spring Boot | `**/service/*{MODULE}*Service*.java` | `**/*{MODULE}*Calculator*.java` | `**/*{MODULE}*Workflow*.java` |
| Django/FastAPI | `**/services/*{MODULE}*.py` | `**/*{MODULE}*calculator*.py` | `**/*{MODULE}*workflow*.py` |
| Go | `**/services/*{MODULE}*.go` | `**/*{MODULE}*calculator*.go` | `**/*{MODULE}*workflow*.go` |
| Generic | `**/services/**/*{MODULE}*.*` | `**/*{MODULE}*calc*.*` | `**/*{MODULE}*workflow*.*` |

Extract:
- Business calculations
- Workflow steps
- Approval processes
- External integrations

### Step 3: Explore Live UI with Playwright (Optional)
Use Playwright MCP tools to explore the live application:

Before exploring, ensure the application is running locally.
Analyze the repo and run the startup script specified in env variable `STARTUP_SCRIPT`.

Then:
1. Navigate to the application URL from env variable `APPLICATION_URL`
2. Login with credentials from env variables `credentials_email` and `credentials_password`
3. Navigate to the module's pages
4. Take screenshots of key screens
5. Document navigation flow and UI elements
6. Capture form fields, buttons, and actions
7. Log out, close browser, and stop servers using `STARTUP_SCRIPT`

### Step 4: Generate FRD Document
Create the document with ALL sections matching the exact template structure.

---

## Technology Detection

### Automatic Detection Process

Before analyzing module code, detect the technology stack:

```
TECHNOLOGY DETECTION:

1. CHECK for module-structure.json at project root:
   IF EXISTS:
     - Read detectedStack.backend → use for backend patterns
     - Read detectedStack.frontend → use for frontend patterns
     - Read detectedStack.database → document in Technology section
     - Read detectedStack.languages → use for file extensions
     - SKIP further detection

2. IF module-structure.json NOT found, DETECT manually:

   BACKEND DETECTION:
   - Check for *.csproj or *.sln → .NET (C#)
   - Check package.json for express/fastify/nestjs → Node.js
   - Check pom.xml or build.gradle for Spring → Spring Boot
   - Check requirements.txt/pyproject.toml for django → Django
   - Check requirements.txt for fastapi → FastAPI
   - Check for go.mod → Go
   - Check Gemfile for rails → Ruby on Rails
   - Check composer.json for laravel → Laravel (PHP)

   FRONTEND DETECTION:
   - Check for *.vue files → Vue.js
   - Check for angular.json → Angular
   - Check package.json for react → React
   - Check for next.config.* → Next.js
   - Check for svelte.config.* → Svelte

   DATABASE DETECTION:
   - Parse connection strings in config files
   - Check for ORM indicators (EF Core, Prisma, TypeORM, etc.)

3. STORE detected stack for use in pattern selection
```

### Using Module Structure (When Available)

If `module-structure.json` exists and contains the module being documented:

```
1. Find the module entry in modules array by name
2. Use paths.backend for backend file locations
3. Use paths.frontend for frontend file locations
4. Use paths.shared for DTO/type locations
5. This provides precise paths instead of glob patterns
```

---

## Document Structure (Must Follow Exactly)

### Title Page & Metadata

```markdown
# FUNCTIONAL REQUIREMENT DOCUMENT (FRD)

**PROGRAMMERS.IO INDIA PVT LTD.**

---

| Field | Value |
|-------|-------|
| **Client Name** | {Client name or "PROGRAMMERS.IO"} |
| **Project Name** | {Project name from module-structure.json or directory name} - {Module Name} Module |
| **Document Version** | 1.0 |
| **Author Name** | Business Analyst |
| **Date** | {Current date in DD/MM/YYYY format} |

---
```

### Version History Table

```markdown
## Version History

| Release Date | Version Number | Section/Page # Change | Change Details | Done By | Reviewed By |
|-------------|----------------|----------------------|----------------|---------|-------------|
| {Current date} | 1.0 | All | Initial draft | Business Analyst | Technical Lead |

---
```

### Section 1: Introduction

```markdown
## 1. Introduction

This Functional Requirements Document (FRD) is a formal statement of the {Module Name} module's functional requirements within the application.

### 1.1 Project Overview

{Provide a brief overview of the module derived from code analysis - what it does, who uses it, and why it exists within the application ecosystem.}

### 1.2 Problem Statement

{Specify the problem statement that this module resolves. Derive from:
- Business context of the module
- Pain points the module addresses
- Current challenges solved}

### 1.3 Purpose

{Define the goal that needs to be accomplished:
- Primary purpose of the module
- Key objectives
- Expected outcomes}

### 1.4 Project Scope

**In Scope:**
{List all features and functionalities that are part of this module, derived from code analysis:}
- Feature 1
- Feature 2
- ...

**Out of Scope:**
{List features that are NOT part of current implementation:}
- Feature 1
- Feature 2
- ...

### 1.5 Assumptions and Constraints

**Assumptions:**
{List assumptions made during analysis:}
- Assumption 1
- Assumption 2
- ...

**Constraints:**
{List constraints and limitations:}
- Constraint 1
- Constraint 2
- ...

#### 1.5.1 Any Dependencies

{Add details if there is a dependency to implement any functionality:}
- Dependency 1: {Description}
- Dependency 2: {Description}

### 1.6 Interfaces to External System

{List any external systems the module interfaces with:}

| System Name | Interface Type | Description |
|-------------|---------------|-------------|
| {System 1} | {API/File/Database} | {Description} |
| {System 2} | {API/File/Database} | {Description} |

---
```

### Section 2: Functional Requirements

```markdown
## 2. Functional Requirements

The functional requirements describe the core functionality of the {Module Name} module. This section includes the data and functional process requirements.

### 2.1 System Flow Diagram

{Describe the system flow including user roles and their related functionalities.}

**User Roles:**
| Role | Permissions | Description |
|------|-------------|-------------|
| {Role 1} | {Create, Read, Update, Delete} | {Description} |
| {Role 2} | {Read only} | {Description} |

**System Flow:**
1. {Step 1 description}
2. {Step 2 description}
3. {Step 3 description}
...

### 2.2 Functional Process Requirements

This section describes what the application should do for the {Module Name} module.

#### 2.2.1 Feature: {Feature Name}

**Description:** {Detailed description of the feature}

**Workflow Diagram:**
{Describe the workflow steps:}
1. Step 1: {Action}
2. Step 2: {Action}
3. Step 3: {Action}

**Wireframes/UI Description:**
{Describe the UI layout or reference screenshots:}
- Screen 1: {Description}
- Screen 2: {Description}

**Use Cases:**

| Use Case ID | Use Case Name | Actor | Description |
|------------|---------------|-------|-------------|
| UC-{ABBREV}-001 | {Use case name} | {Actor} | {Description} |
| UC-{ABBREV}-002 | {Use case name} | {Actor} | {Description} |

**Data Fields:**

| Field Name | Type | Required | Validation Rules | Description |
|-----------|------|----------|-----------------|-------------|
| {field} | {type} | Yes/No | {validation rules} | {description} |

**API Endpoints:**

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | /api/{module}/... | {description} | N/A | {response model} |
| POST | /api/{module}/... | {description} | {request model} | {response model} |

**Business Rules:**
- BR-001: {Rule description from service layer}
- BR-002: {Rule description from validations}

{Repeat for each feature discovered in the module}

#### 2.2.2 Entity Relationship Diagram

{Describe the database entities and their relationships:}

**Entities:**
| Entity Name | Description | Key Fields |
|-------------|-------------|------------|
| {Entity 1} | {Description} | {Primary key, foreign keys} |
| {Entity 2} | {Description} | {Primary key, foreign keys} |

**Relationships:**
- {Entity 1} → {Entity 2}: {Relationship type and description}
- {Entity 2} → {Entity 3}: {Relationship type and description}

#### 2.2.3 Swimlane Diagram

{Describe the process flow across different actors/systems:}

| Step | {Actor 1} | {Actor 2} | {System} |
|------|-----------|-----------|----------|
| 1 | {Action} | | |
| 2 | | {Action} | |
| 3 | | | {Action} |

### 2.3 Data Requirements

This section includes the entity definitions and attribute specifications.

**Entity: {Entity Name}**

| Attribute | Data Type | Size | Nullable | Default | Description |
|-----------|-----------|------|----------|---------|-------------|
| {attribute} | {type} | {size} | Yes/No | {default} | {description} |

{Repeat for each entity}

### 2.4 Non-Functional Requirements

Operational requirements describe the non-business characteristics of the application.

#### 2.4.1 Security

| Requirement | Specification |
|-------------|---------------|
| Authentication | {From code analysis - JWT/OAuth/etc.} |
| Authorization | Role-based access control (RBAC) |
| Data Encryption | {Encryption at rest and in transit} |
| Audit Logging | {All critical actions logged} |
| Session Management | {Session timeout, token expiry details} |

#### 2.4.2 Reliability

| Requirement | Specification |
|-------------|---------------|
| Uptime | {Expected uptime percentage} |
| Error Handling | {Error handling approach} |
| Data Integrity | {Data validation and consistency measures} |

#### 2.4.3 Performance

| Requirement | Specification |
|-------------|---------------|
| Page Load Time | < 3 seconds |
| API Response Time | < 500ms for standard operations |
| Concurrent Users | Support {N} concurrent users |
| Data Volume | Handle {N} records efficiently |

#### 2.4.4 Recoverability

| Requirement | Specification |
|-------------|---------------|
| Backup Frequency | {Backup schedule} |
| Recovery Time Objective (RTO) | {Maximum acceptable downtime} |
| Recovery Point Objective (RPO) | {Maximum acceptable data loss} |

#### 2.4.5 System Availability

| Requirement | Specification |
|-------------|---------------|
| Availability Target | {e.g., 99.9%} |
| Maintenance Windows | {Scheduled maintenance times} |
| Failover Strategy | {Failover approach if applicable} |

---
```

### Section 3: Technology Used

```markdown
## 3. Technology Used

This section specifies the technologies used for the {Module Name} module.

| S No. | Component | Technology |
|-------|-----------|------------|
| 1 | Back-end Technology | {From detectedStack or analysis} |
| 2 | Front-end Technology | {From detectedStack or analysis} |
| 3 | Database | {From detectedStack or analysis} |
| 4 | Authentication | {From analysis - e.g., JWT, OAuth 2.0} |
| 5 | API Style | {From analysis - e.g., RESTful API, GraphQL} |
| 6 | State Management | {From analysis - e.g., Pinia, Redux, Zustand} |
| 7 | UI Framework | {From analysis - e.g., Quasar, Material-UI, Tailwind} |

> **Note:** If `module-structure.json` exists, populate from `detectedStack`. Otherwise, detect automatically from project configuration files.

---
```

### Section 5: Data Migration

```markdown
## 5. Data Migration

{Explain in brief the data conversion plan if applicable.}

### Migration Overview

| Aspect | Details |
|--------|---------|
| Source System | {Source system name if migrating data} |
| Target System | {Project Name} - {Module Name} Module |
| Migration Strategy | {Strategy - e.g., Big Bang, Phased} |
| Data Volume | {Estimated data volume} |

### Migration Steps

1. {Step 1: Data extraction}
2. {Step 2: Data transformation}
3. {Step 3: Data loading}
4. {Step 4: Validation}

### Rollback Plan

{Describe rollback strategy in case of migration failure}

---
```

### Section 6: Document References

```markdown
## 6. Document References

The source of information for this FRD.

| Reference Document | Location | Description |
|-------------------|----------|-------------|
| API Documentation | /docs/api | API specifications |
| Database Schema | /docs/database | Entity relationship diagrams |
| UI Design Mockups | /designs | UI wireframes and mockups |
| Business Requirement Document | Documents/BRD/{Module}_BRD.md | Business requirements |
| {Other reference} | {Location} | {Description} |

---
```

### Section 7: Glossary

```markdown
## 7. Glossary

| Term | Abbreviation | Definition |
|------|--------------|------------|
| {Project-specific term} | {ABBREV} | {Definition based on detected technology} |
| {Module Name} | {ABBREV} | {Module description} |
| Functional Requirement Document | FRD | Document describing functional requirements |
| {Term from code} | {Abbrev} | {Definition} |
| {Business term} | {Abbrev} | {Definition} |

---
```

---

## Step 5: Template Alignment Verification (MANDATORY)

> **CRITICAL: This step ensures 100% alignment with the DOCX template. Do NOT skip.**

### 5.1 Extract Template Structure

Use MCP tools to read the DOCX template:

1. Call `mcp__word-document-server__get_document_outline` with template path:
   `templates/FRD_Template.docx`

2. Extract and document:
   - All section headings with their levels
   - All tables with row/column counts
   - Content structure expectations

### 5.2 Compare Generated Document

Read the generated Markdown document and compare:

| Check | Template Expectation | Generated | Status |
|-------|---------------------|-----------|--------|
| Section Count | 22 sections | ? | PASS/FAIL |
| Table Count | 2 tables | ? | PASS/FAIL |
| Heading Hierarchy | H1→H2→H3 | ? | PASS/FAIL |

### 5.3 Section Alignment Verification

Verify ALL 22 sections are present with exact names:

| # | Expected Section | Found | Status |
|---|------------------|-------|--------|
| 1 | Title Page & Metadata | ? | PASS/FAIL |
| 2 | Version History | ? | PASS/FAIL |
| 3 | 1. Introduction | ? | PASS/FAIL |
| 4 | 1.1 Project Overview | ? | PASS/FAIL |
| 5 | 1.2 Problem Statement | ? | PASS/FAIL |
| 6 | 1.3 Purpose | ? | PASS/FAIL |
| 7 | 1.4 Project Scope | ? | PASS/FAIL |
| 8 | 1.5 Assumptions and Constraints | ? | PASS/FAIL |
| 9 | 1.5.1 Any Dependencies | ? | PASS/FAIL |
| 10 | 1.6 Interfaces to External System | ? | PASS/FAIL |
| 11 | 2. Functional Requirements | ? | PASS/FAIL |
| 12 | 2.1 System Flow Diagram | ? | PASS/FAIL |
| 13 | 2.2 Functional Process Requirements | ? | PASS/FAIL |
| 14 | 2.2.1 Feature sections | ? | PASS/FAIL |
| 15 | 2.2.2 Entity Relationship Diagram | ? | PASS/FAIL |
| 16 | 2.2.3 Swimlane Diagram | ? | PASS/FAIL |
| 17 | 2.3 Data Requirements | ? | PASS/FAIL |
| 18 | 2.4 Non-Functional Requirements | ? | PASS/FAIL |
| 19 | 3. Technology Used | ? | PASS/FAIL |
| 20 | 5. Data Migration | ? | PASS/FAIL |
| 21 | 6. Document References | ? | PASS/FAIL |
| 22 | 7. Glossary | ? | PASS/FAIL |

### 5.4 Table Alignment Verification

Verify ALL 2 tables are present with correct structure:

| Table | Expected Structure | Found | Status |
|-------|-------------------|-------|--------|
| Version History | 6 columns (Release Date, Version Number, Section/Page # Change, Change Details, Done By, Reviewed By), 2+ rows | ? | PASS/FAIL |
| Technology | 3 columns (S No., Component, Technology), 3+ rows | ? | PASS/FAIL |

### 5.5 Auto-Correction Loop

If alignment < 100%, execute corrections:

```
WHILE alignment_score < 100%:
    1. Identify first mismatch
    2. Apply correction:
       - Missing Section → Add section with exact template heading
       - Wrong Section Name → Rename to match template exactly
       - Missing Table → Add table with correct structure
       - Wrong Table Structure → Adjust columns/rows to match
       - Wrong Heading Level → Adjust markdown heading level
    3. Re-verify document
    4. Update alignment score

    MAX_ITERATIONS = 5
    IF iterations > MAX_ITERATIONS: Report remaining issues and proceed
```

### 5.6 Alignment Report

After verification, output:

```
## Template Alignment Results

**Template:** templates/FRD_Template.docx
**Document:** Documents/FRD/{ModuleName}_FRD.md
**Alignment Score:** {SCORE}%

### Summary
| Category | Expected | Found | Status |
|----------|----------|-------|--------|
| Sections | 22 | {N} | PASS/FAIL |
| Tables | 2 | {N} | PASS/FAIL |
| Heading Levels | H1/H2/H3 | {levels} | PASS/FAIL |

### Corrections Applied
- {List of corrections made, or "None required"}

### Status: ALIGNED / NEEDS MANUAL REVIEW
```

---

## Verification Checklist

Before completing, verify:
- [ ] Document created at `Documents/FRD/{ModuleName}_FRD.md`
- [ ] Title page with metadata table (Client, Project, Version, Author, Date)
- [ ] Version History table (6 columns: Release Date, Version Number, Section/Page # Change, Change Details, Done By, Reviewed By)
- [ ] Section 1: Introduction with all 6 subsections (1.1-1.6)
- [ ] Section 2: Functional Requirements with:
  - [ ] 2.1 System Flow Diagram
  - [ ] 2.2 Functional Process Requirements (workflows, wireframes, use cases, ERD, swimlane)
  - [ ] 2.3 Data Requirements
  - [ ] 2.4 Non-Functional Requirements (Security, Reliability, Performance, Recoverability, System Availability)
- [ ] Section 3: Technology table (3 columns: S No., Component, Technology)
- [ ] Section 5: Data Migration plan
- [ ] Section 6: Document References table
- [ ] Section 7: Glossary table
- [ ] All content derived from actual code analysis, not generic placeholders
- [ ] Use Case IDs follow convention: UC-{MODULE_ABBREV}-XXX
- [ ] Business Rule IDs follow convention: BR-XXX
- [ ] Field names match actual implementation
- [ ] Business rules extracted from service layer and validations
- [ ] API endpoints documented from controllers
- [ ] UI exploration findings incorporated (if applicable)

---

## Critical Source Files to Analyze

**The paths below are determined dynamically based on the detected technology stack.**

If `module-structure.json` exists, use the paths from the matching module entry.

Otherwise, use the Explore agent with these generic patterns:

| Purpose | Generic Pattern (adapts to detected stack) |
|---------|---------------------------------------------|
| Frontend pages | `**/{pages,views,app}/**/*{MODULE}*.*` |
| Frontend components | `**/components/**/*{MODULE}*.*` |
| Backend controllers/handlers | `**/{controllers,handlers,routes,routers}/**/*{MODULE}*.*` |
| Backend services | `**/services/**/*{MODULE}*.*` |
| DTOs/Models | `**/{dto,dtos,models,schemas}/**/*{MODULE}*.*` |
| Entities | `**/{entities,models,domain}/**/*{MODULE}*.*` |
| Validations | `**/{validations,validators}/**/*{MODULE}*.*` |
| Stores/State | `**/{store,stores,redux,state}/**/*{MODULE}*.*` |

---

## Execution

Now analyze the module "$ARGUMENTS" and generate the complete Functional Requirement Document:

1. **Parse arguments** - Extract MODULE_NAME from $ARGUMENTS
2. **Detect technology stack** - Check for module-structure.json or detect from project files
3. **Create directory** - Run `mkdir -p Documents/FRD`
4. **Run code analysis** - Use Explore agent with technology-appropriate patterns
5. **Analyze frontend** - Extract pages, components, forms, fields, actions
6. **Analyze backend** - Extract controllers, services, DTOs, entities
7. **Extract business rules** - From service layer and validations
8. **Explore UI (optional)** - Use Playwright to capture screenshots and workflows
9. **Generate document** - Use Write tool to create Markdown file
10. **Verify output** - Confirm all sections and tables present
