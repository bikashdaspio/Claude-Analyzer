---
name: module-discovery
description: Analyzes any codebase to discover modules, sub-modules, paths, and metrics - generating structured JSON output
tags: [analysis, discovery, modules, architecture, documentation]
---
# Module Discovery Skill

## Purpose

This skill performs **technology-agnostic module discovery** on any codebase. It automatically detects the technology stack, identifies module boundaries across all layers (backend, frontend, shared), calculates metrics, and generates a comprehensive JSON structure.

The output serves as a foundation for further documentation generation (BRD, FRD, User Stories, Process Flows).

## Output Specification

Generate `module-structure.json` at the project root with this structure:

```json
{
  "projectName": "string",
  "version": "string",
  "analyzedAt": "ISO timestamp",
  "detectedStack": {
    "backend": "string | null",
    "frontend": "string | null",
    "database": "string | null",
    "languages": ["string"]
  },
  "modules": [
    {
      "name": "string",
      "description": "string",
      "paths": {
        "backend": "string | null",
        "frontend": "string | null",
        "shared": "string | null",
        "types": "string | null"
      },
      "metrics": {
        "fileCount": number,
        "lineCount": number,
        "complexity": "low | medium | high"
      },
      "subModules": [/* recursive structure */]
    }
  ],
  "summary": {
    "totalModules": number,
    "totalSubModules": number,
    "totalFiles": number,
    "totalLines": number
  }
}
```

---

## Phase 1: Technology Stack Detection

### Step 1.1: Scan Project Root for Backend Technology

Use Glob to find configuration files and identify the primary backend technology:

| File Pattern | Technology | Framework Detection |
|-------------|------------|---------------------|
| `*.csproj`, `*.sln` | .NET (C#) | Check for ASP.NET Core in csproj |
| `package.json` | Node.js | Check dependencies for express/fastify/nestjs/hapi |
| `pom.xml` | Java (Maven) | Check for Spring Boot starter |
| `build.gradle`, `build.gradle.kts` | Java (Gradle) | Check for Spring Boot plugin |
| `requirements.txt`, `pyproject.toml`, `setup.py` | Python | Check for django/flask/fastapi |
| `go.mod` | Go | Check for gin/echo/fiber/chi |
| `Cargo.toml` | Rust | Check for actix/rocket/axum |
| `composer.json` | PHP | Check for laravel/symfony |
| `Gemfile` | Ruby | Check for rails/sinatra |

**Detection Logic:**
```
1. Glob for each pattern above
2. If found, read the file to identify specific framework
3. Record: { backend: "ASP.NET Core" | "Express.js" | "Spring Boot" | etc. }
4. If no backend detected, set backend: null
```

### Step 1.2: Detect Frontend Framework

Search for frontend indicators:

| File/Pattern | Framework |
|-------------|-----------|
| `*.vue` files exist | Vue.js |
| `vite.config.*` with vue plugin | Vue.js + Vite |
| `nuxt.config.*` | Nuxt.js |
| `package.json` contains "react" | React |
| `next.config.*` | Next.js |
| `angular.json` | Angular |
| `svelte.config.*` | Svelte |
| `package.json` contains "svelte" | Svelte |

**Detection Logic:**
```
1. Check for framework-specific config files first (most specific)
2. If not found, check package.json dependencies
3. If .vue files exist anywhere, mark as Vue.js
4. Record: { frontend: "Vue.js" | "React" | "Angular" | etc. }
5. If no frontend detected, set frontend: null
```

### Step 1.3: Detect Database/ORM

Search for database configuration:

| Pattern | Database/ORM |
|--------|--------------|
| `appsettings.json` with "ConnectionString" | SQL Server/PostgreSQL (from connection string) |
| `prisma/schema.prisma` | Prisma ORM |
| `package.json` with "mongoose" | MongoDB (Mongoose) |
| `package.json` with "typeorm" | TypeORM |
| `package.json` with "sequelize" | Sequelize |
| `package.json` with "knex" | Knex.js |
| `*.csproj` with "EntityFrameworkCore" | Entity Framework Core |
| `pom.xml` with "hibernate" | Hibernate |
| `requirements.txt` with "sqlalchemy" | SQLAlchemy |
| `requirements.txt` with "django" | Django ORM |

**Detection Logic:**
```
1. Search configuration files for database indicators
2. Parse connection strings to identify database type
3. Record: { database: "PostgreSQL + EF Core" | "MongoDB" | etc. }
4. If no database detected, set database: null
```

### Step 1.4: Compile Languages List

Based on detected stack and file extensions found:

```
languages = []
if .cs files exist: languages.push("C#")
if .ts/.tsx files exist: languages.push("TypeScript")
if .js/.jsx files exist: languages.push("JavaScript")
if .vue files exist: languages.push("Vue")
if .py files exist: languages.push("Python")
if .java files exist: languages.push("Java")
if .go files exist: languages.push("Go")
if .rs files exist: languages.push("Rust")
if .php files exist: languages.push("PHP")
if .rb files exist: languages.push("Ruby")
if .sql files exist: languages.push("SQL")
```

---

## Phase 2: Directory Structure Analysis

### Step 2.1: Map Layer Boundaries

Scan the codebase to identify which directories contain each layer:

**Backend Indicators (search for these patterns):**
```
**/Controllers/**
**/controllers/**
**/Api/**
**/api/**
**/Routes/**
**/routes/**
**/Services/**
**/services/**
**/Handlers/**
**/handlers/**
**/Endpoints/**
**/endpoints/**
**/Application/**
**/Domain/**
**/Infrastructure/**
```

**Frontend Indicators:**
```
**/pages/**
**/Pages/**
**/views/**
**/Views/**
**/components/**
**/Components/**
**/screens/**
**/ui/**
**/src/app/** (for Angular/Next.js)
**/client/**
**/frontend/**
**/web/**
```

**Shared/Types Indicators:**
```
**/types/**
**/Types/**
**/interfaces/**
**/Interfaces/**
**/models/**
**/Models/**
**/shared/**
**/Shared/**
**/common/**
**/Common/**
**/dto/**
**/DTOs/**
**/entities/**
**/Entities/**
**/contracts/**
**/Contracts/**
```

**Database Indicators:**
```
**/migrations/**
**/Migrations/**
**/seeds/**
**/seeders/**
**/Data/**
**/Persistence/**
**/Repositories/**
**/repositories/**
```

**Record the base paths for each layer:**
```json
{
  "backendRoot": "HRMS/",
  "frontendRoot": "hrms-web/",
  "sharedRoot": "HRMS.Shared/",
  "databaseRoot": "HRMS/Infrastructure/Persistence/"
}
```

### Step 2.2: Identify Module Boundaries

Modules are discovered through multiple strategies:

**Strategy A: Controller/Feature-Based (Backend)**
```
For each controller found:
  - Extract module name from controller name (UserController → User)
  - Find related services, repositories, entities
  - Group as a module
```

**Strategy B: Directory-Based Grouping**
```
Look for feature folders at consistent levels:
  /modules/user/
  /features/authentication/
  /domains/employee/
```

**Strategy C: Vue/React Page-Based (Frontend)**
```
For each major page directory:
  - Extract module name from directory name
  - Include related components, composables, stores
```

**Strategy D: Domain-Driven Design Patterns**
```
Look for bounded contexts:
  /src/HumanResources/
  /src/Payroll/
  /src/Recruitment/
```

**Module Name Extraction Rules:**
```
1. Remove suffixes: Controller, Service, Repository, Module, Page, View
2. Convert to PascalCase for display
3. Use singular form (Users → User)
4. Preserve domain terminology (HRMS-specific terms)
```

---

## Phase 3: Cross-Layer Module Matching

### Step 3.1: Match Backend to Frontend

For each discovered backend module, find corresponding frontend code:

**Matching Criteria (in priority order):**

1. **Exact name match:**
   - `EmployeeController` ↔ `employee/` page directory
   - `UserService` ↔ `user/` components

2. **API route to page mapping:**
   - `/api/employees` endpoint ↔ `/pages/employees` or `/views/employees`

3. **Shared type references:**
   - If `EmployeeDto` is used in both backend and frontend, link them

4. **Semantic similarity:**
   - `LeaveManagement` backend ↔ `leave-requests` frontend

### Step 3.2: Build Module Path Map

For each module, construct the paths object:

```json
{
  "name": "Employee",
  "paths": {
    "backend": "HRMS/Controllers/Employee/ + HRMS/Application/Employee/",
    "frontend": "hrms-web/src/pages/employees/",
    "shared": "HRMS.Shared/DTOs/Employee/",
    "types": "hrms-web/src/types/employee.ts"
  }
}
```

**Path Resolution Rules:**
- If multiple directories, concatenate with " + "
- If single file (not directory), include file path
- If layer doesn't exist for module, set to null

---

## Phase 4: Metrics Calculation

### Step 4.1: Determine File Extensions

Based on detected languages, create extension list:

```
extensionMap = {
  "C#": [".cs"],
  "TypeScript": [".ts", ".tsx"],
  "JavaScript": [".js", ".jsx"],
  "Vue": [".vue"],
  "Python": [".py"],
  "Java": [".java"],
  "Go": [".go"],
  "Rust": [".rs"],
  "PHP": [".php"],
  "Ruby": [".rb"],
  "SQL": [".sql"]
}

activeExtensions = flatten(languages.map(lang => extensionMap[lang]))
```

### Step 4.2: Calculate Metrics Per Module

For each module's paths:

```
fileCount = 0
lineCount = 0

for each path in [backend, frontend, shared, types]:
  if path is not null:
    files = glob(path + "/**/*" with activeExtensions)
    fileCount += files.length
    for each file in files:
      lineCount += countNonBlankLines(file)
```

### Step 4.3: Determine Complexity

```
complexity =
  if fileCount > 30 OR lineCount > 2000: "high"
  else if fileCount >= 10 OR lineCount >= 500: "medium"
  else: "low"
```

**Complexity Factors (for description):**
- High: Large module with many files, significant business logic
- Medium: Moderate size, standard CRUD operations plus some business rules
- Low: Simple module, basic operations, few files

---

## Phase 5: Sub-Module Detection

### Step 5.1: Scan for Nested Structure

For each module, look for sub-divisions:

**Sub-module indicators:**
```
/Employee/
  /Management/     ← sub-module
  /Reporting/      ← sub-module
  /Onboarding/     ← sub-module

/Authentication/
  /Login/          ← sub-module
  /Registration/   ← sub-module
  /PasswordReset/  ← sub-module
```

### Step 5.2: Recursive Analysis

Apply the same module discovery process to sub-directories:

```
for each subdirectory in module path:
  if subdirectory contains code files:
    subModule = {
      name: extractModuleName(subdirectory),
      description: inferDescription(subdirectory),
      paths: discoverPaths(subdirectory),
      metrics: calculateMetrics(subdirectory),
      subModules: [] // Can nest further if needed
    }
    module.subModules.push(subModule)
```

### Step 5.3: Sub-Module Depth Limit

- Maximum nesting depth: 2 levels
- If deeper nesting exists, flatten into parent sub-module

---

## Phase 6: JSON Generation

### Step 6.1: Extract Project Metadata

```
projectName =
  - From package.json "name" field
  - From *.csproj project name
  - From go.mod module name
  - From directory name as fallback

version =
  - From package.json "version"
  - From *.csproj <Version> tag
  - From setup.py version
  - "1.0.0" as fallback
```

### Step 6.2: Generate Module Descriptions

For each module, create a meaningful description:

**Description Generation Rules:**
```
1. If README exists in module directory, extract first paragraph
2. If XML documentation exists (C#), use summary
3. If JSDoc exists, extract description
4. Otherwise, generate from:
   - Module name + "management" for CRUD modules
   - Module name + "functionality" for service modules
   - Infer from file names and controller actions
```

**Examples:**
```
Employee → "Employee management including profiles, documents, and organizational data"
Leave → "Leave request management including applications, approvals, and balance tracking"
Authentication → "User authentication and authorization including login, registration, and password management"
```

### Step 6.3: Calculate Summary Statistics

```
summary = {
  totalModules: modules.length,
  totalSubModules: sum(modules.map(m => m.subModules.length)),
  totalFiles: sum(modules.map(m => m.metrics.fileCount)),
  totalLines: sum(modules.map(m => m.metrics.lineCount))
}
```

### Step 6.4: Write JSON Output

Write to `./module-structure.json` with:
- Pretty-printed JSON (2-space indentation)
- UTF-8 encoding
- No trailing commas

---

## Execution Instructions

When `/module-discovery` is invoked:

### Step 1: Initialize
```
1. Announce: "Starting module discovery analysis..."
2. Create empty result structure
3. Record analyzedAt timestamp
```

### Step 2: Execute Phase 1 (Stack Detection)
```
1. Glob for all configuration files
2. Read and parse each to identify technologies
3. Populate detectedStack object
4. Report: "Detected stack: {backend} + {frontend} with {database}"
```

### Step 3: Execute Phase 2 (Directory Analysis)
```
1. Glob for layer indicators
2. Map directory structure
3. Report: "Found {n} potential module boundaries"
```

### Step 4: Execute Phase 3 (Module Discovery)
```
1. For each identified module boundary:
   a. Extract module name
   b. Find cross-layer paths
   c. Match related code
2. Report: "Discovered {n} modules"
```

### Step 5: Execute Phase 4 (Metrics)
```
1. For each module:
   a. Count files by extension
   b. Count lines of code
   c. Calculate complexity
2. Report: "Calculated metrics for all modules"
```

### Step 6: Execute Phase 5 (Sub-modules)
```
1. For each module, scan for nested structure
2. Apply recursive discovery
3. Report: "Found {n} sub-modules across all modules"
```

### Step 7: Execute Phase 6 (Output)
```
1. Generate project metadata
2. Generate module descriptions
3. Calculate summary
4. Write module-structure.json
5. Report: "Generated module-structure.json with {n} modules"
```

### Step 8: Verification
```
1. Read back the generated file
2. Validate JSON structure
3. Report summary statistics
```

---

## Verification Checklist

After generation, verify:

- [ ] `module-structure.json` exists at project root
- [ ] JSON is valid and parseable
- [ ] `detectedStack` accurately reflects technology
- [ ] All discovered modules have paths (at least one non-null)
- [ ] Metrics are calculated for each module
- [ ] Summary statistics match actual counts
- [ ] Sub-modules are properly nested
- [ ] Descriptions are meaningful (not just module names)

---

## Example Output

For a .NET + Vue.js HRMS project:

```json
{
  "projectName": "HRMS",
  "version": "1.0.0",
  "analyzedAt": "2025-01-21T10:30:00.000Z",
  "detectedStack": {
    "backend": "ASP.NET Core",
    "frontend": "Vue.js",
    "database": "PostgreSQL + Entity Framework Core",
    "languages": ["C#", "TypeScript", "Vue", "SQL"]
  },
  "modules": [
    {
      "name": "Employee",
      "description": "Employee management including profiles, organizational data, and document handling",
      "paths": {
        "backend": "HRMS/Controllers/EmployeeController.cs + HRMS/Application/Employees/",
        "frontend": "hrms-web/src/pages/employees/",
        "shared": "HRMS.Shared/DTOs/Employee/",
        "types": "hrms-web/src/types/employee.ts"
      },
      "metrics": {
        "fileCount": 45,
        "lineCount": 3200,
        "complexity": "high"
      },
      "subModules": [
        {
          "name": "Documents",
          "description": "Employee document management and storage",
          "paths": {
            "backend": "HRMS/Application/Employees/Documents/",
            "frontend": "hrms-web/src/pages/employees/documents/",
            "shared": null,
            "types": null
          },
          "metrics": {
            "fileCount": 8,
            "lineCount": 450,
            "complexity": "low"
          },
          "subModules": []
        }
      ]
    },
    {
      "name": "Leave",
      "description": "Leave request management including applications, approvals, and balance tracking",
      "paths": {
        "backend": "HRMS/Controllers/LeaveController.cs + HRMS/Application/Leave/",
        "frontend": "hrms-web/src/pages/leave/",
        "shared": "HRMS.Shared/DTOs/Leave/",
        "types": null
      },
      "metrics": {
        "fileCount": 28,
        "lineCount": 1800,
        "complexity": "medium"
      },
      "subModules": []
    }
  ],
  "summary": {
    "totalModules": 15,
    "totalSubModules": 8,
    "totalFiles": 342,
    "totalLines": 28500
  }
}
```

---

## Error Handling

- **No configuration files found:** Report "Unable to detect technology stack. Please ensure project root is correct."
- **Empty modules list:** Report "No modules discovered. The project structure may not follow common patterns."
- **File read errors:** Skip file, log warning, continue with other files
- **Invalid paths:** Set path to null, continue processing

---

## Notes

- This skill is designed to be the **first step** in documentation generation
- Output is consumed by `/brd`, `/frd`, `/user-stories`, and `/process-flow` skills
- Run this skill whenever the codebase structure changes significantly
- The JSON output can be committed to version control for tracking changes
